var tbl_product = $('#table_product');

$(document).ready( function () {  
    tbl_product.DataTable({
        searching : false,
        ordering : false,
        paging : false,

    });

    $('.btn_edit').on('click', function(){
        id_product = this.id;
        getData(id_product, function(result){
            // document.getElementById('tipe_food').value = result[0].nama_produk;
            document.getElementById('nama_product').innerHTML = result[0].nama;
            document.getElementById('plant_product').innerHTML = result[0].plant;
            document.getElementById('stock_now').innerHTML = result[0].stock;
            document.getElementById('id_product').value = id_product;
        });
        $('#modal-edit').modal('show');
    });

    $('#btn_update_harga').on('click', function(){
        harga_baru = document.getElementById('update_harga').value;
        if(harga_baru === ""){
            alert('Harap Mengisi Harga Terbaru!');
        }else{
            konfirmasi_update_harga = confirm("Anda Akan Mengupdate Harga Menjadi : " + currencyConverter(harga_baru));

            if(konfirmasi_update_harga === true){
                updateHarga(harga_baru, function(result){
                    location.reload();
                });
            }
        }
    });

    $('#save_update').on('click', function(){
        var stock_sekarang =  document.getElementById('stock_now').innerHTML;
        stock_sekarang =  parseInt(stock_sekarang);
        var stock_cek = document.getElementById('stock').value;
        var stock = parseInt(document.getElementById('stock').value);
        var id_product_update = document.getElementById('id_product').value;
        
        var stock_baru = stock_sekarang + stock;

        // console.log(stock_baru);

        if(stock_cek === ""){
            alert('Harap Memasukkan Tambahan Stock Product!');
        }else{
            konfirmasi_update_Stock = confirm("Anda Akan Mengupdate Stock Menjadi : \n" + stock_sekarang + " + " + stock + " = " + stock_baru);

            if(konfirmasi_update_Stock === true){
                updateStock(stock, stock_baru, id_product_update, function (result){
                    $('#modal-edit').modal('hide');
                    location.reload();
                });
            }

        }

    });

    function getData(id_product, callback){
        $.ajax({
            url: '../Product/getProduct',
            type: 'POST',
            dataType: 'json',
            data: {
                id_product : id_product
            },
            success: function(data){
                // console.log(data);
                callback(data);
            },
            error: function() {
                alert("error getData");
            }
        });
    }

    function updateStock(stock_new, stock_akhir, id_product, callback){
        $.ajax({
            url: '../Product/updateStock',
            type: 'POST',
            dataType: 'json',
            data: {
                stock_new : stock_new,
                id_product : id_product,
                stock_akhir : stock_akhir
            },
            success: function(data){
                // console.log(data);
                callback(data);
            },
            error: function() {
                alert("error updateStock");
            }
        });
    }

    function updateHarga(harga_new, callback){
        $.ajax({
            url: '../Product/updateHarga',
            type: 'POST',
            dataType: 'json',
            data: {
                harga_new : harga_new
            },
            success: function(data){
                // console.log(data);
                callback(data);
            },
            error: function() {
                alert("error updateHarga");
            }
        });
    }

    function updateAll(harga_new, stock_new, callback){
        $.ajax({
            url: '../Product/updateAll',
            type: 'POST',
            dataType: 'json',
            data: {
                harga_new : harga_new,
                stock_new : stock_new
            },
            success: function(data){
                // console.log(data);
                callback(data);
            },
            error: function() {
                alert("error updateAll");
            }
        });
    }

    function currencyConverter(uang){
        return new Intl.NumberFormat("id-ID", {
            style: "currency",
            currency: "IDR"
        }).format(uang);
    }
});