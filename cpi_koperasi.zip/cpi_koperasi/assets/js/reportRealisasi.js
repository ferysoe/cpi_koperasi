var cb_nama2 = $('#nama_user2');
var cb_nama3 = $('#nama_user3');
var cb_dept = $('#department_filter');
var cb_vendor = $('#vendor_filter');
var start = $('#tanggal_start');
var end = $('#tanggal_end');
// var test = $('#reservation');
var table_report = $('#table_report').DataTable({
    columns: [
        { "width": "20%" },
        { "width": "10%" },
        { "width": "20%" },
        { "width": "5%" },
        { "width": "5%" },
        { "width": "5%" },
        { "width": "10%" }
    ],
    ordering: true,
    order: [[1, 'ASC']]
});

var table_report_os = $('#table_report_os').DataTable({
    ordering: true,
    order: [[1, 'ASC']],
    pageLength: 50
});

var filter = "none";

$(document).ready( function () {
    start.datepicker({
        uiLibrary: 'bootstrap4',
        format: 'yyyy-mm-dd'
    });

    end.datepicker({
        uiLibrary: 'bootstrap4',
        format: 'yyyy-mm-dd'
    });

    cb_nama2.select2({
    width: '100%'
    });

    cb_nama3.select2({
        width: '100%'
    });

    cb_dept.select2({
        width: '100%'
    });

    cb_vendor.select2({
        width: '100%'
    });

    cb_vendor.on('change', function(){
       id_vendor = this.value;

    //    console.log(id_vendor);

        getDepartmentPerVendor(id_vendor, function(result){
            console.log(result);
        });
    });
});

function getDepartmentPerVendor(id_vendor, callback){
    $.ajax({
        url: '../../cpi_koperasi/Report/getDepartmentPerVendor',
        type: 'POST',
        dataType: 'json',
        data: {
            id_vendor : id_vendor
        },
        success: function(data){
            $("#department_filter option").remove();

            var x;
            var dataOption = [];

            dataOption.push({
                "id" : "",
                "text" : ""
            });

            for(x=0; x<data.length; x++){
                dataOption.push({
                    "id" : data[x].nama_department,
                    "text" : data[x].nama_department
                });
            }

            console.log(dataOption);

            cb_dept.select2({
                width: '100%',
                data:dataOption
            });

            callback(data);
        },
        error: function() {
            alert("error getDepartmentPerVendor");
        }
    });
}