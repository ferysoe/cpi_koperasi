var tbl_user = $('#table_user');

$(document).ready( function () {  
    
    tbl_user.DataTable({
        columns: [
                { "width": "3%" },
                { "width": "10%" },
                { "width": "7%" },
                { "width": "9%" },
                { "width": "5%" },
                { "width": "15%" },
                { "width": "3%" },
                { "width": "5%" },
                { "width": "5%" },
                { "width": "5%" },
                { "width": "5%" }
              ],
        order: [[0, 'desc']]
    });

    document.getElementById('btn_del').disabled = true;
    document.getElementById('username').value = "none";
    document.getElementById('password').value = "none";
    document.getElementById('area_pic').value = "none";

    document.getElementById("table_user").style.cursor = "pointer";

    tbl_user.on('click', 'tbody tr', function() {
        console.log(this.id)
        document.getElementById('id_user').value = this.id
        getUser(this.id, function(result){

            document.getElementById('username_edit').value = result[0].username;
            document.getElementById('password_edit').value = result[0].password;
            document.getElementById('nama_edit').value = result[0].nama;
            document.getElementById('no_reg_edit').value = result[0].no_reg;
            document.getElementById('sts_krywn_edit').value = result[0].status_karyawan;
            document.getElementById('vendor_edit').value = result[0].vendor;
            document.getElementById('department_edit').value = result[0].departemen;
            document.getElementById('aktif_edit').value = result[0].aktif;           
            document.getElementById('id_plant_edit').value = result[0].id_plant;
            document.getElementById('id_pic_edit').value = result[0].id_pic;
            document.getElementById('target_edit').value = result[0].target;
            document.getElementById('has_voucher_edit').value = result[0].has_voucher;

            if(result[0].id_akses > 0){
                document.getElementById('username_edit').disabled = false;
                document.getElementById('password_edit').disabled = false;
            }else{
                document.getElementById('username_edit').disabled = true;
                document.getElementById('password_edit').disabled = true;
            }
            
            $('#modaluser').modal('show');
        });
    });

    // $('.btn_modal').on('click', function(){
    //     console.log(this.id)
    //     document.getElementById('id_user').value = this.id
    //     getUser(this.id, function(result){
    //         console.log(result);
            
    //         if(result[0].status_karyawan === 'PREMANENT'){
    //             sts = 'Permanent';
    //         }else{
    //             sts = 'Non Permanent';
    //         }

    //         if(result[0].aktif === 'AKTIF'){
    //             aktif = 'Aktif';
    //         }else{
    //             aktif = 'Tidak Aktif';
    //         }

    //         document.getElementById('username_edit').value = result[0].username;
    //         document.getElementById('password_edit').value = result[0].password;
    //         document.getElementById('nama_edit').value = result[0].nama;
    //         document.getElementById('no_reg_edit').value = result[0].no_reg;
    //         document.getElementById('sts_krywn_edit').value = sts;
    //         document.getElementById('vendor_edit').value = result[0].vendor;
    //         document.getElementById('departemen_edit').value = result[0].departemen;
    //         document.getElementById('aktif_edit').value = aktif;           
    //         document.getElementById('id_plant_edit').value = result[0].id_plant;
    //         document.getElementById('id_pic_edit').value = result[0].id_pic;
    //         document.getElementById('target_edit').value = result[0].target;
    //         document.getElementById('id_akses_edit').value = result[0].id_akses;
            
    //         $('#modaluser').modal('show');
    //     });
    // });

    $('.btn_delete_modal').on('click', function(){
        console.log(this.id)
        document.getElementById('id_user_delete').value = this.id;
        getUser(this.id, function(result){
            console.log(result);
            document.getElementById('data').innerHTML = "Nama : " + result[0].nama + "<br>NoReg : " + result[0].no_reg;
            $('#modaldeleteuser').modal('show');
        });
    });

    // $('#status_karyawan').on('change', function(){
    //     if(this.value === 'PREMANENT'){
    //         document.getElementById('vendor').value = "5";
    //         document.getElementById('vendor').disabled = true;
    //     }else{
    //         document.getElementById('vendor').value = "";
    //         document.getElementById('vendor').disabled = false;
    //     }
    // });

    $('#pic_yesno').on('change', function(e){
        if(this.value === "y"){
            document.getElementById('username_label').style.display = "block";
            document.getElementById('username').style.display = "block";
            document.getElementById('password_label').style.display = "block";
            document.getElementById('password').style.display = "block";
            document.getElementById('pic_question_label').style.display = "block";
            document.getElementById('pic_question').style.display = "block";
            document.getElementById('area_pic_label').style.display = "block";
            document.getElementById('area_pic').style.display = "block";
            document.getElementById('id_pic').value = "";
            document.getElementById('username').value = "";
            document.getElementById('password').value = "";
            document.getElementById('area_pic').value = "";
            document.getElementById('id_pic').disabled = true;
        }else{
            document.getElementById('username_label').style.display = "none";
            document.getElementById('username').style.display = "none";
            document.getElementById('password_label').style.display = "none";
            document.getElementById('password').style.display = "none";
            document.getElementById('pic_question_label').style.display = "none";
            document.getElementById('pic_question').style.display = "none";
            document.getElementById('area_pic_label').style.display = "none";
            document.getElementById('area_pic').style.display = "none";
            document.getElementById('id_pic').disabled = false;
            document.getElementById('username').value = "none";
            document.getElementById('password').value = "none";
            document.getElementById('area_pic').value = "none";
        }
    });

    $('#pic_question').on('change', function(e){
        if(this.value === "n"){
            document.getElementById('id_pic').disabled = false;
        }else{
            document.getElementById('id_pic').value = "";
            document.getElementById('id_pic').disabled = true;
        }
    });
});

function getUser(id_user_del, callback){
    $.ajax({
        url: '../../cpi_koperasi/User/getUser',
        type: 'POST',
        dataType: 'json',
        data: {
            id_user_del : id_user_del
        },
        success: function(data){
            // console.log(data);
            callback(data);
        },
        error: function() {
            alert("error getUser");
        }
    });
}