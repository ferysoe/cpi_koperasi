var start = $('#tanggal_start');
var end = $('#tanggal_end');
// var test = $('#reservation');
var table_report_krian = $('#table_report_krian').DataTable({
    columns: [
        { "width": "50%" },
        { "width": "50%" }
    ],
    ordering: true,
    order: [[0, 'desc']]
});

var table_report_sepanjang = $('#table_report_sepanjang').DataTable({
    columns: [
        { "width": "50%" },
        { "width": "50%" }
    ],
    ordering: true,
    order: [[0, 'desc']]
});

var filter = "none";

$(document).ready( function () {
    start.datepicker({
        uiLibrary: 'bootstrap4',
        format: 'yyyy-mm-dd'
    });

    end.datepicker({
        uiLibrary: 'bootstrap4',
        format: 'yyyy-mm-dd'
    });
});
