var table_report = $('#table_data_user').DataTable({
    columns: [
        { "width": "10%" },
        { "width": "35%" },
        { "width": "5%" },
        { "width": "25%" },
        // { "width": "5%" },
        { "width": "12" }
    ],
    order: [[2, 'asc']],
    ordering: true
});

var filter = "none";

$(document).ready( function () {
    // var id_pic = document.getElementById('id_pic').value;
    // document.getElementById('department_filter').disabled = false;
    // var vendorLoad = "";
    // setValueCB(id_pic, vendorLoad, function(result){
    //     document.getElementById('department_filter').innerHTML = "";
    //     document.getElementById('department_filter').innerHTML = result;
    // });

    // $('#vendor_filter').on('change', function (e) {
    //     vendor = this.value;
    //     if(vendor === ""){
    //         // document.getElementById('department_filter').innerHTML = "";
    //         // document.getElementById('department_filter').innerHTML = "<option value=''></option>";
    //         // document.getElementById('department_filter').value = "";
    //         // document.getElementById('department_filter').disabled = true;
    //         setValueCB(id_pic, vendor, function(result){
    //             document.getElementById('department_filter').innerHTML = "";
    //             document.getElementById('department_filter').innerHTML = result;
    //         });
    //     }else{
    //         setValueCB(id_pic, vendor, function(result){
    //             document.getElementById('department_filter').innerHTML = "";
    //             document.getElementById('department_filter').innerHTML = result;
    //         });
    //     }
    // });

    $('#btn_search').on('click', function (e) {
        // isDepartmentOn = document.getElementById('department_filter').disabled;
        // departmentVal = document.getElementById('department_filter').value;
        // vendorVal = document.getElementById('vendor_filter').value;
        PICVal = document.getElementById('pic_filter').value;

        console.log(PICVal);

        if(PICVal !== ""){
            getDatabyPIC(PICVal , function(result){
                showDataUser(result);
            });
        }
    });

});

// function setValueCB(id_pic, vendor, callback){
//     $.ajax({
//         url: '../cpi_koperasi/ReportUser/getDepartment',
//         type: 'POST',
//         dataType: 'json',
//         data: {
//             vendor : vendor,
//             id_pic : id_pic
//         },
//         success: function(data){
//             var html = "<option value=''></option>";
//             for (let i = 0; i < data.length; i++) {
//                 html += "<option value='" + data[i].departemen + "'>" + data[i].departemen + "</option>";
//             }
//             callback(html);
//         },
//         error: function() {
//             alert("error setValueCB");
//         }
//     });
// }

function getDatabyVendor(id_pic, vendor, callback){
    $.ajax({
        url: '../cpi_koperasi/ReportUser/getDatabyVendor',
        type: 'POST',
        dataType: 'json',
        data: {
            vendor : vendor,
            id_pic : id_pic
        },
        success: function(data){
            callback(data);
        },
        error: function() {
            alert("error getDatabyVendor");
        }
    });
}

function getDatabyPIC(id_pic, callback){
    $.ajax({
        url: '../ReportUser/getDatabyPIC',
        type: 'POST',
        dataType: 'json',
        data: {
            id_pic : id_pic
        },
        success: function(data){
            // console.log(data);
            callback(data);
        },
        error: function() {
            alert("error getDatabyPIC");
        }
    });
}

function getDatabyDepartment(id_pic, department, callback){
    $.ajax({
        url: '../cpi_koperasi/ReportUser/getDatabyDepartment',
        type: 'POST',
        dataType: 'json',
        data: {
            department : department,
            id_pic : id_pic
        },
        success: function(data){
            callback(data);
        },
        error: function() {
            alert("error getDatabyDepartment");
        }
    });
}

function getDatabyVendor_Department(id_pic, vendor, department, callback){
    $.ajax({
        url: '../cpi_koperasi/ReportUser/getDatabyVendor_Department',
        type: 'POST',
        dataType: 'json',
        data: {
            vendor : vendor,
            id_pic : id_pic,
            department : department
        },
        success: function(data){
            callback(data);
        },
        error: function() {
            alert("error getDatabyVendor_Department");
        }
    });
}

function showDataUser(value){
    table_report.clear().draw();
    var i;
    for(i=0; i<value.length; i++){
        if(value[i].has_voucher === "y"){
            wv_voucher = "Yes";
        }else{
            wv_voucher = "No";
        }
        table_report.row.add([
            value[i].no_reg, 
            value[i].nama, 
            value[i].vendor, 
            value[i].department,
            // value[i].target,
            wv_voucher
        ]).node().id = value[i].id_user;
        table_report.draw();
    }
}
