var table_report = $('#table_dpd');
var table_report_permanent_krian = $('#table_dpd_permanent_krian');
var table_report_permanent_sepanjang = $('#table_dpd_permanent_sepanjang');
var table_report_permanent_premix = $('#table_dpd_permanent_premix');
var table_report_os_krian = $('#table_dpd_os_krian');
var table_report_os_sepanjang = $('#table_dpd_os_sepanjang');
var table_report_os_premix = $('#table_dpd_os_premix');

$(document).ready( function () {
    table_report.DataTable({
        columns: [
            { "width": "10%" },
            { "width": "35%" },
            { "width": "25%" },
            { "width": "25%" }
        ],
        order: [[0, 'asc']],
        ordering: true,
        pageLength: 3,
        lengthChange: false
    });

    table_report_permanent_krian.DataTable({
        columns: [
            { "width": "10%" },
            { "width": "15%" },
            { "width": "25%" },
            { "width": "25%" },
            { "width": "25%" }
        ],
        order: [[0, 'asc']],
        ordering: true,
        pageLength: 10,
        lengthChange: false
    });

    table_report_os_krian.DataTable({
        columns: [
            { "width": "10%" },
            { "width": "15%" },
            { "width": "25%" },
            { "width": "25%" },
            { "width": "25%" }
        ],
        order: [[0, 'asc']],
        ordering: true,
        pageLength: 6,
        lengthChange: false
    });

    table_report_permanent_sepanjang.DataTable({
        columns: [
            { "width": "10%" },
            { "width": "15%" },
            { "width": "25%" },
            { "width": "25%" },
            { "width": "25%" }
        ],
        order: [[0, 'asc']],
        ordering: true,
        pageLength: 10,
        lengthChange: false
    });

    table_report_os_sepanjang.DataTable({
        columns: [
            { "width": "10%" },
            { "width": "15%" },
            { "width": "25%" },
            { "width": "25%" },
            { "width": "25%" }
        ],
        order: [[0, 'asc']],
        ordering: true,
        pageLength: 4,
        lengthChange: false
    });

    table_report_permanent_premix.DataTable({
        columns: [
            { "width": "10%" },
            { "width": "15%" },
            { "width": "25%" },
            { "width": "25%" },
            { "width": "25%" }
        ],
        order: [[0, 'asc']],
        ordering: true,
        pageLength: 10,
        lengthChange: false
    });

    table_report_os_premix.DataTable({
        columns: [
            { "width": "10%" },
            { "width": "15%" },
            { "width": "25%" },
            { "width": "25%" },
            { "width": "25%" }
        ],
        order: [[0, 'asc']],
        ordering: true,
        pageLength: 2,
        lengthChange: false
    });
});
