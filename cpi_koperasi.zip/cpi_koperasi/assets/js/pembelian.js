var cb_nama = $('#nama_user');
var tbl_pembelian = $('#table_pembelian').DataTable({
      order: [[3, 'desc']],
      ordering: true
});

var tbl_pembelian_koperasi = $('#table_pembelian_koperasi').DataTable({
      order: [[3, 'desc']],
      ordering: true
});

var jp_before_edit = "";
var sp_before_edit = "";
var k_before_edit = "";
var jv_before_edit = "";
var kv_before_edit = "";

var flag_dont_accept = false;

$(document).ready( function () {
    
    cb_nama.select2({
        width: '100%'
    });

    id_pic = document.getElementById('id_pic').value;
    id_plant = document.getElementById('id_plant').value;
    id_akses = document.getElementById('id_akses').value;

    if(id_akses === "4"){
        document.getElementById('sisa_voucher_text').style.display = "none";
        document.getElementById('sisa_voucher_print').style.display = "none";
    
        stock_product = document.getElementById('stock_product').value;
        harga_product = document.getElementById('harga_product').value;
    
        // console.log(harga_product);
    
        document.getElementById('stock_now').innerHTML = stock_product;
        document.getElementById('harga_now').innerHTML = currencyConverter(harga_product);
        document.getElementById("table_pembelian").style.cursor = "pointer";
        document.getElementById("loading2").hidden = false;
        document.getElementById("loading").hidden = false;
        showDataPembelian(id_plant, id_akses);
    }else{
        document.getElementById("loading3").hidden = false;
        console.log("test");
        document.getElementById("table_pembelian_koperasi").style.cursor = "pointer";
        showDataPembelianKoperasi(id_plant, id_akses);
    }

    if(id_akses === "4"){
        if(stock_product <= 0){
            // console.log("here");
            document.getElementById('nama_user').disabled = true;
            document.getElementById('jumlah').disabled = true;
            document.getElementById('status_pembayaran').disabled = true;
            document.getElementById('keterangan').disabled = true;
            document.getElementById('jumlah_voucher').disabled = true;
            document.getElementById('kode_redeem_voucher').disabled = true;
    
            alert("Stock Product Habis, Harap Melakukan Restock Kembali!");
        }else{
            $('#save_pembelian').on('click', function(){ 
                document.getElementById("loading").hidden = false;
                var $this = $(this);

                $this.attr('disabled', true);
                
                // console.log(flag_dont_accept);

                stock = document.getElementById('stock_now').innerHTML; 
                stock = parseInt(stock); 
                id_user = $("#nama_user").val();
                status_pembayaran = document.getElementById('status_pembayaran').value;
                keterangan = document.getElementById('keterangan').value;
                jumlah = document.getElementById('jumlah').value;
                total_pembayaran = document.getElementById('total').value;
                jumlah_voucher = document.getElementById('jumlah_voucher').value;
                kode_voucher = document.getElementById('kode_redeem_voucher').value;

                var cekKode = kode_voucher.match(/,/gi);
                if(cekKode !== null){
                    var banyakKode = cekKode.length;
                    banyakKode += 1;
                }else{
                    var banyakKode = 1;
                }
        
                if(id_user === "--"){
                    document.getElementById("loading").hidden = true;
                    alert("Harap Memilih Nama Pembeli!");
                    $this.attr('disabled', false);
                }else{
                    
                        if(status_pembayaran === "--"){
                            document.getElementById("loading").hidden = true;
                            alert("Harap Memilih Status Pembayaran!");
                            $this.attr('disabled', false);
                        }else{
                            if(jumlah === ""){
                                document.getElementById("loading").hidden = true;
                                alert("Harap Mengisi Jumlah Pembelian!");
                                $this.attr('disabled', false);
                            }else{
                                if(jumlah > stock){
                                    document.getElementById("loading").hidden = true;
                                    alert("Jumlah Pembelian Melebihi Dari Stock Product!");
                                    $this.attr('disabled', false);
                                }else{
                                    if(status_pembayaran === "Voucher" && jumlah_voucher === ""){
                                        document.getElementById("loading").hidden = true;
                                        alert("Harap Mengisi Jumlah Voucher!");
                                        $this.attr('disabled', false);
                                    }else{
                                        if(status_pembayaran === "Voucher" && banyakKode < jumlah_voucher){
                                            document.getElementById("loading").hidden = true;
                                            alert("Jumlah Voucher yang Diinputkan Tidak Sesuai!");
                                            $this.attr('disabled', false);
                                        }else{
                                            if(status_pembayaran === "Voucher" && banyakKode > jumlah_voucher){
                                                document.getElementById("loading").hidden = true;
                                                alert("Jumlah Voucher yang Diinputkan Tidak Sesuai!");
                                                $this.attr('disabled', false);
                                            }else{
                                                if(flag_dont_accept == true){
                                                    document.getElementById("loading").hidden = true;
                                                    alert("Anda Melebihi Dari Jumlah Voucher Yang Bisa Digunakan!");
                                                    $this.attr('disabled', false);
                                                }else{
                                                    // console.log('test');  
                                                    insertPembelian(id_user, status_pembayaran, keterangan, jumlah, jumlah_voucher, kode_voucher, total_pembayaran, id_plant, function(result){
                                                        if(result === true){
                                                            document.getElementById("loading").hidden = true;
                                                            alert("Berhasil");
        
                                                            $this.attr('disabled', false);
                                
                                                            cb_nama.val("--");
                                                            cb_nama.trigger('change');
                                                            document.getElementById('status_pembayaran').value = "--";
                                                            document.getElementById('keterangan').value = "";
                                                            document.getElementById('jumlah').value = "";
                                                            document.getElementById('total').value = "";
                                                            document.getElementById('kode_redeem_voucher').value = "";
                                                            document.getElementById('jumlah_voucher').value = "";
                                                            document.getElementById('kode_redeem_voucher').disabled = true;
                                                            document.getElementById('jumlah_voucher').disabled = true;
                                                            document.getElementById('total_pembayaran_print').innerHTML = "Rp 0,00";
                                                            document.getElementById('sisa_voucher_text').style.display = "none";
                                                            document.getElementById('sisa_voucher_print').style.display = "none";
                                                            document.getElementById('sisa_voucher_print').innerHTML = 0;
                                
                                                            showDataPembelian(id_plant, id_akses);
                
                                                            getStock(id_plant, function(result){
                                                                document.getElementById('stock_now').innerHTML = result[0].stock;
                    
                                                                if(result[0].stock <= 0){
                                                                    // console.log("here");
                                                                    document.getElementById('nama_user').disabled = true;
                                                                    document.getElementById('jumlah').disabled = true;
                                                                    document.getElementById('status_pembayaran').disabled = true;
                                                                    document.getElementById('keterangan').disabled = true;
                                                                    document.getElementById('jumlah_voucher').disabled = true;
                                                                    document.getElementById('kode_redeem_voucher').disabled = true;
                                                            
                                                                    alert("Stock Product Habis, Harap Melakukan Restock Kembali!");
                                                                }
                                                            });
                                                        }else{
                                                            // alert(result);
                                                            // console.log(result);
                                                            alert("Hubungi Pihak Automation Error #001");
                                                        }
                                                    });  
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                }
            });
            
            cb_nama.on('change', function (e) {
                var nama_pembeli = cb_nama.val();
                var status_pembayaran_now =  document.getElementById('status_pembayaran').value;
                if(status_pembayaran_now === "Voucher"){
                    document.getElementById("loading").hidden = false;
                    cekPunyaVoucher(nama_pembeli, function(voucher){
                        if(voucher[0].has_voucher === "n"){
                            document.getElementById("loading").hidden = true;
                            alert("User Tidak Memiliki Voucher!")
                            document.getElementById('jumlah_voucher').disabled = true;
                            document.getElementById('kode_redeem_voucher').disabled = true;
                            document.getElementById('status_pembayaran').value = "--";
                        }else{
                            getDataUser(nama_pembeli, function(data){

                                if(data[0].status_karyawan === "NON PERMANENT" && data[0].id_pic !== '998'){
                                    document.getElementById("loading").hidden = true;
                                    alert("Silahkan Menggunakan User : VOUCHER " + data[0].vendor);
                                    document.getElementById('jumlah_voucher').disabled = true;
                                    document.getElementById('kode_redeem_voucher').disabled = true;
                                    document.getElementById('status_pembayaran').value = "--";
                                }else{
                                    cekSisaVoucher(nama_pembeli, function(result){
                                        // console.log(result);
                                        var sisa_voucher = parseInt(result[0].Target);
                                        if(result[0].Voucher === null){
                                            var voucher_redeem = 0;
                                        }else{
                                            var voucher_redeem = parseInt(result[0].Voucher);
                                        }
            
                                        sisa_voucher = sisa_voucher - voucher_redeem;
    
                                        // if(data[0].status_karyawan == "NON PERMANENT" && sisa_voucher <= 0){
                                        //     sisa_voucher = 0;
                                        // }
            
                                        if(sisa_voucher <= 0){
                                            console.log(sisa_voucher);
                                            document.getElementById("loading").hidden = true;
                                            alert("User Sudah Mengclaim Semua Voucher");
                                            document.getElementById('jumlah_voucher').disabled = true;
                                            document.getElementById('kode_redeem_voucher').disabled = true;
                                            document.getElementById('status_pembayaran').value = "--";
                                            document.getElementById('sisa_voucher_print').innerHTML = "0";
                                        }else{
                                            document.getElementById("loading").hidden = true;
                                            document.getElementById('sisa_voucher_print').innerHTML = sisa_voucher;
                                        }
                                    });
                                }

                            });
                        }
                    });
                }
            });

            $('#status_pembayaran').on('change', function (e) {
                var nama_pembeli = cb_nama.val();
                // console.log(nama_pembeli);
                document.getElementById("loading").hidden = false;
                if(this.value === "Voucher"){
                    document.getElementById('jumlah_voucher').disabled = false;
                    document.getElementById('kode_redeem_voucher').disabled = false;
                    document.getElementById('sisa_voucher_text').style.display = "block";
                    document.getElementById('sisa_voucher_print').style.display = "block";
                    document.getElementById('sisa_voucher_print').innerHTML = 0;
                    if(nama_pembeli !== "--"){
                        cekPunyaVoucher(nama_pembeli, function(voucher){
                            // document.getElementById("loading").style.display = "block";
                            if(voucher[0].has_voucher === "n"){
                                document.getElementById("loading").hidden = true;
                                document.getElementById("loading").style.display = "";
                                alert("User Tidak Memiliki Voucher!")
                                document.getElementById('jumlah_voucher').disabled = true;
                                document.getElementById('kode_redeem_voucher').disabled = true;
                                document.getElementById('status_pembayaran').value = "--";
                            }else{
                                getDataUser(nama_pembeli, function(data){
                                    // console.log(data);

                                    if(data[0].status_karyawan === "NON PERMANENT" && data[0].id_pic !== '998'){
                                        document.getElementById("loading").hidden = true;
                                        // document.getElementById("loading").style.display = "";
                                        alert("Silahkan Menggunakan User : VOUCHER " + data[0].vendor);
                                        document.getElementById('jumlah_voucher').disabled = true;
                                        document.getElementById('kode_redeem_voucher').disabled = true;
                                        document.getElementById('status_pembayaran').value = "--";
                                    }else{
                                        cekSisaVoucher(nama_pembeli, function(result){
                                            // console.log(result);
    
                                            // console.log(data);
                                            var sisa_voucher = parseInt(result[0].Target);
                                            if(sisa_voucher === 0){
                                                sisa_voucher = 4;
                                            }
            
                                            if(result[0].Voucher === null){
                                                var voucher_redeem = 0;
                                            }else{
                                                var voucher_redeem = parseInt(result[0].Voucher);
                                            }
            
                                            sisa_voucher = sisa_voucher - voucher_redeem;
    
                                            // if(data[0].status_karyawan == "NON PERMANENT" && sisa_voucher <= 0){
                                            //     sisa_voucher = 0;
                                            // }
    
                                            // console.log(sisa_voucher);
            
                                            if(sisa_voucher <= 0){
                                                document.getElementById("loading").hidden = true;
                                                // document.getElementById("loading").style.display = "";
                                                alert("User Sudah Mengclaim Semua Voucher")
                                                document.getElementById('jumlah_voucher').disabled = true;
                                                document.getElementById('kode_redeem_voucher').disabled = true;
                                                document.getElementById('status_pembayaran').value = "--";
                                            }else{
                                                document.getElementById("loading").hidden = true;
                                                // document.getElementById("loading").style.display = "";
                                                document.getElementById('sisa_voucher_print').innerHTML = sisa_voucher;
                                            }
            
                                            // console.log(sisa_voucher);
                                        });
                                    }
                                });
                            }
                        });
                    }
                }else{
                    jumlah_voucher = document.getElementById('jumlah_voucher').value; 
                    total_pembayaran = parseInt(document.getElementById("total").value);
                    document.getElementById('sisa_voucher_text').style.display = "none";
                    document.getElementById('sisa_voucher_print').style.display = "none";
                    document.getElementById('sisa_voucher_print').innerHTML = 0;
                    if(jumlah_voucher !== ""){
                        
                        tambahan = jumlah_voucher * 25000;
                        console.log(total_pembayaran);
                        console.log(tambahan);
                        total = total_pembayaran + tambahan;
        
                        convertedTotal = currencyConverter(total);
                        document.getElementById("total_pembayaran_print").innerHTML = convertedTotal;
                        document.getElementById('total').value = total;
                        // document.getElementById("loading").hidden = true;
                    }
        
                    document.getElementById('jumlah_voucher').value = "";
                    document.getElementById('kode_redeem_voucher').value = "";
        
                    document.getElementById('jumlah_voucher').disabled = true;
                    document.getElementById('kode_redeem_voucher').disabled = true;
                    document.getElementById("loading").hidden = true;S
                }
            });
        
            $('#status_pembayaran_edit').on('change', function (e) {
                if(this.value === "Voucher"){
                    document.getElementById('jumlah_voucher_edit').disabled = false;
                    document.getElementById('kode_voucher_edit').disabled = false;
                }else{
                    jumlah_voucher = document.getElementById('jumlah_voucher_edit').value; 
                    total_pembayaran = parseInt(document.getElementById("total_edit").value);
        
                    if(jumlah_voucher !== ""){
                        
                        tambahan = jumlah_voucher * 25000;
                        console.log(total_pembayaran);
                        console.log(tambahan);
                        total = total_pembayaran + tambahan;
        
                        convertedTotal = currencyConverter(total);
                        document.getElementById("total_pembayaran_edit_print").innerHTML = convertedTotal;
                        document.getElementById('total_edit').value = total;
                    }
        
                    document.getElementById('jumlah_voucher_edit').value = "";
                    document.getElementById('kode_voucher_edit').value = "";
        
                    document.getElementById('jumlah_voucher_edit').disabled = true;
                    document.getElementById('kode_voucher_edit').disabled = true;
                }
            });
        
            $('#jumlah').on('input', function (e) {
                jumlah = document.getElementById('jumlah').value; 
                jumlah_voucher = document.getElementById('jumlah_voucher').value; 
        
                // console.log(jumlah * 27000);
                getHarga(function(harga){
                    total = jumlah * harga;
        
                    if(jumlah_voucher !== ""){
                        potongan = jumlah_voucher * 25000;
                        total = total - potongan;
                        document.getElementById("total").value = total;
                        convertedTotal = currencyConverter(total);
                        document.getElementById("total_pembayaran_print").innerHTML = convertedTotal;
                        // console.log(currencyConverter(total));
                    }else{
                        document.getElementById("total").value = total;
                        convertedTotal = currencyConverter(total);
                        document.getElementById("total_pembayaran_print").innerHTML = convertedTotal;
                        // console.log(currencyConverter(total));
                    }
        
                });
        
                // console.log("coba");
            });
        
            $('#jumlah_edit').on('input', function (e) {
                jumlah = document.getElementById('jumlah_edit').value; 
                jumlah_voucher = document.getElementById('jumlah_voucher_edit').value; 
        
                // console.log(jumlah * 27000);
                getHarga(function(harga){
                    total = jumlah * harga;
        
                    if(jumlah_voucher !== ""){
                        potongan = jumlah_voucher * 25000;
                        total = total - potongan;
                        document.getElementById("total_edit").value = total;
                        convertedTotal = currencyConverter(total);
                        document.getElementById("total_pembayaran_edit_print").innerHTML = convertedTotal;
                        // console.log(currencyConverter(total));
                    }else{
                        document.getElementById("total_edit").value = total;
                        convertedTotal = currencyConverter(total);
                        document.getElementById("total_pembayaran_edit_print").innerHTML = convertedTotal;
                        // console.log(currencyConverter(total));
                    }
        
                });
        
                // console.log("coba");
            });
        
            $('#jumlah_voucher').on('input', function (e) {
                var nama_pembeli = cb_nama.val();
                jumlah_voucher = document.getElementById('jumlah_voucher').value; 
                total_pembayaran = document.getElementById("total").value;
                jumlah = document.getElementById('jumlah').value; 
                sisa_voucher_now = document.getElementById('sisa_voucher_print').innerHTML; 
                sisa_voucher_now = parseInt(sisa_voucher_now);
                sisa_voucher_now = sisa_voucher_now - jumlah_voucher;
                console.log(sisa_voucher_now);
        
                if(this.value === ""){
                    getHarga(function(harga){
                        total = jumlah * harga;
                        console.log(jumlah + " - " + harga);
                        document.getElementById("total").value = total;
                        convertedTotal = currencyConverter(total);
                        document.getElementById("total_pembayaran_print").innerHTML = convertedTotal;
                    });
                }else{
                    console.log(sisa_voucher_now);
                    getDataUser(nama_pembeli, function(result){
                        if(sisa_voucher_now < 0 && result[0].status_karyawan !== 'NON PERMANENT'){
                            alert("Anda Melebihi Dari Jumlah Voucher Yang Bisa Digunakan!/n" + "Jumlah Voucher yang Mau Diclaim : " + jumlah_voucher);
                            flag_dont_accept = true;
                            document.getElementById("jumlah_voucher").value = "";
                        }else{
                            flag_dont_accept = false;
                            potongan = jumlah_voucher * 25000;
                            total = total_pembayaran - potongan;
                            console.log(total_pembayaran + " - " + potongan);
                            document.getElementById("total").value = total;
                            convertedTotal = currencyConverter(total);
                            document.getElementById("total_pembayaran_print").innerHTML = convertedTotal;
                        }
                    });
                }
            });
        
            $('#jumlah_voucher_edit').on('input', function (e) {
                jumlah_voucher = document.getElementById('jumlah_voucher_edit').value; 
                total_pembayaran = document.getElementById("total_edit").value;
                jumlah = document.getElementById('jumlah_edit').value; 
        
                if(this.value === ""){
                    getHarga(function(harga){
                        total = jumlah * harga;
                        console.log(jumlah + " - " + harga);
                        document.getElementById("total_edit").value = total;
                        convertedTotal = currencyConverter(total);
                        document.getElementById("total_pembayaran_edit_print").innerHTML = convertedTotal;
                    });
                }else{
                    potongan = jumlah_voucher * 25000;
                    total = total_pembayaran - potongan;
                    console.log(total_pembayaran + " - " + potongan);
                    document.getElementById("total_edit").value = total;
                    convertedTotal = currencyConverter(total);
                    document.getElementById("total_pembayaran_edit_print").innerHTML = convertedTotal;
                }
            }); 
        }
    }else{
        $('#table_pembelian_koperasi').on('click', 'tbody tr', function() {
            dataFromId = this.id.split("_");
            idPembelianSelected = dataFromId[0];
            ttlPembayaranReal = dataFromId[1];
            var dataPembelian = tbl_pembelian_koperasi.row( this ).data();
            namaEdit = dataPembelian[1];
            statusPembayaran = dataPembelian[2];
            jumlahPesanan = dataPembelian[4];
            ketPesanan = dataPembelian[5];
            ttlPembayaran = dataPembelian[6];
            kodeVoucher = dataPembelian[7];
            jmlVoucher = dataPembelian[8];
    
            document.getElementById('id_pembelian_edit').innerHTML = "";
            document.getElementById('nama_edit').innerHTML = "";

            document.getElementById('id_pembelian_edit').innerHTML = idPembelianSelected;
            document.getElementById('nama_edit').innerHTML = namaEdit;
            
            $('#modal_data_pembelian').modal('show');
        });
        
        $('#save_edit_pembelian').on('click', function() {
            var status_cek = false;
            id_edit = document.getElementById('id_pembelian_edit').innerHTML;
            sts_pay_edit = document.getElementById('status_pembayaran_edit').value;
            jml_edit = document.getElementById('jumlah_edit').value;
            ket_edit = document.getElementById('ket_edit').value;
            kode_voucher_edit = document.getElementById('kode_voucher_edit').value;
            jml_voucher_edit = document.getElementById('jumlah_voucher_edit').value;
    
            if(jp_before_edit !== jml_edit){
                status_cek = true;
            }
    
            if(sp_before_edit !== sts_pay_edit){
                status_cek = true;
            }
    
            if(k_before_edit !== ket_edit){
                status_cek = true;
            }
    
            if(jv_before_edit !== jml_voucher_edit){
                status_cek = true;
            }
    
            if(kv_before_edit !== kode_voucher_edit){
                status_cek = true;
            }
    
            if(status_cek === false){
                alert('Tidak Ada Data yang Dirubah!');
            }else{
                if(sts_pay_edit === "--"){
                    alert('Harap Memilih Status Pembayaran!');
                }else{
                    if(jml_edit === ""){
                        alert('Harap Mengisi Jumlah Pesanan!');
                    }else{
                        if(sts_pay_edit === "Voucher" && jml_voucher_edit === ""){
                            alert('Harap Mengisi Jumlah Voucher!');
                        }else{
                            if(sts_pay_edit === "Voucher" && kode_voucher_edit === ""){
                                alert('Harap Mengisi Kode Voucher!');
                            }else{
                                updatePembelian(id_edit, sts_pay_edit, jml_edit, ket_edit, kode_voucher_edit, function(result){
                                    showDataPembelian(id_plant, id_akses);
                                });
                                $('#modal_data_pembelian').modal('hide');
                            }
                        }
                    }
                }
            }
        });
    
        $('#delete_pembelian').on('click', function() {
            id_delete = document.getElementById('id_pembelian_edit').innerHTML;
    
            konfirmasiDelete = confirm('Apakah Anda Yakin Untuk Menghapus Data ?');
    
            if(konfirmasiDelete === true){
                deletePembelian(id_delete, id_plant,  function(result){
                    showDataPembelian(id_plant, id_akses);
                });
                $('#modal_data_pembelian').modal('hide');
            }
            
        });
    }


});

function getHarga(callback){
    $.ajax({
        url: '../Pembelian/getHargaProduk',
        type: 'POST',
        dataType: 'json',
        success: function(data){
            // console.log(data);
            callback(data);
        },
        error: function() {
            alert("error getHarga");
        }
    });
}

function deletePembelian(id_pembelian_del, id_plant, callback){
    $.ajax({
        url: '../Pembelian/deletePembelian',
        type: 'POST',
        dataType: 'json',
        data: {
            id_pembelian_del : id_pembelian_del,
            id_plant : id_plant
        },
        success: function(data){
            // console.log(data);
            callback(data);
        },
        error: function() {
            alert("error deletePembeliaan");
        }
    });
}

function insertPembelian(id_user, status_pembayaran, keterangan, jumlah, jumlah_voucher, kode_voucher, total_pembayaran, id_plant, callback){
    $.ajax({
        url: '../Pembelian/pembelian',
        type: 'POST',
        dataType: 'json',
        data: {
            id_user : id_user,
            status_pembayaran : status_pembayaran,
            keterangan : keterangan,
            jumlah : jumlah,
            kode_voucher : kode_voucher,
            jumlah_voucher : jumlah_voucher,
            total_pembayaran : total_pembayaran,
            id_plant : id_plant
        },
        success: function(data){
            // console.log(data);
            callback(data);
        },
        error: function() {
            alert("error insertPembelian");
        }
    });
}

function updatePembelian(id_pembelian_edit, sts_pmbl_edit, jmlh_edit, keter_edit, kode_vouch_edit, callback){
    $.ajax({
        url: '../Pembelian/updatePembelian',
        type: 'POST',
        dataType: 'json',
        data: {
            id_pembelian_edit : id_pembelian_edit,
            sts_pmbl_edit : sts_pmbl_edit,
            jmlh_edit : jmlh_edit,
            keter_edit : keter_edit,
            kode_vouch_edit : kode_vouch_edit
        },
        success: function(data){
            // console.log(data);
            callback(data);
        },
        error: function() {
            alert("error updatePembelian");
        }
    });
}

function showDataPembelian(id_plant, id_akses){
    // console.log(id_akses);
    $.ajax({
        url: '../Pembelian/showDataPembelian',
        type: 'POST',
        dataType: 'json',
        data: {
            id_plant : id_plant,
            id_akses : id_akses
        },
        success: function(data){
            document.getElementById("loading2").hidden = false;
            // callback(data);
            tbl_pembelian.clear().draw();
            var i;
            for(i=0; i<data.length; i++){
                tbl_pembelian.row.add([
                    data[i].id_pembelian, 
                    data[i].nama_user, 
                    data[i].status_pembayaran, 
                    data[i].tgl_pembelian,
                    data[i].jumlah,
                    data[i].keterangan,
                    currencyConverter(data[i].total_pembayaran),
                    data[i].kode_voucher,
                    data[i].jumlah_voucher
                ]).node().id = data[i].id_pembelian + "_" + data[i].total_pembayaran;
                tbl_pembelian.draw();
            }
            // document.getElementById("loading").style.display = "";
            document.getElementById("loading").hidden = true;
            document.getElementById("loading2").hidden = true;
        },
        error: function() {
            alert("error showDataPembelian");
        }
    });
}

function showDataPembelianKoperasi(id_plant, id_akses){
    // console.log(id_akses);
    // console.log("test");
    $.ajax({
        url: '../Pembelian/showDataPembelianKoperasi',
        type: 'POST',
        dataType: 'json',
        data: {
            id_plant : id_plant,
            id_akses : id_akses
        },
        success: function(data){
            console.log(data);
            // callback(data);
            tbl_pembelian_koperasi.clear().draw();
            var i;
            for(i=0; i<data.length; i++){
                tbl_pembelian_koperasi.row.add([
                    data[i].id_pembelian, 
                    data[i].nama_user, 
                    data[i].status_pembayaran, 
                    data[i].tgl_pembelian,
                    data[i].jumlah,
                    data[i].keterangan,
                    currencyConverter(data[i].total_pembayaran),
                    data[i].kode_voucher,
                    data[i].jumlah_voucher
                ]).node().id = data[i].id_pembelian + "_" + data[i].total_pembayaran;
                tbl_pembelian_koperasi.draw();
            }
            document.getElementById("loading3").hidden = true;
        },
        error: function() {
            alert("error showDataPembelianKoperasi");
        }
    });
}

function currencyConverter(uang){
    return new Intl.NumberFormat("id-ID", {
        style: "currency",
        currency: "IDR"
    }).format(uang);
}

function getStock(id_plant, callback){
    $.ajax({
        url: '../Pembelian/getStock',
        type: 'POST',
        dataType: 'json',
        data: {
            id_plant : id_plant
        },
        success: function(data){
            callback(data);
        },
        error: function() {
            alert("error getStock");
        }
    });
}

function cekSisaVoucher(id_pembeli, callback){
    $.ajax({
        url: '../Pembelian/cekSisaVoucher',
        type: 'POST',
        dataType: 'json',
        data: {
            id_pembeli : id_pembeli
        },
        success: function(data){
            callback(data);
            // console.log(data);
        },
        error: function() {
            alert("error cekSisaVoucher");
        }
    });
}

function cekPunyaVoucher(id_pembeli, callback){
    $.ajax({
        url: '../Pembelian/cekPunyaVoucher',
        type: 'POST',
        dataType: 'json',
        data: {
            id_pembeli : id_pembeli
        },
        success: function(data){
            callback(data);
        },
        error: function() {
            alert("error cekSisaVoucher");
        }
    });
}

function getDataUser(id_pembeli, callback){
    $.ajax({
        url: '../Pembelian/statusUser',
        type: 'POST',
        dataType: 'json',
        data: {
            id_pembeli : id_pembeli
        },
        success: function(data){
            callback(data);
        },
        error: function() {
            alert("error cekSisaVoucher");
        }
    });
}
