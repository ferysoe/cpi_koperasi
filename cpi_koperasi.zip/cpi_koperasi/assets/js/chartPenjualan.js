$(document).ready( function () {
    const ctx = document.getElementById('myChart');
    document.getElementById("loading").hidden = true;

    getDataPerVendor(function(result){
        var data_label = [];
        var data_pembelian_ayam = [];
        var data_target = [];
        var data_cash = [];
        var data_voucher = [];
        var data_payroll = [];
        var datasets_data = [];
        var label_datasets = ["Pembelian Ayam", "Target", "Cash", "Voucher", "Payroll"];

        // console.log(label_datasets[0]);

        for(i=0; i<result.length; i++){
            data_label.push(result[i].vendor);
            data_pembelian_ayam.push(result[i].jumlah);
            data_target.push(result[i].target);
            data_cash.push(result[i].cash);
            data_voucher.push(result[i].voucher);
            data_payroll.push(result[i].payroll);
        }

        var dataset_all = [data_pembelian_ayam, data_target, data_cash, data_voucher, data_payroll];

        for(i=0; i<5; i++){
            var randomColor = Math.floor(Math.random()*16777215).toString(16);
            var color_val = "#" + randomColor;
        
            var datasets_pass = {
                label: label_datasets[i],
                data: dataset_all[i],
                borderWidth: 1,
                borderColor: color_val,
                backgroundColor: color_val
            }

            datasets_data.push(datasets_pass);
        }

        new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data_label,
            datasets: datasets_data
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
        });

    });
});

function getDataPerVendor(callback){
    $.ajax({
        url: '../cpi_koperasi/ChartPenjualan/getDataPerVendor',
        type: 'POST',
        dataType: 'json',
        success: function(data){
            // console.log(data);
            callback(data);
        },
        error: function() {
            alert("error getHarga");
        }
    });
}