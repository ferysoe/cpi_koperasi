var table_report = $('#table_data_user');

var filter = "none";

$(document).ready( function () {
    table_report.DataTable({
        columns: [
            { "width": "15%" },
            { "width": "15%" },
            { "width": "15%" },
            { "width": "15%" },
            { "width": "15%" },
            { "width": "15%" },
        ],
        order: [[2, 'asc']],
        ordering: true
    });
});
