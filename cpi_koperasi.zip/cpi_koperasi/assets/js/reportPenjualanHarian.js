var table_report = $('#table_data_user');

var filter = "none";

$(document).ready( function () {
    table_report.DataTable({
        columns: [
            { "width": "10%" },
            { "width": "15%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "10%" },
            { "width": "5%" },
            { "width": "10%" },
            { "width": "10%" }
        ],
        order: [[0, 'asc']],
        ordering: true
    });
});
