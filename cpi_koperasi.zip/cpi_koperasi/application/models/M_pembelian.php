<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_pembelian extends CI_Model
{
    public function __construct(){
        $this->load->database();
    }

    function getStock($id_plant){
        $this->db->select('stock');
        $this->db->from('product');
        $this->db->where('nama_produk', 'Ayam Karkas 800 - 900 Gram');
        $this->db->where('id_plant', $id_plant);
        return $this->db->get();
    }

    function getHarga($id_plant){
        $this->db->select('harga');
        $this->db->from('product');
        $this->db->where('nama_produk', 'Ayam Karkas 800 - 900 Gram');
        $this->db->where('id_plant', $id_plant);
        return $this->db->get();
    }

    function getDataPembelian(){
        $this->db->select('*');
        $this->db->from('master_pembelian');
        $this->db->order_by('tgl_pembelian', 'DESC');
        return $this->db->get();
    }

    function showDataPembelian($id_plant){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama_user,
                        mp.status_pembayaran AS status_pembayaran,
                        mp.tgl_pembelian AS tgl_pembelian,
                        mp.jumlah AS jumlah,
                        mp.keterangan AS keterangan,
                        mp.total_pembayaran AS total_pembayaran,
                        mp.kode_redeem_voucher AS kode_voucher,
                        mp.jumlah_voucher_redeem AS jumlah_voucher
                    FROM 
                        master_pembelian AS mp, 
                        master_user AS mu 
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_konfirmasi = '0' AND
                        mu.id_plant = '" . $id_plant . "'
                    ORDER BY
                        mp.tgl_pembelian
                    LIMIT 500
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function showDataPembelian2($id_plant){
        if($id_plant == "1742"){
            $query = "  SELECT 
                            mp.id_pembelian AS id_pembelian,
                            mu.nama AS nama_user,
                            mp.status_pembayaran AS status_pembayaran,
                            mp.tgl_pembelian AS tgl_pembelian,
                            mp.jumlah AS jumlah,
                            mp.keterangan AS keterangan,
                            mp.total_pembayaran AS total_pembayaran,
                            mp.kode_redeem_voucher AS kode_voucher,
                            mp.jumlah_voucher_redeem AS jumlah_voucher
                        FROM 
                            master_pembelian AS mp, 
                            master_user AS mu 
                        WHERE 
                            mp.id_user = mu.id_user AND
                            mp.status_konfirmasi = '0' AND
                            mu.id_plant = '1742' OR
                            mu.id_plant = '1961'
                        ORDER BY
                            mp.tgl_pembelian
                            ";
        }else{

        }

        $result = $this->db->query($query);
        return $result;
    }

    function showDataPembelianAll(){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama_user,
                        mp.status_pembayaran AS status_pembayaran,
                        mp.tgl_pembelian AS tgl_pembelian,
                        mp.jumlah AS jumlah,
                        mp.keterangan AS keterangan,
                        mp.total_pembayaran AS total_pembayaran,
                        mp.kode_redeem_voucher AS kode_voucher,
                        mp.jumlah_voucher_redeem AS jumlah_voucher
                    FROM 
                        master_pembelian AS mp, 
                        master_user AS mu 
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_konfirmasi = '0' AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                    ORDER BY
                        mp.tgl_pembelian DESC
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function showDataPembelianAllKoperasi(){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama_user,
                        mp.status_pembayaran AS status_pembayaran,
                        mp.tgl_pembelian AS tgl_pembelian,
                        mp.jumlah AS jumlah,
                        mp.keterangan AS keterangan,
                        mp.total_pembayaran AS total_pembayaran,
                        mp.kode_redeem_voucher AS kode_voucher,
                        mp.jumlah_voucher_redeem AS jumlah_voucher
                    FROM 
                        master_pembelian AS mp, 
                        master_user AS mu 
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_konfirmasi = '0' AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                    ORDER BY
                        mp.tgl_pembelian DESC
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function insertDataPembelian($id_pembelian, $id_user, $status_pembayaran, $jumlah, $status_konfirmasi, $keterangan, $total_pembayaran, $redeem_voucher, $jumlah_voucher, $total_harga_ayam, $id_plant){
        $data = array(
            'id_pembelian' => $id_pembelian,
            'id_user' => $id_user,
            'status_pembayaran' => $status_pembayaran,
            'jumlah' => $jumlah,
            'status_konfirmasi' => $status_konfirmasi,
            'keterangan' => $keterangan,
            'tgl_konfirmasi' => null,
            'total_pembayaran' => $total_pembayaran,
            'kode_redeem_voucher' => $redeem_voucher,
            'total_harga_ayam' => $total_harga_ayam,
            'jumlah_voucher_redeem' => $jumlah_voucher,
            'id_plant_pembelian' => $id_plant
        );
        
        return $this->db->insert('master_pembelian', $data);
    }

    // function getDataUser2($id_plant){
    //     $this->db->select('*');
    //     $this->db->from('master_user');
    //     $this->db->where('id_plant', $id_plant);
    //     // if($id_plant == "1742"){
    //     //     $this->db->where('id_plant', "1961");
    //     // }
    //     $this->db->where('id_akses <', '3');
    //     $this->db->where('aktif', 'AKTIF');
    //     return $this->db->get();
    // }

    function getHargaProduct(){
        $this->db->select('*');
        $this->db->from('product');
        $this->db->where('id_product', '1');
        return $this->db->get();
    }

    function getVoucher($id_user){
        $this->db->select('voucher');
        $this->db->from('master_user');
        $this->db->where('id_user', $id_user);
        return $this->db->get();
    }

    function deletePembelian($id_pembelian){
        $this->db->where('id_pembelian', $id_pembelian);
        return $this->db->delete('master_pembelian');
    }

    function updatePembelian($id_pembelian_edit, $sts_pembayaran, $jmlh_edit, $ket_edit, $total_pembayaran_edit, $kode_voucher_edit){
        $data = array(
            'status_pembayaran' => $sts_pembayaran,
            'jumlah' => $jmlh_edit,
            'keterangan' => $ket_edit,
            'total_pembayaran' => $total_pembayaran_edit,
            'kode_redeem_voucher' => $kode_voucher_edit
        );

        $this->db->where('id_pembelian', $id_pembelian_edit);
        return $this->db->update('master_pembelian', $data);
    }

    function updateStock($id_plant, $stock){
        $data = array(
            'stock' => $stock
        );

        $this->db->where('id_plant', $id_plant);
        $this->db->where('nama_produk', 'Ayam Karkas 800 - 900 Gram');
        return $this->db->update('product', $data);
    }

    function cekPicUser($id_user){
        $this->db->select('id_pic, vendor, id_plant');
        $this->db->from('master_user');
        $this->db->where('id_user', $id_user);
        return $this->db->get();
    }

    function cekSisaVoucher($id_pembeli){
        $query = "  SELECT  
                        IF(SUM(mp.jumlah_voucher_redeem) IS NULL, 0, SUM(mp.jumlah_voucher_redeem)) AS Voucher,
                        (
                            SELECT 
                                mu.target
                            FROM
                                master_user AS mu
                            WHERE
                                mu.id_user = '" . $id_pembeli . "'
                        ) AS Target
                    FROM 
                        master_pembelian AS mp
                    WHERE 
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                        mp.id_user = '" . $id_pembeli . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function cekSisaVoucherVendor($vendor, $plant){
        $query = "  SELECT
                        (
                            SELECT
                                IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah))
                            FROM
                                master_pembelian AS mp,
                                master_user AS mu2
                            WHERE
                                mp.id_user = mu2.id_user AND
                                mu2.vendor = '" . $vendor . "' AND
                                mu2.id_plant = '" . $plant . "' AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                                mp.status_pembayaran = 'Voucher'
                        ) AS Voucher,
                        (
                            SELECT
                                SUM(mu.target) AS Target
                            FROM
                                master_user AS mu
                            WHERE
                                mu.aktif = 'AKTIF' AND
                                mu.vendor = '" . $vendor . "' AND
                                mu.id_plant = '" . $plant . "'
                        ) AS Target
                    ";

        $result = $this->db->query($query);
        return $result;
    }

    function cekPunyaVoucher($id_pembeli){
        $this->db->select('has_voucher');
        $this->db->from('master_user');
        $this->db->where('id_user', $id_pembeli);
        return $this->db->get();
    }

    // function getDataUser3($id_plant){
    //     if($id_plant === "1742"){
    //         $query = "  SELECT 
    //                         * 
    //                     FROM 
    //                         master_user AS mu 
    //                     WHERE 
    //                         mu.id_akses < 3 AND 
    //                         mu.aktif = 'AKTIF'
    //                 ";
    //     }else{
    //         $query = "  SELECT  
    //                         *
    //                     FROM 
    //                         master_user AS mu
    //                     WHERE
    //                         mu.id_akses < 3 AND
    //                         mu.aktif = 'AKTIF'
    //                 ";
    //     }
    //     $result = $this->db->query($query);
    //     return $result;
    // }

    function getDataUser($id_plant){
        
        if($id_plant == "1742"){
            $filter = "mu.id_plant in ('1742', '1961')";
        }else{
            $filter = "mu.id_plant = '1741'";
        }

        $query = "  SELECT 
                        mu.id_user AS id_user,
                        mu.nama AS nama,
                        mu.no_reg AS no_reg,
                        mv.nama AS vendor
                    FROM 
                        master_user AS mu,
                        master_vendor AS mv
                    WHERE 
                        mv.id = mu.vendor AND
                        mu.id_akses < 3 AND 
                        mu.aktif = 'AKTIF' AND
                        mu.id_pic <> '998'
                    UNION
                    SELECT 
                        mu.id_user AS id_user,
                        mu.nama AS nama,
                        mu.no_reg AS no_reg,
                        mv.nama AS vendor
                    FROM 
                        master_user AS mu,
                        master_vendor AS mv
                    WHERE 
                        mv.id = mu.vendor AND
                        mu.id_akses < 3 AND 
                        mu.aktif = 'AKTIF' AND
                        mu.id_pic = '998' AND
                        " . $filter;
        
        $result = $this->db->query($query);
        return $result;
    }

    function getJumlahperDataPembelian($id_pembelian){
        $this->db->select('jumlah, id_plant_pembelian');
        $this->db->from('master_pembelian');
        $this->db->where('id_pembelian', $id_pembelian);
        return $this->db->get();
    }

    function getLastPembelian(){
        $query = "  SELECT 
                        * 
                    FROM 
                        master_pembelian AS mp 
                    ORDER BY
                        mp.tgl_pembelian DESC
                    LIMIT 5
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function statusUser($id_user){
        $query = "  SELECT 
                        mu.status_karyawan AS status_karyawan,
                        mu.id_pic AS id_pic,
                        mv.nama AS vendor
                    FROM 
                        master_user AS mu,
                        master_vendor AS mv
                    WHERE 
                        mv.id = mu.vendor AND
                        mu.id_user = '" . $id_user . "'
                ";
        
        $result = $this->db->query($query);
        return $result;
    }
}