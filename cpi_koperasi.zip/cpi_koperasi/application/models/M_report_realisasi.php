<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_report_realisasi extends CI_Model
{
    function get_user()	{
		return $this->db->get('master_user');
	}

    function get_plant()	{
		return $this->db->get('master_plant');
	}

    function get_akses()	{
		return $this->db->get('master_akses');
	}

    function get_pic()	{
		return $this->db->get('master_pic');
	}

    function get_vendor()	{
		return $this->db->get('master_vendor');
	}

    function getDataUser($id_pic){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        return $this->db->get();
    }

    function getNamaVendor($vendor){
        $this->db->select('*');
        $this->db->from('master_vendor');
        $this->db->where('id', $vendor);
        return $this->db->get();
    }

    // function get_department(){
    //     $query = $this->db->query("SELECT DISTINCT departemen FROM `master_user` WHERE status_karyawan = 'PERMANENT'");
    //     $result = $this->db->query($query);
    //     return $result;
    // }

    function get_department(){
        $this->db->select('*');
        $this->db->from('master_department');
        return $this->db->get();
    }

    function dataRealisasiOS(){
        $query = "  SELECT
                        DISTINCT mpl.keterangan AS plant,
                        mv.keterangan AS vendor,
                        (
                            SELECT
                                IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah))
                            FROM
                                master_pembelian AS mp,
                                master_user AS mu2
                            WHERE
                                mp.id_user = mu2.id_user AND
                                mu2.vendor = mu.vendor AND
                                mu2.id_plant = MU.id_plant AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS realisasi,
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM
                        master_user AS mu,
                        master_vendor AS mv,
                        master_plant AS mpl
                    WHERE
                        mu.vendor = mv.id AND
                        mu.id_plant = mpl.id_plant AND
                        mu.status_karyawan = 'NON PERMANENT'
                    GROUP BY
                        mu.id_plant,
                        mu.vendor
                    ORDER BY
                        mu.id_plant,
                        mu.vendor
                    ";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiOS(){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.status_karyawan = 'NON PERMANENT' AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                    ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetOS(){
        $query = "  SELECT 
                        SUM(mu.target) AS target
                    FROM 
                        master_user AS mu
                    WHERE 
                        mu.aktif = 'AKTIF' AND
                        mu.status_karyawan = 'NON PERMANENT'
                    ";

        $result = $this->db->query($query);
        return $result;
    }

    // ======================================== VENDOR ======================================== // 

    function dataVendor($vendor){
        $query = " SELECT 
                        mu.nama AS nama,
                        mu.no_reg AS noreg,
                        mv.nama AS vendor,
                        mu.departemen AS department,
                        (
                            SELECT
                                SUM(mp.jumlah) as jml
                            FROM
                                master_pembelian AS mp
                            WHERE
                                mp.id_user = mu.id_user AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS realisasi,
                        mu.target AS target,
                        mu.id_plant AS plant
                    FROM 
                        master_user AS mu,
                        master_vendor AS mv
                    WHERE
                        mu.vendor = mv.id AND
                        mu.vendor = '" . $vendor . "'";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendor_realisasi($vendor){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                        mu.vendor = '" . $vendor . "'";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendor_target($vendor){
        $query = "  SELECT 
                        SUM(mu.target) AS target
                    FROM 
                        master_user AS mu
                    WHERE 
                        mu.aktif = 'AKTIF' AND
                        mu.vendor = '" . $vendor . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    // ======================================== DEPARTMENT ======================================== // 

    function dataDeptCPI(){
        $query = "  SELECT 
                        mu.nama AS nama,
                        mu.no_reg AS noreg,
                        mu.departemen AS department,
                        (
                            SELECT
                                SUM(mp.jumlah) as jml
                            FROM
                                master_pembelian AS mp
                            WHERE
                                mp.id_user = mu.id_user AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS realisasi,
                        mu.target AS target,
                        mu.id_plant AS plant
                    FROM 
                        master_user AS mu
                    WHERE
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.vendor = '5'
                        -- mu.aktif = 'AKTIF'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDept($department){
        $query = "  SELECT 
                        mu.nama AS nama,
                        mu.no_reg AS noreg,
                        mu.departemen AS department,
                        (
                            SELECT
                                SUM(mp.jumlah) as jml
                            FROM
                                master_pembelian AS mp
                            WHERE
                                mp.id_user = mu.id_user AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS realisasi,
                        mu.target AS target,
                        mu.id_plant AS plant
                    FROM 
                        master_user AS mu
                    WHERE
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDept_realisasi($department){
        $query = "  SELECT 
                       SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.status_karyawan = 'PERMANENT' AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                        mu.departemen = '" . $department . "' 
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptCPI_realisasi(){
        $query = "  SELECT 
                       SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.status_karyawan = 'PERMANENT' AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                        mu.vendor = '5'
                        -- mu.aktif = 'AKTIF'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDept_target($department){
        $query = "  SELECT 
                       SUM(mu.target) AS target
                    FROM 
                        master_user AS mu
                    WHERE 
                        mu.aktif = 'AKTIF' AND
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.departemen = '" . $department . "'  
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptCPI_target(){
        $query = "  SELECT 
                       SUM(mu.target) AS target
                    FROM 
                        master_user AS mu
                    WHERE 
                        mu.aktif = 'AKTIF' AND
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.vendor = '5'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    // ======================================== DEPARTMENT_VENDOR ======================================== // 

    function dataDeptVendor($department, $vendor){
        $query = "  SELECT 
                        mu.nama AS nama,
                        mu.no_reg AS noreg,
                        mv.nama AS vendor,
                        mu.departemen AS department,
                        (
                            SELECT
                                SUM(mp.jumlah) as jml
                            FROM
                                master_pembelian AS mp
                            WHERE
                                mp.id_user = mu.id_user AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS realisasi,
                        mu.target AS target,
                        mu.id_plant AS plant
                    FROM 
                        master_user AS mu,
                        master_vendor AS mv
                    WHERE
                        mu.vendor = mv.id AND
                        mu.vendor = '" . $vendor . "' AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptVendor_realisasi($department, $vendor){
        $query = "  SELECT 
                       SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                        mu.vendor = '" . $vendor . "' AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptVendor_target($department, $vendor){
        $query = "  SELECT 
                       SUM(mu.target) AS target
                    FROM 
                        master_user AS mu
                    WHERE 
                        mu.aktif = 'AKTIF' AND
                        mu.vendor = '" . $vendor . "' AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    // ============================================================================================= //

    function getDepartmentPerVendor($vendor){
        $query = "  SELECT DISTINCT
                        mu.departemen AS nama_department
                    FROM 
                        master_vendor AS mv,
                        master_user as mu
                    WHERE 
                        mu.vendor = mv.id AND
                        mv.id = '" . $vendor . "'
                    ORDER BY
                        mu.departemen
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataRealisasiGlobal(){
        $query = "  SELECT 
                        mu.nama AS nama,
                        mu.no_reg AS noreg,
                        mv.nama AS vendor,
                        mu.departemen AS department,
                        (
                            SELECT
                                SUM(mp.jumlah) as jml
                            FROM
                                master_pembelian AS mp
                            WHERE
                                mp.id_user = mu.id_user AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS realisasi,
                        mu.target AS target,
                        mu.id_plant AS plant
                    FROM 
                        master_user AS mu,
                        master_vendor AS mv
                    WHERE
                        mu.vendor = mv.id AND
                        mu.vendor <> 'none'
                    ORDER BY 
                        mu.vendor
                        ";

        $result = $this->db->query($query);
        return $result;
    }
}