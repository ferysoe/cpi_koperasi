<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_report extends CI_Model
{
    function get_user()	{
		return $this->db->get('master_user');
	}

    function get_plant()	{
		return $this->db->get('master_plant');
	}

    function get_akses()	{
		return $this->db->get('master_akses');
	}

    function get_pic()	{
		return $this->db->get('master_pic');
	}

    function get_vendor()	{
		return $this->db->get('master_vendor');
	}

    function getDataUser($id_pic){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        return $this->db->get();
    }

    function getNamaVendor($vendor){
        $this->db->select('*');
        $this->db->from('master_vendor');
        $this->db->where('id', $vendor);
        return $this->db->get();
    }

    // function get_department(){
    //     $query = $this->db->query("SELECT DISTINCT departemen FROM master_user");
    //     $result = $this->db->query($query);
    //     return $result;
    // }

    function get_department(){
        $this->db->select('*');
        $this->db->from('master_department');
        return $this->db->get();
    }

    function showDataPenjualan(){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama_user,
                        mp.status_pembayaran AS status_pembayaran,
                        mp.tgl_pembelian AS tgl_pembelian,
                        mp.jumlah AS jumlah,
                        mp.keterangan AS keterangan,
                        mp.total_pembayaran AS total_pembayaran
                    FROM 
                        master_pembelian AS mp, 
                        master_user AS mu 
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_konfirmasi = '0'
                    ORDER BY
                        mp.tgl_pembelian
                        ";

        $result = $this->db->query($query);
        return $result;
    }
    
    // ======================================== TANGGAL ======================================== // 

    function dataTanggal($start, $end){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama,
                        mp.tgl_pembelian AS tanggal,
                        mp.jumlah AS jumlah,
                        mp.total_pembayaran AS total,
                        mp.status_pembayaran AS jenis_pembayaran,
                        mp.keterangan AS keterangan,
                        mp.kode_redeem_voucher AS kode_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataTanggal_jumlahPenjualan($start, $end){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataTanggal_jumlahCash($start, $end){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah_cash
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Cash' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataTanggal_jumlahPayroll($start, $end){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah_payroll
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Payroll' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataTanggal_jumlahVoucher($start, $end){
        $query = "  SELECT 
                        SUM(mp.jumlah_voucher_redeem) AS jumlah_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataTanggal_jumlahUang($start, $end){
        $query = "  SELECT 
                        SUM(mp.total_pembayaran) AS jumlah_uang
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    // ======================================== DEPARTMENT_TANGGAL ======================================== // 

    function dataDeptTanggal($start, $end, $department){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama,
                        mp.tgl_pembelian AS tanggal,
                        mp.jumlah AS jumlah,
                        mp.total_pembayaran AS total,
                        mp.status_pembayaran AS jenis_pembayaran,
                        mp.keterangan AS keterangan,
                        mp.kode_redeem_voucher AS kode_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptTanggal_jumlahPenjualan($start, $end, $department){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptTanggal_jumlahCash($start, $end, $department){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah_cash
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Cash' AND
                        mu.departemen = '" . $department . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptTanggal_jumlahPayroll($start, $end, $department){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah_payroll
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Payroll' AND
                        mu.departemen = '" . $department . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptTanggal_jumlahVoucher($start, $end, $department){
        $query = "  SELECT 
                        SUM(mp.jumlah_voucher_redeem) AS jumlah_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptTanggal_jumlahUang($start, $end, $department){
        $query = "  SELECT 
                        SUM(mp.total_pembayaran) AS jumlah_uang
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    // ======================================== VENDOR ======================================== // 

    function dataVendor($vendor){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama,
                        mp.tgl_pembelian AS tanggal,
                        mp.jumlah AS jumlah,
                        mp.total_pembayaran AS total,
                        mp.status_pembayaran AS jenis_pembayaran,
                        mp.keterangan AS keterangan,
                        mp.kode_redeem_voucher AS kode_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.vendor = '" . $vendor . "'";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendor_jumlahPenjualan($vendor){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.vendor = '" . $vendor . "'";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendor_jumlahPayroll($vendor){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah_payroll
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Payroll' AND
                        mu.vendor = '" . $vendor . "'";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendor_jumlahCash($vendor){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah_cash
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Cash' AND
                        mu.vendor = '" . $vendor . "'";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendor_jumlahVoucher($vendor){
        $query = "  SELECT 
                        SUM(mp.jumlah_voucher_redeem) AS jumlah_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.vendor = '" . $vendor . "'";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendor_jumlahUang($vendor){
        $query = "  SELECT 
                        SUM(mp.total_pembayaran) AS jumlah_uang
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.vendor = '" . $vendor . "'";

        $result = $this->db->query($query);
        return $result;
    }

    // ======================================== VENDOR_TANGGAL ======================================== // 

    function dataVendorTanggal($vendor, $start, $end){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama,
                        mp.tgl_pembelian AS tanggal,
                        mp.jumlah AS jumlah,
                        mp.total_pembayaran AS total,
                        mp.status_pembayaran AS jenis_pembayaran,
                        mp.keterangan AS keterangan,
                        mp.kode_redeem_voucher AS kode_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendorTanggal_jumlahPenjualan($vendor, $start, $end){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendorTanggal_jumlahCash($vendor, $start, $end){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah_cash
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Cash' AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendorTanggal_jumlahPayroll($vendor, $start, $end){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah_payroll
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Payroll' AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendorTanggal_jumlahVoucher($vendor, $start, $end){
        $query = "  SELECT 
                        SUM(mp.jumlah_voucher_redeem) AS jumlah_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataVendorTanggal_jumlahUang($vendor, $start, $end){
        $query = "  SELECT 
                        SUM(mp.total_pembayaran) AS jumlah_uang
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    // ======================================== DEPARTMENT ======================================== // 

    function dataDept($department){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama,
                        mp.tgl_pembelian AS tanggal,
                        mp.jumlah AS jumlah,
                        mp.total_pembayaran AS total,
                        mp.status_pembayaran AS jenis_pembayaran,
                        mp.keterangan AS keterangan,
                        mp.kode_redeem_voucher AS kode_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDept_jumlahPenjualan($department){
        $query = "  SELECT 
                       SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDept_jumlahCash($department){
        $query = "  SELECT 
                       SUM(mp.jumlah) AS jumlah_cash
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Cash' AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDept_jumlahPayroll($department){
        $query = "  SELECT 
                       SUM(mp.jumlah) AS jumlah_payroll
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Payroll' AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDept_jumlahVoucher($department){
        $query = "  SELECT 
                       SUM(mp.jumlah_voucher_redeem) AS jumlah_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDept_jumlahUang($department){
        $query = "  SELECT 
                       SUM(mp.total_pembayaran) AS jumlah_uang
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    // ======================================== DEPARTMENT_VENDOR_TANGGAL ======================================== // 

    function dataDeptVendorTanggal($department, $vendor, $start, $end){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian,
                        mu.nama AS nama,
                        mp.tgl_pembelian AS tanggal,
                        mp.jumlah AS jumlah,
                        mp.total_pembayaran AS total,
                        mp.status_pembayaran AS jenis_pembayaran,
                        mp.keterangan AS keterangan,
                        mp.kode_redeem_voucher AS kode_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "' AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptVendorTanggal_jumlahPenjualan($department, $vendor, $start, $end){
        $query = "  SELECT 
                       SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "' AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptVendorTanggal_jumlahCash($department, $vendor, $start, $end){
        $query = "  SELECT 
                       SUM(mp.jumlah) AS jumlah_cash
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Cash' AND
                        mu.departemen = '" . $department . "' AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptVendorTanggal_jumlahPayroll($department, $vendor, $start, $end){
        $query = "  SELECT 
                       SUM(mp.jumlah) AS jumlah_payroll
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mp.status_pembayaran = 'Payroll' AND
                        mu.departemen = '" . $department . "' AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptVendorTanggal_jumlahVoucher($department, $vendor, $start, $end){
        $query = "  SELECT 
                       SUM(mp.jumlah_voucher_redeem) AS jumlah_voucher
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "' AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataDeptVendorTanggal_jumlahUang($department, $vendor, $start, $end){
        $query = "  SELECT 
                       SUM(mp.total_pembayaran) AS jumlah_uang
                    FROM 
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE 
                        mp.id_user = mu.id_user AND
                        mu.departemen = '" . $department . "' AND
                        mu.vendor = '" . $vendor . "' AND
                        mp.tgl_pembelian BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    // ============================================================================================= //

    function getDepartmentPerVendor($vendor){
        $query = "  SELECT DISTINCT
                        mu.departemen AS nama_department
                    FROM 
                        master_vendor AS mv,
                        master_user as mu
                    WHERE 
                        mu.vendor = mv.id AND
                        mv.id = '" . $vendor . "'
                    ORDER BY
                        mu.departemen
                        ";

        $result = $this->db->query($query);
        return $result;
    }
}