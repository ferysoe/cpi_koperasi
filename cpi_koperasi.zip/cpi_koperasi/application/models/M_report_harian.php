<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_report_harian extends CI_Model
{
    function getPenjualanHarian($id_plant){
        $query = "  SELECT 
                        mp.id_pembelian AS id_pembelian, 
                        mu.nama AS nama, 
                        mu.no_reg AS no_reg, 
                        mp.jumlah AS jumlah, 
                        mp.total_pembayaran AS total, 
                        mp.status_pembayaran AS status, 
                        mp.keterangan AS keterangan,
                        mp.kode_redeem_voucher AS kode_voucher 
                    FROM 
                        master_pembelian AS mp, 
                        master_user AS mu 
                    WHERE 
                        mu.id_user = mp.id_user AND
                        mp.id_plant_pembelian = '" . $id_plant . "' AND
                        DATE(mp.tgl_pembelian) = CURDATE()
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getTotalPembayaran($id_plant){
        $query = "  SELECT 
                        SUM(mp.total_pembayaran) AS total
                    FROM 
                        master_pembelian AS mp, 
                        master_user AS mu 
                    WHERE 
                        mu.id_user = mp.id_user AND
                        mp.id_plant_pembelian = '" . $id_plant . "' AND
                        DATE(mp.tgl_pembelian) = CURDATE()
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getJumlahPembelian($id_plant){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp, 
                        master_user AS mu 
                    WHERE 
                        mu.id_user = mp.id_user AND
                        mp.id_plant_pembelian = '" . $id_plant . "' AND
                        DATE(mp.tgl_pembelian) = CURDATE()
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getJumlahVoucher($id_plant){
        $query = "  SELECT 
                        SUM(mp.jumlah_voucher_redeem) AS jumlah
                    FROM 
                        master_pembelian AS mp, 
                        master_user AS mu 
                    WHERE 
                        mu.id_user = mp.id_user AND
                        mp.id_plant_pembelian = '" . $id_plant . "' AND
                        DATE(mp.tgl_pembelian) = CURDATE()
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getTotalCash($id_plant){
        $query = "  SELECT 
                        count(mp.status_pembayaran) AS cash
                    FROM 
                        master_pembelian AS mp
                    WHERE 
                        mp.status_pembayaran = 'Cash' AND
                        mp.id_plant_pembelian = '" . $id_plant . "' AND
                        DATE(mp.tgl_pembelian) = CURDATE()
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getTotalVoucher($id_plant){
        $query = "  SELECT 
                        count(mp.status_pembayaran) AS voucher
                    FROM 
                        master_pembelian AS mp
                    WHERE 
                        mp.status_pembayaran = 'Voucher' AND
                        mp.id_plant_pembelian = '" . $id_plant . "' AND
                        DATE(mp.tgl_pembelian) = CURDATE()
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getTotalPayroll($id_plant){
        $query = "  SELECT 
                        count(mp.status_pembayaran) AS payroll
                    FROM 
                        master_pembelian AS mp
                    WHERE 
                        mp.status_pembayaran = 'Payroll' AND
                        mp.id_plant_pembelian = '" . $id_plant . "' AND
                        DATE(mp.tgl_pembelian) = CURDATE()
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getStock($id_plant){
        $this->db->select('stock');
        $this->db->from('product');
        $this->db->where('nama_produk', 'Ayam Karkas 800 - 900 Gram');
        $this->db->where('id_plant', $id_plant);
        return $this->db->get();
    }
}