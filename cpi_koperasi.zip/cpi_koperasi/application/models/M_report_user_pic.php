<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_report_user_pic extends CI_Model
{
    function getDataUser($id_pic){
        $query = "  SELECT 
                        mu.nama AS nama, 
                        mu.no_reg AS no_reg, 
                        mv.nama AS vendor,
                        mu.departemen AS department,
                        mu.target AS target,
                        IF(mu.has_voucher = 'y', 'YES', 'NO') AS voucher
                    FROM 
                        master_user AS mu,
                        master_vendor AS mv
                    WHERE 
                        mu.vendor = mv.id AND
                        mu.id_pic = '". $id_pic ."' AND
                        mu.aktif = 'AKTIF'
                    ORDER BY
                        mu.vendor,
                        mu.departemen,
                        mu.no_reg
                        ";

        $result = $this->db->query($query);
        return $result;
    }
}