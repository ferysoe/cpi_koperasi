<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_report_stock extends CI_Model
{
    function get_user()	{
		return $this->db->get('master_user');
	}

    function get_plant()	{
		return $this->db->get('master_plant');
	}

    function get_akses()	{
		return $this->db->get('master_akses');
	}

    function get_pic()	{
		return $this->db->get('master_pic');
	}

    function get_vendor()	{
		return $this->db->get('master_vendor');
	}

    function getDataUser($id_pic){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        return $this->db->get();
    }

    function getNamaVendor($vendor){
        $this->db->select('*');
        $this->db->from('master_vendor');
        $this->db->where('id', $vendor);
        return $this->db->get();
    }

    function get_department(){
        $this->db->select('*');
        $this->db->from('master_department');
        return $this->db->get();
    }

    function dataRestockKrian($start, $end){
        $query = "  SELECT 
                        ms.tanggal AS tanggal,
                        ms.tambahan_stock AS stock
                    FROM 
                        master_stock AS ms
                    WHERE 
                        ms.id_product = '4' AND
                        ms.tanggal BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function dataRestockSepanjang($start, $end){
        $query = "  SELECT 
                        ms.tanggal AS tanggal,
                        ms.tambahan_stock AS stock
                    FROM 
                        master_stock AS ms
                    WHERE 
                        ms.id_product = '1' AND
                        ms.tanggal BETWEEN '" . $start . "' AND DATE_ADD('" . $end . "', INTERVAL 1 DAY)
                        ";

        $result = $this->db->query($query);
        return $result;
    }
}