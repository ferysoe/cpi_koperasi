<?php

defined('BASEPATH') OR exit('No direct script access allowed');
  
class M_login extends CI_Model{
    
    public function __construct(){
        $this->load->database();
    }

    function cekUser($username){
        $this->db->select('password, id_akses, id_user, id_pic, nama, id_plant');
        $this->db->from('master_user');
        $this->db->where('username', $username);
        return $this->db->get();
    }

    function getIdPic($id_user){
        $this->db->select('id_pic');
        $this->db->from('master_pic');
        $this->db->where('id_user', $id_user);
        return $this->db->get();
    }

}
?>