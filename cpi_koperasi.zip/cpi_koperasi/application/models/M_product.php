<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_product extends CI_Model
{
    public function __construct(){
        $this->load->database();
    }

    function insertNewDetailProductPrice($id_product, $harga, $tanggal){
        $data = array(
            'id_product' => $id_product,
            'harga' => $harga,
            'tanggal' => $tanggal
        );
        
        return $this->db->insert('master_harga', $data);
    }

    function insertNewDetailProductStock($id_product, $stock, $tanggal, $stock_akhir){
        $data = array(
            'id_product' => $id_product,
            'stock' => $stock_akhir,
            'tanggal' => $tanggal,
            'tambahan_stock' => $stock
        );
        
        return $this->db->insert('master_stock', $data);
    }

    function updateProduct($id_product, $harga, $stock){
        $data = array(
            'harga' => $harga,
            'stock' => $stock
        );

        $this->db->where('id_product', $id_product);
        return $this->db->update('product', $data);
    }

    function updateProductStock($id_product, $stock){
        $data = array(
            'stock' => $stock
        );

        $this->db->where('id_product', $id_product);
        return $this->db->update('product', $data);
    }
    
    function updateProductPrice($id_product, $harga){
        $data = array(
            'harga' => $harga
        );

        $this->db->where('id_product', $id_product);
        return $this->db->update('product', $data);
    }

    function getProduct(){
        $query = "  SELECT 
                        p.id_product AS id_product,
                        p.nama_produk AS nama,
                        mp.keterangan AS plant,
                        p.harga AS harga,
                        p.stock AS stock
                    FROM
                        product AS P,
                        master_plant AS mp
                    WHERE 
                        p.id_plant = mp.id_plant
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getProductperID($id_product){
        $query = "  SELECT 
                        p.nama_produk AS nama,
                        mp.keterangan AS plant,
                        p.harga AS harga,
                        p.stock AS stock
                    FROM
                        product AS P,
                        master_plant AS mp
                    WHERE 
                        p.id_plant = mp.id_plant AND
                        p.id_product = '" . $id_product . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }
}