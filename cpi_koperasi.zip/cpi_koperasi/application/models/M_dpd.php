<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_dpd extends CI_Model
{
    public function __construct(){
        $this->load->database();
    }

    function dataPerDay(){
        $this->db->select('*');
        $this->db->from('rec_dpd');
        $this->db->order_by('tanggal', 'DESC');
        return $this->db->get(); 
    }

    function dataPerDayPermanentKrian(){
        $this->db->select('*');
        $this->db->from('rec_dpd_dept');
        $this->db->where('id_plant', '1742');
        $this->db->order_by('tanggal', 'DESC');
        $this->db->order_by('department', 'ASC');
        return $this->db->get(); 
    }

    function dataPerDayPermanentSepanjang(){
        $this->db->select('*');
        $this->db->from('rec_dpd_dept');
        $this->db->where('id_plant', '1741');
        $this->db->order_by('tanggal', 'DESC');
        $this->db->order_by('department', 'ASC');
        return $this->db->get(); 
    }

    function dataPerDayPermanentPremix(){
        $this->db->select('*');
        $this->db->from('rec_dpd_dept');
        $this->db->where('id_plant', '1961');
        $this->db->order_by('tanggal', 'DESC');
        $this->db->order_by('department', 'ASC');
        return $this->db->get(); 
    }

    function dataPerDayOSKrian(){
        $query = "  SELECT 
                        rdo.tanggal,
                        rdo.id_plant,
                        mv.keterangan AS vendor,
                        rdo.realisasi,
                        rdo.target
                    FROM 
                        rec_dpd_os AS rdo,
                        master_vendor AS mv
                    WHERE 
                        rdo.id_vendor = mv.id AND
                        rdo.id_plant = '1742'
                    ORDER BY
                        rdo.tanggal DESC,
                        rdo.id_vendor
                        ";

        $result = $this->db->query($query);
        return $result;
    }
    
    function dataPerDayOSSepanjang(){
        $query = "  SELECT 
                        rdo.tanggal,
                        rdo.id_plant,
                        mv.keterangan AS vendor,
                        rdo.realisasi,
                        rdo.target
                    FROM 
                        rec_dpd_os AS rdo,
                        master_vendor AS mv
                    WHERE 
                        rdo.id_vendor = mv.id AND
                        rdo.id_plant = '1741'
                    ORDER BY
                        rdo.tanggal DESC,
                        rdo.id_vendor
                        ";

        $result = $this->db->query($query);
        return $result;
    }
    
    function dataPerDayOSPremix(){
        $query = "  SELECT 
                        rdo.tanggal,
                        rdo.id_plant,
                        mv.keterangan AS vendor,
                        rdo.realisasi,
                        rdo.target
                    FROM 
                        rec_dpd_os AS rdo,
                        master_vendor AS mv
                    WHERE 
                        rdo.id_vendor = mv.id AND
                        rdo.id_plant = '1961'
                    ORDER BY
                        rdo.tanggal DESC,
                        rdo.id_vendor
                        ";

        $result = $this->db->query($query);
        return $result;
    }
}