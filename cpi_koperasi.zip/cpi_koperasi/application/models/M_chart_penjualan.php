<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_chart_penjualan extends CI_Model
{
    public function __construct(){
        $this->load->database();
    }

    public function getDataPerVendor(){
        $query = "  SELECT
                        IF(mv.nama = 'KOPERASI', 'EXTERNAL', mv.nama) AS vendor,
                        (
                            SELECT
                                IF(SUM(mp.jumlah) IS NULL, 0, (SUM(mp.jumlah)))
                            FROM
                                master_pembelian AS mp,
                                master_user AS mu
                            WHERE
                                mp.id_user = mu.id_user AND
                                mu.vendor = mv.id AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'02')
                        ) AS jumlah,
                        (
                            SELECT
                                SUM(mu2.target)
                            FROM
                                master_user AS mu2
                            WHERE
                                mu2.vendor = mv.id
                        ) AS target,
                        (
                            SELECT
                                IF(SUM(mp2.jumlah) IS NULL, 0, (SUM(mp2.jumlah)))
                            FROM
                                master_pembelian AS mp2,
                                master_user AS mu3
                            WHERE
                                mp2.id_user = mu3.id_user AND
                                mu3.vendor = mv.id AND
                                DATE_FORMAT(mp2.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'02') AND
                                mp2.status_pembayaran = 'Cash'
                        ) AS cash,
                        (
                            SELECT
                                IF(SUM(mp3.jumlah) IS NULL, 0, (SUM(mp3.jumlah)))
                            FROM
                                master_pembelian AS mp3,
                                master_user AS mu4
                            WHERE
                                mp3.id_user = mu4.id_user AND
                                mu4.vendor = mv.id AND
                                DATE_FORMAT(mp3.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'02') AND
                                mp3.status_pembayaran = 'Voucher'
                        ) AS voucher,
                        (
                            SELECT
                                IF(SUM(mp4.jumlah) IS NULL, 0, (SUM(mp4.jumlah)))
                            FROM
                                master_pembelian AS mp4,
                                master_user AS mu5
                            WHERE
                                mp4.id_user = mu5.id_user AND
                                mu5.vendor = mv.id AND
                                DATE_FORMAT(mp4.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'02') AND
                                mp4.status_pembayaran = 'Payroll'
                        ) AS payroll
                    FROM  
                        master_vendor AS mv
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    public function jumlahtarget(){
        $query = "  SELECT
                        rd.target AS target
                    FROM  
                        rec_dpd AS rd
                    WHERE
                        rd.tanggal = CONCAT(LAST_DAY(CONCAT(YEAR(CURDATE()),'-0',MONTH(CURDATE())-1,'-01')),' 23:00:00')
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    public function jumlahtarget2(){
        $this->db->select('target');
        $this->db->from('rec_dpd');
        $this->db->where('id_dpd', '1');
        return $this->db->get(); 
    }
    
    public function jumlahrealisasi(){
        $query = "  SELECT 
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS jumlah
                    FROM 
                        master_pembelian AS mp
                    WHERE 
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'03')
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    public function dataPenjualanCPI(){
        $query = "  SELECT
                        DISTINCT CAST(mp.tgl_pembelian AS DATE) AS tanggal,
                        (
                            SELECT
                                SUM(mp2.jumlah)
                            FROM
                                master_pembelian AS mp2,
                                master_user AS mu2
                            WHERE
                                mp2.id_user = mu2.id_user AND
                                mu2.vendor = '5' AND
                                CAST(mp2.tgl_pembelian AS DATE) = tanggal
                        ) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mp.id_user = mu.id_user AND
                        mu.vendor = '5'
                    ORDER BY
                        tanggal ASC
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    public function pilihanPeriode_unused(){
        $query = "  SELECT DISTINCT
                        CONCAT(MONTHNAME(r.tanggal), ' ',YEAR(r.tanggal)) AS periode,
                        MONTH(r.tanggal) AS bulan
                    FROM
                        rec_dpd AS r
                    ORDER BY
                        r.tanggal DESC
                    ";

        $result = $this->db->query($query);
        return $result;
    }

    function pilihanPeriode(){
        $query = "  SELECT 
                        DATE_FORMAT(m1, '%b %Y') AS periode,
                        m1 AS bulan
                    FROM
                        (
                            SELECT 
                                ('2023-02-01' - INTERVAL DAYOFMONTH('2023-02-01')-1 DAY)+INTERVAL m MONTH as m1
                            FROM
                                (
                                    SELECT @rownum:=@rownum+1 AS m FROM
                                        (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) t1,
                                        (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) t2,
                                        (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) t3,
                                        (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) t4,
                                        (SELECT @rownum:=-1) t0
                                ) d1
                        ) d2 
                    WHERE m1 <= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                    ORDER BY m1 DESC
                    ";

        $result = $this->db->query($query);
        return $result;
    }
}