<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_user extends CI_Model
{
    public function __construct(){
        $this->load->database();
    }

    public function getDataUser(){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->order_by('id_user');
        return $this->db->get(); 
    }

    public function get_vendor(){
        $this->db->select('*');
        $this->db->from('master_vendor');
        return $this->db->get(); 
    }

    public function get_department(){
       $query = "  SELECT DISTINCT
                        mu.departemen AS department
                    FROM
                        master_user AS mu
                    WHERE
                        mu.departemen <> 'none'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    public function insertDataUser(){
        $this->db->insert('master_user', $tambah);
    }

    public function updateDataUser($id_user_edit, $username, $password, $nama, $nik, $no_reg, $status_karyawan, $vendor, $department, $aktif, $id_plant, $id_pic, $target, $id_akses, $voucher){

        $dataEdit = array(
            'username' => $username,
            'password' => $password,
            'nama' => $nama,
            'nik' => $nik,
            'no_reg' => $no_reg,
            'status_karyawan' => $status_karyawan,
            'vendor' => $vendor,
            'departemen' => $department,
            'aktif' => $aktif,
            'id_plant' => $id_plant,
            'id_pic' => $id_pic,
            'target' => $target,
            'id_akses' => $id_akses,
            'voucher' => $voucher
        );

        // $this->db->where('id_pembelian', $id_pembelian_edit);
        // return $this->db->update('master_pembelian', $data);

        $this->db->where('id_user', $id_user_edit);
        $this->db->update('master_user', $dataEdit);
        return TRUE;
    }

    public function DeleteDataUser(){
        $this->db->where('id_user', $id_user);
        return $this->db->delete('master_user');

        // $this->db->where('id_pembelian', $id_pembelian);
        // return $this->db->delete('master_pembelian');
    }
    
    function get_product()	{
		$query = "  SELECT 
                        p.id_product AS id_product,
                        p.nama_produk AS nama,
                        mp.keterangan AS plant,
                        p.harga AS harga,
                        p.stock AS stock
                    FROM
                        product AS P,
                        master_plant AS mp
                    WHERE 
                        p.id_plant = mp.id_plant
                        ";

        $result = $this->db->query($query);
        return $result;
	}

    function get_harga(){
        $this->db->select('harga');
        $this->db->from('product');
        $this->db->where('id_product', '1');
        return $this->db->get(); 
    }

    function get_user2()	{
		return $this->db->get('master_user');
	}

    // public function get_user(){
    //     $this->db->select('*');
    //     $this->db->from('master_user');
    //     $this->db->where('vendor <>', 'none');
    //     $this->db->order_by('id_user');
    //     return $this->db->get(); 
    // }

    function get_user()	{
		$query = "  SELECT 
                        mu.nama AS nama,
                        mu.no_reg AS no_reg,
                        mu.status_karyawan AS status_karyawan,
                        mv.nama AS vendor,
                        mu.departemen AS departemen,
                        mu.aktif AS aktif,
                        mu.id_plant AS id_plant,
                        mp.nama AS id_pic,
                        mu.target AS target,
                        mu.id_akses AS id_akses,
                        mu.id_user AS id_user,
                        IF(mu.has_voucher = 'y', 'YES', 'NO') AS has_voucher
                    FROM 
                        master_user AS mu,
                        master_vendor AS mv,
                        master_pic AS mp
                    WHERE 
                        mu.vendor = mv.id AND
                        mu.id_pic = mp.id_pic
                        ";

        $result = $this->db->query($query);
        return $result;
	}

    function get_plant()	{
		return $this->db->get('master_plant');
	}
    function get_akses()	{
		return $this->db->get('master_akses');
	}
    function get_pic()	{
		return $this->db->get('master_pic');
	}

    function insertNewDetailProduct($id_product, $harga, $tanggal){
        $data = array(
            'id_product' => $id_product,
            'harga' => $harga,
            'tanggal' => $tanggal
        );
        
        return $this->db->insert('master_pembelian', $data);
    }

    function updateHarga($id_product, $harga){
        $data = array(
            'harga' => $harga
        );

        $this->db->where('id_product', $id_product);
        return $this->db->update('product', $data);
    }

    public function deleteUser($id_user){
        $this->db->where('id_user', $id_user);
        return $this->db->delete('master_user');
    }

    public function getUser($id_user){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_user', $id_user);
        return $this->db->get();
    }

    public function getDataUserDetail($id_user)
    {
        $this->db->where('id_user',$id_user);
        $query = $this->db->get('master_user');
        return $query->row();
    }

    public function jumlahtarget(){
        $this->db->select_sum('target');
        $this->db->from('master_user');
        $this->db->where('aktif', 'AKTIF');
        return $this->db->get(); 
    }
    
    public function jumlahrealisasi(){
        $query = "  SELECT 
                        SUM(mp.jumlah) AS jumlah
                    FROM 
                        master_pembelian AS mp
                    WHERE 
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    public function jumlahdataplantkrian(){
        $this->db->select_sum('jumlah');
    }

    public function updateUser($id_user, $username, $pass, $nama, $noreg, $status_karyawan, $vendor, $department, $aktif, $id_plant, $id_pic, $target, $id_akses, $has_voucher){
        $data = array(
            'username' => $username,
            'password' => $pass,
            'nama' => $nama,
            'no_reg' => $noreg,           
            'status_karyawan' => $status_karyawan,
            'vendor' => $vendor,          
            'departemen' => $department,
            'aktif' => $aktif,
            'id_plant' => $id_plant,
            'id_pic' => $id_pic,
            'target' => $target,
            'id_akses' => $id_akses,
            'has_voucher' => $has_voucher
        );

        $this->db->where('id_user', $id_user);
        return $this->db->update('master_user', $data);
    }

    public function showDataUser(){
        $query = "  SELECT 
                        mu.nama AS nama,
                        mu.nama AS no_reg,
                        mu.status_karyawan AS status_karyawan,
                        mu.vendor AS vendor,
                        mu.departemen AS departemen,
                        mu.aktif AS aktif,
                        mu.id_plant AS id_plant,
                        mu.id_pic AS id_pic,
                        mu.target AS 'target'
                    FROM 
                        master_user AS mu 
                    ORDER BY
                        mu.id_user
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    public function getDataPerAreaKrian(){
        $query = "  SELECT 
                        mp.area AS Area,
                        (
                            SELECT 
                                IF(SUM(mpb.jumlah) IS NULL, 0, SUM(mpb.jumlah))
                            FROM 
                                master_pembelian AS mpb,
                                master_user AS mu2
                            WHERE 
                                mpb.id_user = mu2.id_user AND
                                mu2.id_pic = mp.id_pic AND
                            mu2.status_karyawan = 'PERMANENT' AND
                                DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi,
                        (
                            SELECT 
                                IF(SUM(mu.target) IS NULL, 0, SUM(mu.target))
                            FROM 
                                master_user AS mu
                            WHERE 
                                mu.id_pic = mp.id_pic AND
                                mu.status_karyawan = 'PERMANENT' AND
                                mu.aktif = 'AKTIF'
                        ) AS Target
                    FROM 
                        master_pic AS mp
                    Where
                        mp.id_plant = '1742'
                    ORDER BY
                    	mp.area";

        $result = $this->db->query($query);
        return $result;
    }

    public function getDataPerDeptKrian(){
        $query = "  SELECT DISTINCT 
                        mu3.departemen AS Departemen, 
                        ( 
                            SELECT 
                                SUM(mpb.jumlah) 
                            FROM 
                                master_pembelian AS mpb, 
                                master_user AS mu2 
                            WHERE 
                                mpb.id_user = mu2.id_user AND 
                                mu3.departemen = mu2.departemen AND 
                                mu2.id_plant = '1742' AND
			                    DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi, 
                        SUM(mu3.target) AS Target 
                    FROM 
                        master_user AS mu3 
                    Where 
                        mu3.id_plant = '1742' AND 
                        departemen != 'none' AND 
                        aktif = 'AKTIF' 
                    GROUP BY Departemen";

        $result = $this->db->query($query);
        return $result;
    }

    public function dataDeptCPIKrian(){
        $query = "  SELECT DISTINCT 
                        mu3.departemen AS Departemen, 
                        ( 
                            SELECT 
                                SUM(mpb.jumlah) 
                            FROM 
                                master_pembelian AS mpb, 
                                master_user AS mu2 
                            WHERE 
                                mpb.id_user = mu2.id_user AND 
                                mu3.vendor = mu2.vendor AND 
                                mu3.departemen = mu2.departemen AND 
                                mu2.id_plant = '1742' AND
                                DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi, 
                        SUM(mu3.target) AS Target 
                    FROM 
                        master_user AS mu3 
                    Where 
                        mu3.id_plant = '1742' AND 
                        mu3.status_karyawan = 'PERMANENT' AND 
                        aktif = 'AKTIF' 
                    GROUP BY Departemen";

        $result = $this->db->query($query);
        return $result;
    }

    public function dataOSKrian(){
        $query = "  SELECT
                        DISTINCT mv.nama AS Vendor,
                        (
                            SELECT
                                SUM(mp.jumlah)
                            FROM
                                master_pembelian AS mp,
                                master_user AS mu2
                            WHERE
                                mp.id_user = mu2.id_user AND
                                mu2.vendor = mu.vendor AND
                                mu2.id_plant = '1742' AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi,
                        SUM(mu.target) AS Target
                    FROM
                        master_vendor AS mv,
                        master_user AS mu
                    WHERE
                        mv.id = mu.vendor AND
                        mu.aktif = 'AKTIF' AND
                        mu.id_plant = '1742' AND
                        mu.status_karyawan = 'NON PERMANENT'
                    GROUP BY
                        mv.id";

        $result = $this->db->query($query);
        return $result;
    }

    public function dataDeptCPISepanjang(){
        $query = "  SELECT DISTINCT 
                        mu3.departemen AS Departemen, 
                        ( 
                            SELECT 
                                SUM(mpb.jumlah) 
                            FROM 
                                master_pembelian AS mpb, 
                                master_user AS mu2 
                            WHERE 
                                mpb.id_user = mu2.id_user AND 
                                mu3.vendor = mu2.vendor AND 
                                mu3.departemen = mu2.departemen AND 
                                mu2.id_plant = '1741' AND
                                DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi, 
                        SUM(mu3.target) AS Target 
                    FROM 
                        master_user AS mu3 
                    Where 
                        mu3.id_plant = '1741' AND 
                        mu3.status_karyawan = 'PERMANENT' AND 
                        aktif = 'AKTIF' 
                    GROUP BY Departemen";

        $result = $this->db->query($query);
        return $result;
    }

    public function dataOSSepanjang(){
        $query = "  SELECT
                        DISTINCT mv.nama AS Vendor,
                        (
                            SELECT
                                SUM(mp.jumlah)
                            FROM
                                master_pembelian AS mp,
                                master_user AS mu2
                            WHERE
                                mp.id_user = mu2.id_user AND
                                mu2.vendor = mu.vendor AND
                                mu2.id_plant = '1741' AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi,
                        SUM(mu.target) AS Target
                    FROM
                        master_vendor AS mv,
                        master_user AS mu
                    WHERE
                        mv.id = mu.vendor AND
                        mu.aktif = 'AKTIF' AND
                        mu.id_plant = '1741' AND
                        mu.status_karyawan = 'NON PERMANENT'
                    GROUP BY
                        mv.id";

        $result = $this->db->query($query);
        return $result;
    }

    public function dataDeptCPIPremix(){
        $query = "  SELECT DISTINCT 
                        mu3.departemen AS Departemen, 
                        ( 
                            SELECT 
                                SUM(mpb.jumlah) 
                            FROM 
                                master_pembelian AS mpb, 
                                master_user AS mu2 
                            WHERE 
                                mpb.id_user = mu2.id_user AND 
                                mu3.vendor = mu2.vendor AND 
                                mu3.departemen = mu2.departemen AND 
                                mu2.id_plant = '1961' AND
                                DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi, 
                        SUM(mu3.target) AS Target 
                    FROM 
                        master_user AS mu3 
                    Where 
                        mu3.id_plant = '1961' AND 
                        mu3.status_karyawan = 'PERMANENT' AND 
                        aktif = 'AKTIF' 
                    GROUP BY Departemen";

        $result = $this->db->query($query);
        return $result;
    }

    public function dataOSPremix(){
        $query = "  SELECT
                        DISTINCT mv.nama AS Vendor,
                        (
                            SELECT
                                SUM(mp.jumlah)
                            FROM
                                master_pembelian AS mp,
                                master_user AS mu2
                            WHERE
                                mp.id_user = mu2.id_user AND
                                mu2.vendor = mu.vendor AND
                                mu2.id_plant = '1961' AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi,
                        SUM(mu.target) AS Target
                    FROM
                        master_vendor AS mv,
                        master_user AS mu
                    WHERE
                        mv.id = mu.vendor AND
                        mu.aktif = 'AKTIF' AND
                        mu.id_plant = '1961' AND
                        mu.status_karyawan = 'NON PERMANENT'
                    GROUP BY
                        mv.id";

        $result = $this->db->query($query);
        return $result;
    }

    public function getDataPerAreaSepanjang(){
        $query = "  SELECT 
                        mp.area AS Area,
                        (
                            SELECT 
                                IF(SUM(mpb.jumlah) IS NULL, 0, SUM(mpb.jumlah))
                            FROM 
                                master_pembelian AS mpb,
                                master_user AS mu2
                            WHERE 
                                mpb.id_user = mu2.id_user AND
                                mu2.id_pic = mp.id_pic AND
                                mu2.status_karyawan = 'PERMANENT' AND
			                    DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi,
                        (
                            SELECT 
                                IF(SUM(mu.target) IS NULL, 0, SUM(mu.target))
                            FROM 
                                master_user AS mu
                            WHERE 
                                mu.id_pic = mp.id_pic AND
                                mu.status_karyawan = 'PERMANENT' AND
                                mu.aktif = 'AKTIF'
                        ) AS Target
                    FROM 
                        master_pic AS mp
                    WHERE
                        mp.id_plant = '1741'
                    ORDER BY
                    	mp.area
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    public function getDataPerDeptSepanjang(){
        $query = "  SELECT DISTINCT 
                        mu3.departemen AS Departemen, 
                        ( 
                            SELECT 
                                SUM(mpb.jumlah) 
                            FROM 
                                master_pembelian AS mpb, 
                                master_user AS mu2 
                            WHERE 
                                mpb.id_user = mu2.id_user AND 
                                mu3.departemen = mu2.departemen AND 
                                mu2.id_plant = '1741' AND
			                    DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi, 
                        SUM(mu3.target) AS Target 
                    FROM 
                        master_user AS mu3 
                    Where 
                        mu3.id_plant = '1741' AND 
                        departemen != 'none' AND 
                        aktif = 'AKTIF' 
                    GROUP BY Departemen";

        $result = $this->db->query($query);
        return $result;
    }

    public function getDataPerAreaPremix(){
        $query = "  SELECT 
                        mp.area AS Area,
                        (
                            SELECT 
                                IF(SUM(mpb.jumlah) IS NULL, 0, SUM(mpb.jumlah))
                            FROM 
                                master_pembelian AS mpb,
                                master_user AS mu2
                            WHERE 
                                mpb.id_user = mu2.id_user AND
                                mu2.id_pic = mp.id_pic AND
                                mu2.status_karyawan = 'PERMANENT' AND
			                    DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi,
                        (
                            SELECT 
                                IF(SUM(mu.target) IS NULL, 0, SUM(mu.target))
                            FROM 
                                master_user AS mu
                            WHERE 
                                mu.id_pic = mp.id_pic AND
                                mu.status_karyawan = 'PERMANENT' AND
                                mu.aktif = 'AKTIF'
                        ) AS Target
                    FROM 
                        master_pic AS mp
                    Where
                        mp.id_plant = '1961'
                    ORDER BY
                    	mp.area";

        $result = $this->db->query($query);
        return $result;
    }

    public function getDataPerDeptPremix(){
        $query = "  SELECT DISTINCT
                            mu3.departemen AS Departemen,
                            (
                                SELECT 
                                    SUM(mpb.jumlah)
                                FROM 
                                    master_pembelian AS mpb,
                                    master_user AS mu2
                                WHERE 
                                    mpb.id_user = mu2.id_user AND
                                    mu3.departemen = mu2.departemen AND
                                    mu2.id_plant = '1961' AND
			                        DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                            ) AS Realisasi,
                            SUM(mu3.target) AS Target
                        FROM 
                            master_user AS mu3
                        Where
                            mu3.id_plant = '1961'
                            AND departemen != 'none'
                            AND aktif = 'AKTIF'
                    GROUP BY Departemen";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiKrian(){
        $query = "  SELECT
                        SUM(mp.jumlah) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mu.id_user = mp.id_user AND
                        mu.id_plant = '1742' AND
	                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiCPIKrian(){
        $query = "  SELECT
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mu.id_user = mp.id_user AND
                        mu.id_plant = '1742' AND
                        mu.status_karyawan = 'PERMANENT' AND
	                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiOSKrian(){
        $query = "  SELECT
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mu.id_user = mp.id_user AND
                        mu.id_plant = '1742' AND
                        mu.status_karyawan = 'NON PERMANENT' AND
	                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiCPISepanjang(){
        $query = "  SELECT
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mu.id_user = mp.id_user AND
                        mu.id_plant = '1741' AND
                        mu.status_karyawan = 'PERMANENT' AND
	                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiOSSepanjang(){
        $query = "  SELECT
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mu.id_user = mp.id_user AND
                        mu.id_plant = '1741' AND
                        mu.status_karyawan = 'NON PERMANENT' AND
	                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiCPIPremix(){
        $query = "  SELECT
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mu.id_user = mp.id_user AND
                        mu.id_plant = '1961' AND
                        mu.status_karyawan = 'PERMANENT' AND
	                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiOSPremix(){
        $query = "  SELECT
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mu.id_user = mp.id_user AND
                        mu.id_plant = '1961' AND
                        mu.status_karyawan = 'NON PERMANENT' AND
	                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetKrian(){
        $query = "  SELECT
                        SUM(mu.target) AS target
                    FROM
                        master_user AS mu
                    WHERE
                        mu.id_plant = '1742' AND
                        mu.aktif = 'AKTIF'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetCPIKrian(){
        $query = "  SELECT
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM
                        master_user AS mu
                    WHERE
                        mu.id_plant = '1742' AND
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.aktif = 'AKTIF'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetOSKrian(){
        $query = "  SELECT
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM
                        master_user AS mu
                    WHERE
                        mu.id_plant = '1742' AND
                        mu.status_karyawan = 'NON PERMANENT' AND
                        mu.aktif = 'AKTIF'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetCPISepanjang(){
        $query = "  SELECT
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM
                        master_user AS mu
                    WHERE
                        mu.id_plant = '1741' AND
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.aktif = 'AKTIF'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetOSSepanjang(){
        $query = "  SELECT
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM
                        master_user AS mu
                    WHERE
                        mu.id_plant = '1741' AND
                        mu.status_karyawan = 'NON PERMANENT' AND
                        mu.aktif = 'AKTIF'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetCPIPremix(){
        $query = "  SELECT
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM
                        master_user AS mu
                    WHERE
                        mu.id_plant = '1961' AND
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.aktif = 'AKTIF'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetOSPremix(){
        $query = "  SELECT
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM
                        master_user AS mu
                    WHERE
                        mu.id_plant = '1961' AND
                        mu.status_karyawan = 'NON PERMANENT' AND
                        mu.aktif = 'AKTIF'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiSpj(){
        $query = "  SELECT
                        SUM(mp.jumlah) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mu.id_user = mp.id_user AND
                        mu.id_plant = '1741'  AND
	                    DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetSpj(){
        $query = "  SELECT
                        SUM(mu.target) AS target
                    FROM
                        master_user AS mu
                    WHERE
                        mu.id_plant = '1741' AND
                        mu.aktif = 'AKTIF'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function realisasiPremix(){
        $query = "  SELECT
                        SUM(mp.jumlah) AS jumlah
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mu.id_user = mp.id_user AND
                        mu.id_plant = '1961'  AND
	                    DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function targetPremix(){
        $query = "  SELECT
                        SUM(mu.target) AS target
                    FROM
                        master_user AS mu
                    WHERE
                        mu.id_plant = '1961' AND
                        mu.aktif = 'AKTIF'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    public function getDataExternal(){
        $query = "  SELECT DISTINCT 
                        mu.nama AS Nama, 
                        ( 
                            SELECT 
                                SUM(mpb.jumlah) 
                            FROM 
                                master_pembelian AS mpb
                            WHERE 
                                mpb.id_user = '1485' AND
                                DATE_FORMAT(mpb.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS Realisasi, 
                        SUM(mu.target) AS Target 
                    FROM 
                        master_user AS mu 
                    Where 
                        mu.id_user = '1485'
                ";

        $result = $this->db->query($query);
        return $result;
    }

    function getLastIDPIC(){
        $query = "  SELECT
                        mp.id_pic AS id_pic
                    FROM 
                        master_pic AS mp
                    ORDER BY 
                        mp.id_pic DESC
                    LIMIT 1
                ";

        $result = $this->db->query($query);
        return $result->result();
    }

    function getLastIdUser(){
        $query = "  SELECT
                        mu.id_user AS id_user
                    FROM 
                        master_user AS mu
                    ORDER BY 
                        mu.id_user DESC
                    LIMIT 1
                ";

        $result = $this->db->query($query);
        return $result->result();
    }

    function insertNewUser($username, $password, $nama, $no_reg, $status_karyawan, $vendor, $department, $aktif, $id_plant, $id_pic, $target, $id_akses, $has_voucher){
        $data = array(
            'username' => $username,
            'password' => $password,
            'nama' => $nama,
            'no_reg' => $no_reg,
            'status_karyawan' => $status_karyawan,
            'vendor' => $vendor,
            'departemen' => $department,
            'aktif' => $aktif,
            'id_plant' => $id_plant,
            'id_pic' => $id_pic,
            'target' => $target,
            'id_akses' => $id_akses,
            'has_voucher' => $has_voucher
        );
        
        return $this->db->insert('master_user', $data);
    }

    function insertNewPIC($id_pic, $id_user, $nama, $id_plant, $area_pic){
        $data = array(
            'id_pic' => $id_pic,
            'id_user' => $id_user,
            'nama' => $nama,
            'nama' => $nama,
            'id_plant' => $id_plant,
            'area' => $area_pic
        );
        
        return $this->db->insert('master_pic', $data);
    }

    function rekap(){
        $query = "  SELECT 
                        DATE_FORMAT(m1, '%b %Y') AS bulan,
                        (
                            SELECT 
                                IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS jumlah
                            FROM 
                                master_pembelian AS mp
                            WHERE 
                                DATE_FORMAT(mp.tgl_pembelian, '%b %Y') = bulan
                        ) AS realisasi,
                        (
                            SELECT
                                rd.target AS target
                            FROM  
                                rec_dpd AS rd
                            WHERE
                                rd.tanggal = CONCAT(LAST_DAY(CONCAT(DATE_FORMAT(m1, '%Y-%m'),'-01')),' 23:00:00')
                        ) AS target
                    FROM
                        (
                            SELECT 
                                ('2023-02-01' - INTERVAL DAYOFMONTH('2023-02-01')-1 DAY)+INTERVAL m MONTH as m1
                            FROM
                                (
                                    SELECT @rownum:=@rownum+1 AS m FROM
                                        (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) t1,
                                        (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) t2,
                                        (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) t3,
                                        (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) t4,
                                        (SELECT @rownum:=-1) t0
                                ) d1
                        ) d2 
                    WHERE m1 <= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                    ORDER BY m1
                    ";

        $result = $this->db->query($query);
        return $result;
    }
}