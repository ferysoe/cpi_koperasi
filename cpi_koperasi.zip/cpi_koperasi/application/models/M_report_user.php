<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_report_user extends CI_Model
{
    function getDetailPIC($id_user){
        $this->db->select('*');
        $this->db->from('master_pic');
        $this->db->where('id_user', $id_user);
        return $this->db->get();
    }

    // function getDataUseronPIC($id_pic){
    //     $this->db->select('*');
    //     $this->db->from('master_user');
    //     $this->db->where('id_pic', $id_pic);
    //     $this->db->order_by('vendor', 'ASC');
    //     $this->db->order_by('departemen', 'ASC');
    //     $this->db->order_by('no_reg', 'ASC');
    //     return $this->db->get();
    // }

    function getDataUseronPIC($id_pic){
        $query = "  SELECT
                        mu.no_reg AS no_reg,
                        mu.nama AS nama,
                        mv.nama AS vendor,
                        mu.departemen AS department,
                        mu.target AS target,
                        mu.has_voucher AS has_voucher
                    FROM
                        master_user AS mu,
                        master_vendor AS mv
                    WHERE
                        mu.vendor = mv.id AND
                        mu.aktif = 'AKTIF' AND
                        mu.id_pic = '" . $id_pic . "'
                ";
        
        $result = $this->db->query($query);
        return $result;
    }

    function getVendorUseronPIC($id_pic){
        $this->db->distinct();
        $this->db->select('vendor');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->order_by('vendor', 'ASC');
        return $this->db->get();
    }

    function getDepartmentAll($id_pic){
        $this->db->distinct();
        $this->db->select('departemen');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->order_by('departemen', 'ASC');
        $this->db->order_by('vendor', 'ASC');
        return $this->db->get();
    }

    function getDepartmentUseronPIC($id_pic, $vendor){
        $this->db->distinct();
        $this->db->select('departemen');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->where('vendor', $vendor);
        $this->db->order_by('vendor', 'ASC');
        $this->db->order_by('departemen', 'ASC');
        return $this->db->get();
    }

    function getDatabyVendor($id_pic, $vendor){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->where('vendor', $vendor);
        $this->db->order_by('departemen', 'ASC');
        $this->db->order_by('no_reg', 'ASC');
        return $this->db->get();
    }

    function getDatabyDepartment($id_pic, $department){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->where('departemen', $department);
        $this->db->order_by('departemen', 'ASC');
        $this->db->order_by('no_reg', 'ASC');
        return $this->db->get();
    }

    function getDatabyVendor_Department($id_pic, $department, $vendor){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->where('vendor', $vendor);
        $this->db->where('departemen', $department);
        $this->db->order_by('no_reg', 'ASC');
        return $this->db->get();
    }

    function getDataPIC(){
        $this->db->select('*');
        $this->db->from('master_pic');
        return $this->db->get();
    }

    function getNamaPIC($id_pic){
        $this->db->select('nama');
        $this->db->from('master_pic');
        $this->db->where('id_pic', $id_pic);
        return $this->db->get();
    }
}