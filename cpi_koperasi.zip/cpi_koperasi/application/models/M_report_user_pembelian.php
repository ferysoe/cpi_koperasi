<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_report_user_pembelian extends CI_Model
{
    function getDetailPIC($id_user){
        $this->db->select('*');
        $this->db->from('master_pic');
        $this->db->where('id_user', $id_user);
        return $this->db->get();
    }

    function getDataUseronPIC($id_pic){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->order_by('vendor', 'ASC');
        $this->db->order_by('departemen', 'ASC');
        $this->db->order_by('no_reg', 'ASC');
        return $this->db->get();
    }

    function getVendorUseronPIC($id_pic){
        $this->db->distinct();
        $this->db->select('vendor');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->order_by('vendor', 'ASC');
        return $this->db->get();
    }

    function getDepartmentAll($id_pic){
        $this->db->distinct();
        $this->db->select('departemen');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->order_by('departemen', 'ASC');
        $this->db->order_by('vendor', 'ASC');
        return $this->db->get();
    }

    function getDepartmentUseronPIC($id_pic, $vendor){
        $this->db->distinct();
        $this->db->select('departemen');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->where('vendor', $vendor);
        $this->db->order_by('vendor', 'ASC');
        $this->db->order_by('departemen', 'ASC');
        return $this->db->get();
    }

    function getDatabyVendor($id_pic, $vendor){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->where('vendor', $vendor);
        $this->db->order_by('departemen', 'ASC');
        $this->db->order_by('no_reg', 'ASC');
        return $this->db->get();
    }

    function getDatabyDepartment($id_pic, $department){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->where('departemen', $department);
        $this->db->order_by('departemen', 'ASC');
        $this->db->order_by('no_reg', 'ASC');
        return $this->db->get();
    }

    function getDatabyVendor_Department($id_pic, $department, $vendor){
        $this->db->select('*');
        $this->db->from('master_user');
        $this->db->where('id_pic', $id_pic);
        $this->db->where('vendor', $vendor);
        $this->db->where('departemen', $department);
        $this->db->order_by('no_reg', 'ASC');
        return $this->db->get();
    }

    function getDataPIC(){
        $this->db->select('*');
        $this->db->from('master_pic');
        return $this->db->get();
    }

    function getNamaPIC($id_pic){
        $this->db->select('nama');
        $this->db->from('master_pic');
        $this->db->where('id_pic', $id_pic);
        return $this->db->get();
    }

    function getDataRealisasi($id_pic){
        $query = "  SELECT 
                        mu.nama AS nama, 
                        mu.no_reg AS no_reg, 
                        mv.nama AS vendor,
                        mu.departemen AS department,
                        ( 
                            SELECT 
                                IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) 
                            FROM 
                                master_pembelian AS mp 
                            WHERE 
                                mp.id_user = mu.id_user AND
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE()))
                        ) AS realisasi,
                        mu.target AS target
                    FROM 
                        master_user AS mu,
                        master_vendor AS mv
                    WHERE 
                        mu.vendor = mv.id AND
                        mu.id_pic = '" . $id_pic . "' AND
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.aktif = 'AKTIF'
                    ORDER BY
                        mu.departemen,
                        mu.no_reg
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getRealisasiPIC($id_pic){
        $query = "  SELECT
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS realisasi
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mp.id_user = mu.id_user AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                        mu.id_pic = '" . $id_pic . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getRealisasiPICPermanent($id_pic){
        $query = "  SELECT
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS realisasi
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mp.id_user = mu.id_user AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.id_pic = '" . $id_pic . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getRealisasiPICOS($id_pic){
        $query = "  SELECT
                        IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah)) AS realisasi
                    FROM
                        master_pembelian AS mp,
                        master_user AS mu
                    WHERE
                        mp.id_user = mu.id_user AND
                        DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                        mu.id_plant = (SELECT mpc.id_plant FROM master_pic AS mpc WHERE mpc.id_pic = '" . $id_pic . "') AND
                        mu.vendor IN(
                                        SELECT DISTINCT
                                            mu2.vendor AS vendor
                                        FROM
                                            master_user as mu2
                                        WHERE
                                            mu2.id_pic = '" . $id_pic . "' AND
                                            mu2.status_karyawan = 'NON PERMANENT'
                                    )
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getTargetPIC($id_pic){
        $query = "  SELECT 
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM 
                        master_user AS mu
                    WHERE 
                        mu.aktif = 'AKTIF' AND
                        mu.id_pic = '" . $id_pic . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getTargetPICPermanent($id_pic){
        $query = "  SELECT 
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM 
                        master_user AS mu
                    WHERE 
                        mu.aktif = 'AKTIF' AND
                        mu.status_karyawan = 'PERMANENT' AND
                        mu.id_pic = '" . $id_pic . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getTargetPICOS($id_pic){
        $query = "  SELECT 
                        IF(SUM(mu.target) IS NULL, 0, SUM(mu.target)) AS target
                    FROM 
                        master_user AS mu
                    WHERE 
                        mu.aktif = 'AKTIF' AND
                        mu.id_plant = (SELECT mpc.id_plant FROM master_pic AS mpc WHERE mpc.id_pic = '" . $id_pic . "') AND
                        mu.vendor IN(
                                        SELECT DISTINCT
                                            mu2.vendor AS vendor
                                        FROM
                                            master_user as mu2
                                        WHERE
                                            mu2.id_pic = '" . $id_pic . "' AND
                                            mu2.status_karyawan = 'NON PERMANENT'
                                    )
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getDataOS($id_pic){
        $query = "  SELECT
                        mv.nama AS vendor,
                        (
                            SELECT
                                IF(SUM(mp.jumlah) IS NULL, 0, SUM(mp.jumlah))
                            FROM
                                master_pembelian AS mp,
                                master_user AS mu2
                            WHERE
                                DATE_FORMAT(mp.tgl_pembelian, '%Y%m') = CONCAT(YEAR(CURDATE()),'0',MONTH(CURDATE())) AND
                                mp.id_user = mu2.id_user AND
                                mu2.vendor = mv.id AND
                                mu2.id_plant = (
                                                SELECT
                                                    mpc.id_plant
                                                FROM
                                                    master_pic AS mpc
                                                WHERE
                                                    mpc.id_pic = '" . $id_pic . "'
                                                )
                        ) AS realisasi,
                        (
                            SELECT
                                IF(SUM(mu3.target) IS NULL, 0, SUM(mu3.target))
                            FROM
                                master_user AS mu3
                            WHERE
                                mu3.vendor = mv.id AND
                                mu3.id_plant = (
                                                SELECT
                                                    mpc.id_plant
                                                FROM
                                                    master_pic AS mpc
                                                WHERE
                                                    mpc.id_pic = '" . $id_pic . "'
                                                )
                        ) AS target
                    FROM
                        master_vendor AS mv
                    WHERE
                        mv.id IN 	(
                                    SELECT DISTINCT
                                        mu.vendor AS vendor
                                    FROM
                                        master_user as mu
                                    WHERE
                                        mu.id_pic = '" . $id_pic . "' AND
                                        mu.status_karyawan = 'NON PERMANENT'
                                    )
                        ";

        $result = $this->db->query($query);
        return $result;
    }

    function getStatusUserPIC($id_pic){
        $query = "  SELECT
                        DISTINCT mu.status_karyawan AS status	
                    FROM
                        master_user AS mu
                    WHERE
                        mu.aktif = 'AKTIF' AND
                        mu.id_pic = '" . $id_pic . "'
                        ";

        $result = $this->db->query($query);
        return $result;
    }
}