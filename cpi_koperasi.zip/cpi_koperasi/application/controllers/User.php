<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	public function __construct() 
    {
        parent::__construct();
        $this->load->model('M_user', 'user');
        $this->load->model('M_product');
        $this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		// if ($this->session->userdata('status') == 0) {
        //     $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">
        //     Anda Harus Login Dahulu</div>');
        //     redirect('login'); 
        // }
    }
	public function index()
	{
		if($this->session->has_userdata('id_user')){
			$data['master_user'] = $this->user->get_user()->result();
			$data['plant'] = $this->user->get_plant()->result();
			$data['akses'] = $this->user->get_akses()->result();
			$data['pic'] = $this->user->get_pic()->result();
			$data['vendor'] = $this->user->get_vendor()->result();
			$data['department'] = $this->user->get_department()->result();

			// $keyword = $this->input->post('keyword');
			// $data = $this->user->cariDataUser($keyword);
			// $data = array(
			// 	'keyword'	=> $keyword,
			// 	'data'		=> $data
			// );

			// var_dump($data['master_user']);
			$this->load->view('templates/header', $data);
			$this->load->view('user', $data);
			$this->load->view('templates/footer');
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda Harus Login Dahulu</div>');
            redirect('login'); 
		}
	}

	public function showDataUser(){
		$dataUserUpToDate = $this->M_user->showDataUser()->result();

		echo json_encode($dataUserUpToDate);
	}

	public function tambahuser(){
			
        if ($this->input->post()) {
			$isPic = $this->input->post('pic_yesno');
			$aktif = "AKTIF";

			$nama = $this->input->post('nama');
			$no_reg = $this->input->post('no_reg');
			$status_karyawan = $this->input->post('status_karyawan');
			$has_voucher = $this->input->post('has_voucher');
			$target = $this->input->post('target');
			$vendor = $this->input->post('vendor');
			$department = $this->input->post('department');
			$id_plant = $this->input->post('id_plant');
			$id_pic = $this->input->post('id_pic');
			$pic_question = $this->input->post('pic_question');

			if($isPic == 'n'){
				$id_akses = 0;
				$username = null;
				$password = null;
			}else{
				$id_akses = 2;
				$username = $this->input->post('username');
				$password = $this->input->post('password');

				if($pic_question == 'y'){
					$lastIDPIC = $this->user->getLastIDPIC();
					$id_pic = (int)$lastIDPIC[0]->id_pic + 1;
				}
			}

			$this->user->insertNewUser($username, $password, $nama, $no_reg, $status_karyawan, $vendor, $department, $aktif, $id_plant, $id_pic, $target, $id_akses, $has_voucher);
			
			if($isPic == 'y' && $pic_question == 'y'){
				$lastIdUser = $this->user->getLastIdUser();
				$id_user_now = (int)$lastIdUser[0]->id_user;
				$area_pic = $this->input->post('area_pic');

				$this->user->insertNewPIC($id_pic, $id_user_now, $nama, $id_plant, $area_pic);
			}

			redirect('user/index');
    	}
		
	}

	// public function updateDataUser(){
	// 	$id_user_edit = $this->input->post('id_user_edit');
	// 	$username = $this->input->post('username');
	// 	$password = $this->input->post('password');
    //     $nama = $this->input->post('nama');
	// 	$nik = $this->input->post('nik');
	// 	$no_reg = $this->input->post('no_reg');
	// 	$status_karyawan = $this->input->post('status_karyawan');
    //     $vendor = $this->input->post('vendor');
    //     $department = $this->input->post('departemen');
    //     $aktif = $this->input->post('aktif');
    //     $id_plant = $this->input->post('id_plant');
	// 	$id_pic = $this->input->post('id_pic');
	// 	$target = $this->input->post('target');
	// 	$id_akses = $this->input->post('id_akses');
	// 	$voucher = $this->input->post('voucher');

	// 	$this->M_user->updateDataUser($id_user_edit, $username, $password, $nama, $nik, $no_reg, $status_karyawan, $vendor, $department, $aktif, $id_plant, $id_pic, $target, $id_akses, $voucher);

	// 	echo json_encode("Berhasil Update");

	// }

	public function produk()
	{
		if($this->session->has_userdata('id_user')){
			$data['product'] = $this->user->get_product()->result();
			
			$harga = $this->user->get_harga()->result();
			foreach($harga as $h){
				$hargaPass = $h->harga;
			}

			$data['harga'] = $hargaPass;
			$data['master_user'] = $this->db->get_where('master_user', ['id_user' => $this->session->userdata('id_user')])->row_array();
			//$data['product'] = $this->db->get_where('product', ['id_product' => $this->session->userdata('id_user')])->row_array();
			$this->load->view('templates/header', $data);
			$this->load->view('produk', $data);
			$this->load->view('templates/footer');
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda Harus Login Dahulu</div>');
            redirect('login'); 
		}
	}

	public function tambahproduk()
	{
		if ($this->input->post()) {
			$nama_produk = $this->input->post('nama_produk');
			$harga = $this->input->post('harga');
            $tambah = array(
				'nama_produk' => $nama_produk,
				'harga' => $harga,
            );
            $this->db->insert('product', $tambah);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data User Berhasil Ditambah</div>');
            redirect('user/produk');
        } else {
            $data['product'] = $this->user->get_product()->result();
			$this->load->view('templates/header', $data);
			$this->load->view('user', $data);
			$this->load->view('templates/footer');
    }

		$data['product'] = $this->user->get_product()->result();
		$data['master_user'] = $this->db->get_where('master_user', ['id_user' => $this->session->userdata('id_user')])->row_array();
		//$data['product'] = $this->db->get_where('product', ['id_product' => $this->session->userdata('id_user')])->row_array();
		$this->load->view('templates/header', $data);
		$this->load->view('produk', $data);
		$this->load->view('templates/footer');
	
	}

	public function editProduk(){
		$nama = $this->input->post('nama_produk');
		$harga = $this->input->post('harga');
		$harga_past = $this->input->post('harga_past');
		$stock = $this->input->post('stock');
		$stock_past = $this->input->post('stock_past');
		$id_product = $this->input->post('id_product');
		$cek_update = 0;
		$status_update = "all";

		date_default_timezone_set('Asia/Jakarta');
		$tanggal_update = date('Y-m-d H:i:s', time());

		if($harga == $harga_past){
			$cek_update += 1;
			$status_update = "price";
		}

		if($stock == $stock_past){
			$cek_update += 1;
			$status_update = "stock";
		}

		if($cek_update > 1){
			$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda Harus Login Dahulu</div>');
		}

		// if ($this->session->userdata('status') == 0) {
		// 	$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda Harus Login Dahulu</div>');
		// }

		// $this->M_product->insertNewDetailProductPrice($id_product, $harga, $tanggal_update);
		// $this->M_product->insertNewDetailProductStock($id_product, $stock, $tanggal_update);
		// $this->M_product->updateProduct($id_product, $harga, $stock);

		// $this->produk();

	}

	public function deleteUser(){
		$id_user = $this->input->post('id_user');
		$this->user->deleteUser($id_user);
		$this->index();
	}

	public function getUser(){
		$id_user = $this->input->post('id_user_del');
		$dataUser = $this->user->getUser($id_user)->result();
		echo json_encode($dataUser);
	}

	public function getDataUSerDetail($id_user)
	{
		$this->db->where('id_user',$id_user);
		$query = $this->db->get('master_user');
		return $query->row();
	}

	public function editUser(){
		$idUser = $this->input->post('id_user');
		$username = $this->input->post('username_edit');
		$pass = $this->input->post('password_edit');
		if($pass == null){
			$pass = "";
		}
		$nama = $this->input->post('nama_edit');
		$noreg = $this->input->post('no_reg_edit');
		$status_karyawan = $this->input->post('sts_krywn_edit');
		$vendor = $this->input->post('vendor_edit');
		$department = $this->input->post('department_edit');
		$aktif = $this->input->post('aktif_edit');
		$id_plant = $this->input->post('id_plant_edit');
		$id_pic = $this->input->post('id_pic_edit');
		$target = $this->input->post('target_edit');
		$id_akses = $this->input->post('id_akses_edit');
		$has_voucher = $this->input->post('has_voucher_edit');
		
		if($id_akses == null){
			$id_akses = 0;
		}

		$this->user->updateUser($idUser, $username, $pass, $nama, $noreg, $status_karyawan, $vendor, $department, $aktif, $id_plant, $id_pic, $target, $id_akses, $has_voucher);

		$this->index();

		// echo $aktif;
	}
	public function reportuser()
	{
		if($this->session->has_userdata('id_user')){
			$data['master_user'] = $this->user->get_user()->result();
			$data['plant'] = $this->user->get_plant()->result();
			$data['akses'] = $this->user->get_akses()->result();
			$data['pic'] = $this->user->get_pic()->result();

			// $keyword = $this->input->post('keyword');
			// $data = $this->user->cariDataUser($keyword);
			// $data = array(
			// 	'keyword'	=> $keyword,
			// 	'data'		=> $data
			// );

			// var_dump($data['master_user']);
			$this->load->view('templates/header', $data);
			$this->load->view('report_user', $data);
			$this->load->view('templates/footer');
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda Harus Login Dahulu</div>');
            redirect('login'); 
		}
	}

	function getNamaVendor(){
		$id_vendor = $this->input->post('id_vendor');
		$dataVendor = $this->user->getNamaVendor($id_vendor)->result();
		echo json_encode($dataVendor);
	}
}
