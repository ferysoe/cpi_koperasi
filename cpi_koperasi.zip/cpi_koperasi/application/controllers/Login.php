<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		
		$this->load->helper('form');
        $this->load->helper('url');
		$this->load->library('form_validation');
        $this->load->model('M_login');
	}

	public function index()
	{
        if($this->session->has_userdata('id_user')){
			redirect('Dashboard');
		}else{
			$this->load->view('login');
		}
	}

    public function login(){
        $this->form_validation->set_rules('input_user','Username','required|trim'); // Required Username
        $this->form_validation->set_rules('input_password','Password','required|trim'); // Required Pass
    
        if($this->form_validation->run() == false)
        {
            $this->load->view('login');
        }
        else
        {
            $this->cek_login();
        }
    }

    private function cek_login(){
        $username = $this->input->post('input_user');
		$password = $this->input->post('input_password');

        $password_user = null;
        $akses_user = null;

        $dataUser = $this->M_login->cekUser($username)->result();

        if($dataUser == null){
            $data['error'] = "Username Tidak Terdaftar";
            $this->load->view('login', $data);
        }else{
            foreach($dataUser as $du){
                $password_user = $du->password;
                $akses_user = $du->id_akses;
                $id_user = $du->id_user;
                $nama = $du->nama;
                $id_plant = $du->id_plant;
            }

            $getIdPic = $this->M_login->getIdPic($id_user)->result();

            // var_dump($getIdPic[0]->id_pic);

            foreach($getIdPic as $gip){
                $id_pic = $gip->id_pic;
            }

            // var_dump($id_pic);
            
            if($akses_user > 0){
                if($password == $password_user){
                    $data['id_akses'] = $akses_user;
                    $data['id_user'] = $id_user;
                    $data['id_pic'] = $id_pic;
                    $data['nama'] = $nama;
                    $data['id_plant'] = $id_plant;
                    $this->session->set_userdata($data);

                    var_dump($this->session->userdata('id_pic'));
                    redirect('dashboard'); 
                }else{
                    $data['error'] = "Password Salah";
                    $this->load->view('login', $data);
                }
            }
        }

    }

    function logout(){
        $this->session->unset_userdata('id_akses');
        $this->session->unset_userdata('id_user');
        $this->session->unset_userdata('id_pic');
        $this->session->unset_userdata('nama');

        // var_dump($this->session->all_userdata());
        redirect('Welcome');
    }

}
