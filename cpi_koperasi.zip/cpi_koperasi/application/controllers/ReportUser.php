<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReportUser extends CI_Controller {
    public function __construct() 
    {
        parent::__construct();
        $this->load->model('M_report_user', 'report');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
	{
        // $data['dataUser'] = $this->report->get_user()->result();
        // $data['pic'] = $this->report->get_pic()->result();
        // $data['vendor'] = $this->report->get_vendor()->result();

		// $data['master_user'] = $this->report->get_user()->result();
		// $data['plant'] = $this->report->get_plant()->result();
        // $data['departemen'] = $this->report->get_department();
		// $data['akses'] = $this->user->get_akses()->result();
		// $data['pic'] = $this->user->get_pic()->result();

		// var_dump($data['master_user']);

        $nama = $this->session->userdata('nama');
        $id_user = $this->session->userdata('id_user');
        $id_akses = $this->session->userdata('id_akses');
        $id_pic = $this->session->userdata('id_pic');

        $dataDetailPIC = $this->report->getDetailPIC($id_user)->result();
        
        foreach($dataDetailPIC as $ddp){
            $id_pic = $ddp->id_pic;
        }
        
        $data['id_pic'] = $id_pic;
        $data['vendor'] = $this->report->getVendorUseronPIC($id_pic)->result();
        $data['dataUser'] = $this->report->getDataUseronPIC($id_pic)->result();
        $dataNow['dataNow'] = $this->report->getDataUseronPIC($id_pic)->result();

        $this->session->unset_userdata('dataNow');
        $this->session->set_userdata($dataNow);

        // var_dump($data['dataUser']);
		$this->load->view('templates/header');
		$this->load->view('report_user', $data);
		$this->load->view('templates/footer');
	
	}

    function getDepartment(){
        $vendor = $this->input->post('vendor');
        $id_pic = $this->input->post('id_pic');

        if($vendor == ""){
            $dataDepartment = $this->report->getDepartmentAll($id_pic)->result();
        }else{
            $dataDepartment = $this->report->getDepartmentUseronPIC($id_pic, $vendor)->result();
        }


        echo json_encode($dataDepartment);
    }

    function getDatabyVendor(){
        $vendor = $this->input->post('vendor');
        $id_pic = $this->input->post('id_pic');

        $dataByVendor = $this->report->getDatabyVendor($id_pic, $vendor)->result();
        $dataNow['dataNow'] = $this->report->getDatabyVendor($id_pic, $vendor)->result();

        $this->session->unset_userdata('dataNow');
        $this->session->set_userdata($dataNow);

        echo json_encode($dataByVendor);
    }

    function getDatabyDepartment(){
        $department = $this->input->post('department');
        $id_pic = $this->input->post('id_pic');

        $dataByDepartment = $this->report->getDatabyDepartment($id_pic, $department)->result();
        $dataNow['dataNow'] = $this->report->getDatabyDepartment($id_pic, $department)->result();

        $this->session->unset_userdata('dataNow');
        $this->session->set_userdata($dataNow);
        

        echo json_encode($dataByDepartment);
    }

    function getDatabyVendor_Department(){
        $vendor = $this->input->post('vendor');
        $department = $this->input->post('department');
        $id_pic = $this->input->post('id_pic');

        $dataByVendor_Department = $this->report->getDatabyVendor_Department($id_pic, $department, $vendor)->result();
        $dataNow['dataNow'] = $this->report->getDatabyVendor_Department($id_pic, $department, $vendor)->result();

        $this->session->unset_userdata('dataNow');
        $this->session->set_userdata($dataNow);

        echo json_encode($dataByVendor_Department);
    }

    function print_data(){

        $data['dataPrint'] = $this->session->userdata('dataNow');
        
		$this->load->view('print/excelExportReportUser', $data);

        // var_dump($this->session->userdata('dataNow'));
		
    }

    public function indexkop()
	{
        // $data['dataUser'] = $this->report->get_user()->result();
        // $data['pic'] = $this->report->get_pic()->result();
        // $data['vendor'] = $this->report->get_vendor()->result();

		// $data['master_user'] = $this->report->get_user()->result();
		// $data['plant'] = $this->report->get_plant()->result();
        // $data['departemen'] = $this->report->get_department();
		// $data['akses'] = $this->user->get_akses()->result();
		// $data['pic'] = $this->user->get_pic()->result();

		// var_dump($data['master_user']);

        $nama = $this->session->userdata('nama');
        $id_user = $this->session->userdata('id_user');
        $id_akses = $this->session->userdata('id_akses');
        $id_pic = $this->session->userdata('id_pic');

        $dataDetailPIC = $this->report->getDetailPIC($id_user)->result();
        
        foreach($dataDetailPIC as $ddp){
            $id_pic = $ddp->id_pic;
        }
        
        $data['id_pic'] = $id_pic;
        $data['tampil_pic'] = $this->report->getDataPIC($id_pic)->result();
        $data['vendor'] = $this->report->getVendorUseronPIC($id_pic)->result();
        $data['dataUser'] = $this->report->getDataUseronPIC($id_pic)->result();
        $dataNow['dataNow'] = $this->report->getDataUseronPIC($id_pic)->result();

        $this->session->unset_userdata('dataNow');
        $this->session->set_userdata($dataNow);

        // var_dump($data['dataUser']);
		$this->load->view('templates/header');
		$this->load->view('report_user_kop', $data);
		$this->load->view('templates/footer');
	
	}
    
    function getDatabyPIC(){
        // $department = $this->input->post('department');
        $id_pic = $this->input->post('id_pic');
        // $id_pic = "1";

        $namaPIC = $this->report->getNamaPIC($id_pic)->result();
        $dataByPIC = $this->report->getDataUseronPIC($id_pic)->result();
        $dataNow['dataNow'] = $this->report->getDataUseronPIC($id_pic)->result();

        foreach($namaPIC as $np){
            $namaPICPass = $np->nama;
        }

        $dataNow['namaPIC'] = $namaPICPass;

        $this->session->unset_userdata('dataNow');
        $this->session->set_userdata($dataNow);

        // var_dump($dataByPIC);
        
        echo json_encode($dataByPIC);
        // echo json_encode($id_pic);
    }
}