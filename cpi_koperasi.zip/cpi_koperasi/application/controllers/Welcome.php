<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->helper('form');
        $this->load->helper('url');
		$this->load->library('form_validation');
        $this->load->model('M_login');
		$this->load->model('M_user', 'user');
	}

	public function index()
	{
		if($this->session->has_userdata('id_user')){
			redirect('Dashboard');
		}else{
			$data['target'] = $this->user->jumlahtarget()->result();
			$data['realisasi'] = $this->user->jumlahrealisasi()->result();

			// $data['dataKrian'] = $this->user->getDataPerDeptKrian()->result();
			// $realisasiKrian = $this->user->realisasiKrian()->result();
			// $targetKrian = $this->user->targetKrian()->result();
			
			// foreach($realisasiKrian as $rk){
			// 	$data['realisasiKrian'] = $rk->jumlah;
			// }
			// foreach($targetKrian as $tk){
			// 	$data['targetKrian'] = $tk->target;
			// }

			$data['dataCPIKrian'] = $this->user->dataDeptCPIKrian()->result();
			$realisasiCPIKrian = $this->user->realisasiCPIKrian()->result();
			$targetCPIKrian = $this->user->targetCPIKrian()->result();
			
			foreach($realisasiCPIKrian as $rk){
				$data['realisasiCPIKrian'] = $rk->jumlah;
				$realisasiCPIKrianCal = $rk->jumlah;
			}
			foreach($targetCPIKrian as $tk){
				$data['targetCPIKrian'] = $tk->target;
				$targetCPIKrianCal = $tk->target;
			}

			if($targetCPIKrianCal <= 0){
				if($realisasiCPIKrianCal <= 0){
					$persentaseCPIKrian = 0;
				}else{
					$persentaseCPIKrian = 100;
				}
			}else{
				if($realisasiCPIKrianCal <= 0){
					$persentaseCPIKrian = 0;
				}else{
					$persentaseCPIKrian = ($realisasiCPIKrianCal/$targetCPIKrianCal) * 100;
					// $persentaseCPIKrian = round($realisasiCPIKrianCal/$targetCPIKrianCal) * 100;
				}
			}

			$data['persentaseCPIKrian'] = number_format((float)$persentaseCPIKrian, 1, '.', '');
			
			$data['dataOSKrian'] = $this->user->dataOSKrian()->result();
			$realisasiOSKrian = $this->user->realisasiOSKrian()->result();
			$targetOSKrian = $this->user->targetOSKrian()->result();
			
			foreach($realisasiOSKrian as $rok){
				$data['realisasiOSKrian'] = $rok->jumlah;
				$realisasiOSKrianCal = $rok->jumlah;
			}
			foreach($targetOSKrian as $tok){
				$data['targetOSKrian'] = $tok->target;
				$targetOSKrianCal = $tok->target;
			}

			if($targetOSKrianCal <= 0){
				if($realisasiOSKrianCal <= 0){
					$persentaseOSKrian = 0;
				}else{
					$persentaseOSKrian = 100;
				}
			}else{
				if($realisasiOSKrianCal <= 0){
					$persentaseOSKrian = 0;
				}else{
					$persentaseOSKrian = ($realisasiOSKrianCal/$targetOSKrianCal) * 100;
				}
			}

			$data['persentaseOSKrian'] = number_format((float)$persentaseOSKrian, 1, '.', '');

			// $data['dataSepanjang'] = $this->user->getDataPerDeptSepanjang()->result();
			// $realisasiSpj = $this->user->realisasiSpj()->result();
			// $targetSpj = $this->user->targetSpj()->result();

			// foreach($realisasiSpj as $rs){
			// 	$data['realisasiSpj'] = $rs->jumlah;
			// }
			// foreach($targetSpj as $ts){
			// 	$data['targetSpj'] = $ts->target;
			// }

			$data['dataCPISepanjang'] = $this->user->dataDeptCPISepanjang()->result();
			$realisasiCPISepanjang = $this->user->realisasiCPISepanjang()->result();
			$targetCPISepanjang = $this->user->targetCPISepanjang()->result();
			
			foreach($realisasiCPISepanjang as $rs){
				$data['realisasiCPISepanjang'] = $rs->jumlah;
				$realisasiCPISepanjangCal = $rs->jumlah;
			}
			foreach($targetCPISepanjang as $ts){
				$data['targetCPISepanjang'] = $ts->target;
				$targetCPISepanjangCal = $ts->target;
			}

			if($targetCPISepanjangCal <= 0){
				if($realisasiCPISepanjangCal <= 0){
					$persentaseCPISepanjang = 0;
				}else{
					$persentaseCPISepanjang = 100;
				}
			}else{
				if($realisasiCPISepanjangCal <= 0){
					$persentaseCPISepanjang = 0;
				}else{
					$persentaseCPISepanjang = ($realisasiCPISepanjangCal/$targetCPISepanjangCal) * 100;
				}
			}

			$data['persentaseCPISepanjang'] = number_format((float)$persentaseCPISepanjang, 1, '.', '');

			$data['dataOSSepanjang'] = $this->user->dataOSSepanjang()->result();
			$realisasiOSSepanjang = $this->user->realisasiOSSepanjang()->result();
			$targetOSSepanjang = $this->user->targetOSSepanjang()->result();
			
			foreach($realisasiOSSepanjang as $ros){
				$data['realisasiOSSepanjang'] = $ros->jumlah;
				$realisasiOSSepanjangCal = $ros->jumlah;
			}
			foreach($targetOSSepanjang as $tos){
				$data['targetOSSepanjang'] = $tos->target;
				$targetOSSepanjangCal = $tos->target;
			}

			if($targetOSSepanjangCal <= 0){
				if($realisasiOSSepanjangCal <= 0){
					$persentaseOSSepanjang = 0;
				}else{
					$persentaseOSSepanjang = 100;
				}
			}else{
				if($realisasiOSSepanjangCal <= 0){
					$persentaseOSSepanjang = 0;
				}else{
					$persentaseOSSepanjang = ($realisasiOSSepanjangCal/$targetOSSepanjangCal) * 100;
				}
			}

			$data['persentaseOSSepanjang'] = number_format((float)$persentaseOSSepanjang, 1, '.', '');

			// $data['dataPremix'] = $this->user->getDataPerDeptPremix()->result();
			// $realisasiPremix = $this->user->realisasiPremix()->result();
			// $targetPremix = $this->user->targetPremix()->result();

			// foreach($realisasiPremix as $rp){
			// 	$data['realisasiPremix'] = $rp->jumlah;
			// }
			// foreach($targetPremix as $tp){
			// 	$data['targetPremix'] = $tp->target;
			// }
				
			$data['dataCPISPremix'] = $this->user->dataDeptCPIPremix()->result();
			$realisasiCPIPremix = $this->user->realisasiCPIPremix()->result();
			$targetCPIPremix = $this->user->targetCPIPremix()->result();
			
			foreach($realisasiCPIPremix as $rp){
				$data['realisasiCPIPremix'] = $rp->jumlah;
				$realisasiCPIPremixCal = $rp->jumlah;
			}
			foreach($targetCPIPremix as $tp){
				$data['targetCPIPremix'] = $tp->target;
				$targetCPIPremixCal = $tp->target;
			}

			if($targetCPIPremixCal <= 0){
				if($realisasiCPIPremixCal <= 0){
					$persentaseCPIPremix = 0;
				}else{
					$persentaseCPIPremix = 100;
				}
			}else{
				if($realisasiCPIPremixCal <= 0){
					$persentaseCPIPremix = 0;
				}else{
					$persentaseCPIPremix = ($realisasiCPIPremixCal/$targetCPIPremixCal) * 100;
				}
			}

			$data['persentaseCPIPremix'] = number_format((float)$persentaseCPIPremix, 1, '.', '');

			$data['dataOSPremix'] = $this->user->dataOSPremix()->result();
			$realisasiOSPremix = $this->user->realisasiOSPremix()->result();
			$targetOSPremix = $this->user->targetOSPremix()->result();
			
			foreach($realisasiOSPremix as $rop){
				$data['realisasiOSPremix'] = $rop->jumlah;
				$realisasiOSPremixCal = $rop->jumlah;
			}
			foreach($targetOSPremix as $top){
				$data['targetOSPremix'] = $top->target;
				$targetOSPremixCal = $top->target;
			}

			if($targetOSPremixCal <= 0){
				if($realisasiOSPremixCal <= 0){
					$persentaseOSPremix = 0;
				}else{
					$persentaseOSPremix = 100;
				}
			}else{
				if($realisasiOSPremixCal <= 0){
					$persentaseOSPremix = 0;
				}else{
					$persentaseOSPremix = ($realisasiOSPremixCal/$targetOSPremixCal) * 100;
				}
			}

			$data['persentaseOSPremix'] = number_format((float)$persentaseOSPremix, 1, '.', '');

			$targetPass = $this->user->jumlahtarget()->result();
			$realisasiPass = $this->user->jumlahrealisasi()->result();
			
			$target = $targetPass[0]->target;
			$realisasi = $realisasiPass[0]->jumlah;
			$percentage = ($realisasi / $target) * 100;
			$data['percentage'] = number_format((float)$percentage, 1, '.', '');

			$data['dataExternal'] = $this->user->getDataExternal()->result();
			$data['rekap'] = $this->user->rekap()->result();

			$this->load->view('index', $data);
		}
	}

	public function pembelian()
	{
		$this->load->view('templates/header');
		$this->load->view('pembelian');
		$this->load->view('templates/footer');
	}

	public function data_user()
	{
		$this->load->view('templates/header');
		$this->load->view('user');
		$this->load->view('templates/footer');
	}
	
	public function verifikasi()
	{
		$this->load->view('templates/header');
		$this->load->view('verifikasi');
		$this->load->view('templates/footer');
	}
}
