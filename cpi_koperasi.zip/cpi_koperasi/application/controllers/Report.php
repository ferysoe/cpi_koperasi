<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {
    public function __construct() 
    {
        parent::__construct();
        $this->load->model('M_report', 'report');
        $this->load->helper(array('form', 'url'));
        // if ($this->session->userdata('status') == 0) {
        //     $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">
        //     Anda Harus Login Dahulu</div>');
        //     redirect('login'); 
        // }
    }

    public function index()
	{
        $data['dataUser'] = $this->report->get_user()->result();
        $data['pic'] = $this->report->get_pic()->result();
        $data['vendor'] = $this->report->get_vendor()->result();
		$data['plant'] = $this->report->get_plant()->result();
        $data['department'] = $this->report->get_department()->result_array();
        $data['has_data'] = "No";

		$this->load->view('templates/header', $data);
		$this->load->view('verifikasi', $data);
		$this->load->view('templates/footer');
	
	}

    // function showDataPenjualan(){
    //     $dataPenjualan = $this->report->showDataPenjualan()->result();

    //     // var_dump($dataPenjualan);
    //     echo json_encode($dataPenjualan);
    //     // echo json_encode("test");
    // }

    function cekData(){
        $data['dataUser'] = $this->report->get_user()->result();
        $data['pic'] = $this->report->get_pic()->result();
        $data['vendor'] = $this->report->get_vendor()->result();
        $data['plant'] = $this->report->get_plant()->result();
        $data['department'] = $this->report->get_department()->result_array();

        $start = $this->input->post("start");
        $end = $this->input->post("end");
        $department = $this->input->post("department");
        $vendor = $this->input->post("vendor");

        $mode = "";

        if($start != "" && $end != ""){
            if($start > $end){
                $mode = "error";
                $data['error'] = "Date Start Tidak Boleh Lebih Besar Dari Date End!";
                $data['has_data'] = "No";
            }else{
                if($department != null){
                    if($vendor != null){
                        $mode = "department/vendor/tanggal";
                        $start_bongkar = explode("-",$start);
                        $end_bongkar = explode("-",$end);

                        $start_new = $start_bongkar[2] . "/" . $start_bongkar[1] . "/" . $start_bongkar[0];
                        $end_new = $end_bongkar[2] . "/" . $end_bongkar[1] . "/" . $end_bongkar[0];

                        $range_tanggal = $start_new . " - " . $end_new;

                        $data['rangeTanggal'] = $range_tanggal;
                        $data['departmentSelected'] = $department;

                        $dataPrint['rangeTanggal'] = $range_tanggal;
                        $dataPrint['departmentSelected'] = $department;
                    }else{
                        $mode = "department/tanggal";
                        $start_bongkar = explode("-",$start);
                        $end_bongkar = explode("-",$end);

                        $start_new = $start_bongkar[2] . "/" . $start_bongkar[1] . "/" . $start_bongkar[0];
                        $end_new = $end_bongkar[2] . "/" . $end_bongkar[1] . "/" . $end_bongkar[0];

                        $range_tanggal = $start_new . " - " . $end_new;

                        $data['rangeTanggal'] = $range_tanggal;
                        $data['departmentSelected'] = $department;

                        $dataPrint['rangeTanggal'] = $range_tanggal;
                        $dataprint['departmentSelected'] = $department;
                    }
                }else{
                    if($vendor != null){
                        $mode = "vendor/tanggal";
                        $start_bongkar = explode("-",$start);
                        $end_bongkar = explode("-",$end);

                        $start_new = $start_bongkar[2] . "/" . $start_bongkar[1] . "/" . $start_bongkar[0];
                        $end_new = $end_bongkar[2] . "/" . $end_bongkar[1] . "/" . $end_bongkar[0];

                        $range_tanggal = $start_new . " - " . $end_new;

                        $data['rangeTanggal'] = $range_tanggal;

                        $dataPrint['rangeTanggal'] = $range_tanggal;
                    }else{
                        $mode = "tanggal";
                        $start_bongkar = explode("-",$start);
                        $end_bongkar = explode("-",$end);

                        $start_new = $start_bongkar[2] . "/" . $start_bongkar[1] . "/" . $start_bongkar[0];
                        $end_new = $end_bongkar[2] . "/" . $end_bongkar[1] . "/" . $end_bongkar[0];

                        $range_tanggal = $start_new . " - " . $end_new;

                        $data['rangeTanggal'] = $range_tanggal;
                        
                        $dataPrint['rangeTanggal'] = $range_tanggal;
                    }
                }
            }
        }elseif($start == null && $end == null){
            if($department != null){
                if($vendor != null){
                    $mode = "department/vendor";
                    $data['departmentSelected'] = $department;
                    $dataPrint['departmentSelected'] = $department;
                }else{
                    $mode = "department";
                    $data['departmentSelected'] = $department;
                    $dataPrint['departmentSelected'] = $department;
                }
            }else{
                if($vendor != null){
                    $mode = "vendor";
                }else{
                    $mode = "error";
                    $data['error'] = "Harap Mengisi Data yang Ingin Dicari!";
                    $data['has_data'] = "No";
                }
            }
        }elseif($start != null || $end != null){
            $mode = "error";
            $data['error'] = "Harap Mengisi Date Start / Date End!";
            $data['has_data'] = "No";
        }

        $dataPrint['mode'] = $mode;

        if($mode == "tanggal"){

            $result = $this->report->dataTanggal($start, $end)->result();
            $jumlahAyam = $this->report->dataTanggal_jumlahPenjualan($start, $end)->result();
            $jumlahVoucher = $this->report->dataTanggal_jumlahVoucher($start, $end)->result();
            $jumlahCash = $this->report->dataTanggal_jumlahCash($start, $end)->result();
            $jumlahPayroll = $this->report->dataTanggal_jumlahPayroll($start, $end)->result();
            $jumlahUang = $this->report->dataTanggal_jumlahUang($start, $end)->result();

            foreach($jumlahAyam as $ja){
                $jumlahAyamPass = $ja->jumlah;
            }
            foreach($jumlahVoucher as $jv){
                $jumlahVoucherPass = $jv->jumlah_voucher;
            }
            foreach($jumlahCash as $jc){
                $jumlahCashPass = $jc->jumlah_cash;
            }
            foreach($jumlahPayroll as $jp){
                $jumlahPayrollPass = $jp->jumlah_payroll;
            }
            foreach($jumlahUang as $ju){
                $jumlahUangPass = $ju->jumlah_uang;
            }

            $data['printData'] = $result;
            $data['jumlahAyam'] = $jumlahAyamPass;
            $data['jumlahVoucher'] = $jumlahVoucherPass;
            $data['jumlahCash'] = $jumlahCashPass;
            $data['jumlahPayroll'] = $jumlahPayrollPass;
            $data['jumlahUang'] = $jumlahUangPass;
            $data['has_data'] = "Yes";

            $dataPrint['dataPrint'] = $result;

        }elseif($mode == "department/tanggal"){

            $result = $this->report->dataDeptTanggal($start, $end, $department)->result();
            $jumlahAyam = $this->report->dataDeptTanggal_jumlahPenjualan($start, $end, $department)->result();
            $jumlahVoucher = $this->report->dataDeptTanggal_jumlahVoucher($start, $end, $department)->result();
            $jumlahCash = $this->report->dataDeptTanggal_jumlahCash($start, $end, $department)->result();
            $jumlahPayroll = $this->report->dataDeptTanggal_jumlahPayroll($start, $end, $department)->result();
            $jumlahUang = $this->report->dataDeptTanggal_jumlahUang($start, $end, $department)->result();

            foreach($jumlahAyam as $ja){
                $jumlahAyamPass = $ja->jumlah;
            }
            foreach($jumlahVoucher as $jv){
                $jumlahVoucherPass = $jv->jumlah_voucher;
            }
            foreach($jumlahCash as $jc){
                $jumlahCashPass = $jc->jumlah_cash;
            }
            foreach($jumlahPayroll as $jp){
                $jumlahPayrollPass = $jp->jumlah_payroll;
            }
            foreach($jumlahUang as $ju){
                $jumlahUangPass = $ju->jumlah_uang;
            }

            $data['printData'] = $result;
            $data['jumlahAyam'] = $jumlahAyamPass;
            $data['jumlahVoucher'] = $jumlahVoucherPass;
            $data['jumlahCash'] = $jumlahCashPass;
            $data['jumlahPayroll'] = $jumlahPayrollPass;
            $data['jumlahUang'] = $jumlahUangPass;
            $data['has_data'] = "Yes";

            $dataPrint['dataPrint'] = $result;

        }elseif($mode == "department"){

            $result = $this->report->dataDept($department)->result();
            $jumlahAyam = $this->report->dataDept_jumlahPenjualan($department)->result();
            $jumlahVoucher = $this->report->dataDept_jumlahVoucher($department)->result();
            $jumlahCash = $this->report->dataDept_jumlahCash($department)->result();
            $jumlahPayroll = $this->report->dataDept_jumlahPayroll($department)->result();
            $jumlahUang = $this->report->dataDept_jumlahUang($department)->result();

            foreach($jumlahAyam as $ja){
                $jumlahAyamPass = $ja->jumlah;
            }
            foreach($jumlahVoucher as $jv){
                $jumlahVoucherPass = $jv->jumlah_voucher;
            }
            foreach($jumlahCash as $jc){
                $jumlahCashPass = $jc->jumlah_cash;
            }
            foreach($jumlahPayroll as $jp){
                $jumlahPayrollPass = $jp->jumlah_payroll;
            }
            foreach($jumlahUang as $ju){
                $jumlahUangPass = $ju->jumlah_uang;
            }

            $data['printData'] = $result;
            $data['jumlahAyam'] = $jumlahAyamPass;
            $data['jumlahVoucher'] = $jumlahVoucherPass;
            $data['jumlahCash'] = $jumlahCashPass;
            $data['jumlahPayroll'] = $jumlahPayrollPass;
            $data['jumlahUang'] = $jumlahUangPass;
            $data['has_data'] = "Yes";

            $dataPrint['dataPrint'] = $result;

        }elseif($mode == "vendor"){

            $result = $this->report->dataVendor($vendor)->result();
            $vendorShow = $this->report->getNamaVendor($vendor)->result();
            $jumlahAyam = $this->report->dataVendor_jumlahPenjualan($vendor)->result();
            $jumlahVoucher = $this->report->dataVendor_jumlahVoucher($vendor)->result();
            $jumlahCash = $this->report->dataVendor_jumlahCash($vendor)->result();
            $jumlahPayroll = $this->report->dataVendor_jumlahPayroll($vendor)->result();
            $jumlahUang = $this->report->dataVendor_jumlahUang($vendor)->result();

            foreach($vendorShow as $vs){
                $vendorShowPass = $vs->keterangan;
            }
            foreach($jumlahAyam as $ja){
                $jumlahAyamPass = $ja->jumlah;
            }
            foreach($jumlahVoucher as $jv){
                $jumlahVoucherPass = $jv->jumlah_voucher;
            }
            foreach($jumlahCash as $jc){
                $jumlahCashPass = $jc->jumlah_cash;
            }
            foreach($jumlahPayroll as $jp){
                $jumlahPayrollPass = $jp->jumlah_payroll;
            }
            foreach($jumlahUang as $ju){
                $jumlahUangPass = $ju->jumlah_uang;
            }

            $data['printData'] = $result;
            $data['vendorShow'] = $vendorShowPass;
            $data['jumlahAyam'] = $jumlahAyamPass;
            $data['jumlahVoucher'] = $jumlahVoucherPass;
            $data['jumlahCash'] = $jumlahCashPass;
            $data['jumlahPayroll'] = $jumlahPayrollPass;
            $data['jumlahUang'] = $jumlahUangPass;
            $data['has_data'] = "Yes";
            
            $dataPrint['dataPrint'] = $result;
            $dataPrint['vendorShow'] = $vendorShowPass;

        }elseif($mode == "vendor/tanggal"){

            $result = $this->report->dataVendorTanggal($vendor, $start, $end)->result();
            $vendorShow = $this->report->getNamaVendor($vendor)->result();
            $jumlahAyam = $this->report->dataVendorTanggal_jumlahPenjualan($vendor, $start, $end)->result();
            $jumlahVoucher = $this->report->dataVendorTanggal_jumlahVoucher($vendor, $start, $end)->result();
            $jumlahCash = $this->report->dataVendorTanggal_jumlahCash($vendor, $start, $end)->result();
            $jumlahPayroll = $this->report->dataVendorTanggal_jumlahPayroll($vendor, $start, $end)->result();
            $jumlahUang = $this->report->dataVendorTanggal_jumlahUang($vendor, $start, $end)->result();

            foreach($vendorShow as $vs){
                $vendorShowPass = $vs->keterangan;
            }
            foreach($jumlahAyam as $ja){
                $jumlahAyamPass = $ja->jumlah;
            }
            foreach($jumlahVoucher as $jv){
                $jumlahVoucherPass = $jv->jumlah_voucher;
            }
            foreach($jumlahCash as $jc){
                $jumlahCashPass = $jc->jumlah_cash;
            }
            foreach($jumlahPayroll as $jp){
                $jumlahPayrollPass = $jp->jumlah_payroll;
            }
            foreach($jumlahUang as $ju){
                $jumlahUangPass = $ju->jumlah_uang;
            }

            $data['printData'] = $result;
            $data['vendorShow'] = $vendorShowPass;
            $data['jumlahAyam'] = $jumlahAyamPass;
            $data['jumlahVoucher'] = $jumlahVoucherPass;
            $data['jumlahCash'] = $jumlahCashPass;
            $data['jumlahPayroll'] = $jumlahPayrollPass;
            $data['jumlahUang'] = $jumlahUangPass;
            $data['has_data'] = "Yes";
            
            $dataPrint['dataPrint'] = $result;
            $dataPrint['vendorShow'] = $vendorShowPass;

        }elseif($mode == "department/vendor/tanggal"){

            $result = $this->report->dataDeptVendorTanggal($department, $vendor, $start, $end)->result();
            $vendorShow = $this->report->getNamaVendor($vendor)->result();
            $jumlahAyam = $this->report->dataDeptVendorTanggal_jumlahPenjualan($department, $vendor, $start, $end)->result();
            $jumlahVoucher = $this->report->dataDeptVendorTanggal_jumlahVoucher($department, $vendor, $start, $end)->result();
            $jumlahCash = $this->report->dataDeptVendorTanggal_jumlahCash($department, $vendor, $start, $end)->result();
            $jumlahPayroll = $this->report->dataDeptVendorTanggal_jumlahPayroll($department, $vendor, $start, $end)->result();
            $jumlahUang = $this->report->dataDeptVendorTanggal_jumlahUang($department, $vendor, $start, $end)->result();

            foreach($vendorShow as $vs){
                $vendorShowPass = $vs->keterangan;
            }
            foreach($jumlahAyam as $ja){
                $jumlahAyamPass = $ja->jumlah;
            }
            foreach($jumlahVoucher as $jv){
                $jumlahVoucherPass = $jv->jumlah_voucher;
            }
            foreach($jumlahCash as $jc){
                $jumlahCashPass = $jc->jumlah_cash;
            }
            foreach($jumlahPayroll as $jp){
                $jumlahPayrollPass = $jp->jumlah_payroll;
            }
            foreach($jumlahUang as $ju){
                $jumlahUangPass = $ju->jumlah_uang;
            }

            $data['printData'] = $result;
            $data['vendorShow'] = $vendorShowPass;
            $data['jumlahAyam'] = $jumlahAyamPass;
            $data['jumlahVoucher'] = $jumlahVoucherPass;
            $data['jumlahCash'] = $jumlahCashPass;
            $data['jumlahPayroll'] = $jumlahPayrollPass;
            $data['jumlahUang'] = $jumlahUangPass;
            $data['has_data'] = "Yes";

            $dataPrint['dataPrint'] = $result;
            $dataPrint['vendorShow'] = $vendorShowPass;

        }else{
            $data['has_data'] = "No";
        }

        $data['mode'] = $mode;

        $this->session->unset_userdata('dataPrint');
        $this->session->set_userdata($dataPrint);
        
        $this->load->view('templates/header', $data);
        $this->load->view('verifikasi', $data);
        $this->load->view('templates/footer');
    }

    function getDepartmentPerVendor(){
        $id_vendor = $this->input->post('id_vendor');
        if($id_vendor == null){
            $department = $this->report->get_department()->result();
        }else{
            $department = $this->report->getDepartmentPerVendor($id_vendor)->result();
        }
        echo json_encode($department);
    }

    function print_data(){
        $modeNow = $this->session->userdata('mode');
        // var_dump($modeNow);

        if($mode != "error"){
            $data['dataPrint'] = $this->session->userdata('dataPrint');
            $data['rangeTanggal'] = $this->session->userdata('rangeTanggal');
            $data['departmentSelected'] = $this->session->userdata('departmentSelected');
            $data['vendorShow'] = $this->session->userdata('vendorShow');
            $data['mode'] = $this->session->userdata('mode');
            
            $this->load->view('print/excelExportReportPenjualan', $data);
        }

    }
}