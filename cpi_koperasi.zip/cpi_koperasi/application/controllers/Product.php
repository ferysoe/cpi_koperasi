<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	public function __construct() 
    {
        parent::__construct();
        $this->load->model('M_product');
        $this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
    }
	public function index()
	{

	}

    function getProduct(){
        $id_product = $this->input->post('id_product');
        $dataProduct = $this->M_product->getProductperID($id_product)->result();

        // var_dump($dataProduct);
        echo json_encode($dataProduct);
    }

    function updateStock(){
        $stock = $this->input->post('stock_new');
        $stockAkhir = $this->input->post('stock_akhir');
        $id_product = $this->input->post('id_product');
        date_default_timezone_set('Asia/Jakarta');
		$tanggal_update = date('Y-m-d H:i:s', time());
        // $id_product = "1";

        $this->M_product->insertNewDetailProductStock($id_product, $stock, $tanggal_update, $stockAkhir);
        $this->M_product->updateProductStock($id_product, $stockAkhir);

        // var_dump($dataProduct);
        echo json_encode("Berhasil Update Stock");
    }

    function updateHarga(){
        $harga = $this->input->post('harga_new');
        date_default_timezone_set('Asia/Jakarta');
		$tanggal_update = date('Y-m-d H:i:s', time());
        $id_product = "1";
        $this->M_product->insertNewDetailProductPrice($id_product, $harga, $tanggal_update);
        $this->M_product->updateProductPrice($id_product, $harga);
        
        $id_product = "4";
        $this->M_product->insertNewDetailProductPrice($id_product, $harga, $tanggal_update);
        $this->M_product->updateProductPrice($id_product, $harga);

        // var_dump($dataProduct);
        echo json_encode("Berhasil Update Harga");
    }

    function updateAll(){
        $stock = $this->input->post('stock_new');
        $harga = $this->input->post('harga_new');
        date_default_timezone_set('Asia/Jakarta');
		$tanggal_update = date('Y-m-d H:i:s', time());
        $id_product = "1";

        $this->M_product->insertNewDetailProductStock($id_product, $stock, $tanggal_update);
        $this->M_product->insertNewDetailProductPrice($id_product, $harga, $tanggal_update);
        $this->M_product->updateProduct($id_product, $harga, $stock);

        // var_dump($dataProduct);
        echo json_encode("Berhasil Update Product");
    }
}
