<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		
		$this->load->helper('form'); 
        $this->load->helper('url');
		$this->load->library('form_validation');
        $this->load->model('M_login');
		$this->load->model('M_user', 'user');
		// if ($this->session->userdata('status') == 0) {
        //     $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">
        //     Anda Harus Login Dahulu</div>');
        //     redirect('login'); 
        // }
	}

	public function index()
	{
        // $data['id_akses'] =  $this->session->userdata('id_akses');
        // $data['id_user'] = $this->session->userdata('id_user');
        // $data['id_pic'] = $this->session->userdata('id_pic');
        // $data['nama'] = $this->session->userdata('nama');
		
		// var_dump($data);

		// echo '<pre>'; print_r($this->session->all_userdata());exit;
		//$data = $this->user->jumlahtarget()->result();

		if($this->session->has_userdata('id_user')){
			$data['target'] = $this->user->jumlahtarget()->result();
			$data['realisasi'] = $this->user->jumlahrealisasi()->result();
			$targetPass = $this->user->jumlahtarget()->result();
			$realisasiPass = $this->user->jumlahrealisasi()->result();
			
			$target = $targetPass[0]->target;
			$realisasi = $realisasiPass[0]->jumlah;
			$percentage = ($realisasi / $target) * 100;
			$data['percentage'] = number_format((float)$percentage, 1, '.', '');

			$data['dataKrian'] = $this->user->getDataPerAreaKrian()->result();
			$data['dataOSKrian'] = $this->user->dataOSKrian()->result();
			$data['realisasiKrian'] = $this->user->realisasiKrian()->result();
			$data['targetKrian'] = $this->user->targetKrian()->result();

			$data['dataSepanjang'] = $this->user->getDataPerAreaSepanjang()->result();
			$data['dataOSSepanjang'] = $this->user->dataOSSepanjang()->result();
			$data['realisasiSpj'] = $this->user->realisasiSpj()->result();
			$data['targetSpj'] = $this->user->targetSpj()->result();

			$data['dataPremix'] = $this->user->getDataPerAreaPremix()->result();
			$data['dataOSPremix'] = $this->user->dataOSPremix()->result();
			$data['realisasiPremix'] = $this->user->realisasiPremix()->result();
			$data['targetPremix'] = $this->user->targetPremix()->result();
			
			$this->load->view('templates/header', $data);
			$this->load->view('index2', $data);
			$this->load->view('templates/footer');
			// var_dump($data['target']);
			//redirect('');
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda Harus Login Dahulu</div>');
            redirect('login'); 
		}
	}

}
