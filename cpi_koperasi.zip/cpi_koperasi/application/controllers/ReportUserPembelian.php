<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReportUserPembelian extends CI_Controller {
    public function __construct() 
    {
        parent::__construct();
        $this->load->model('M_report_user_pembelian', 'report');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
	{
        $nama = $this->session->userdata('nama');
        $id_user = $this->session->userdata('id_user');
        $id_akses = $this->session->userdata('id_akses');
        $id_pic = $this->session->userdata('id_pic');

        $statusUserPass = $this->report->getStatusUserPIC($id_pic)->result();
        $banyakJenisUser = count($statusUserPass);
        if($banyakJenisUser > 1){
            $data['status'] = 'ALL';
        }else{
            foreach($statusUserPass as $sup){
                $data['status'] = $sup->status;
            }
        }
        
        $dataNow['dataNow'] = $this->report->getDataRealisasi($id_pic)->result();
        $dataNow['namaPrint'] = $nama;
        $data['dataUser'] = $this->report->getDataRealisasi($id_pic)->result();
        $data['dataUserOS'] = $this->report->getDataOS($id_pic)->result();

        $realisasiPass = $this->report->getRealisasiPIC($id_pic)->result();
        foreach($realisasiPass as $rp){
            $data['realisasi'] = $rp->realisasi;
        }
        
        $targetPass = $this->report->getTargetPIC($id_pic)->result();
        foreach($targetPass as $tp){
            $data['target'] = $tp->target;
        }
        
        $realisasiPermanentPass = $this->report->getRealisasiPICPermanent($id_pic)->result();
        foreach($realisasiPermanentPass as $rpp){
            $data['realisasiPermanent'] = $rpp->realisasi;
        }

        $targetPermanentPass = $this->report->getTargetPICPermanent($id_pic)->result();
        foreach($targetPermanentPass as $tpp){
            $data['targetPermanent'] = $tpp->target;
        }

        $realisasiOSPass = $this->report->getRealisasiPICOS($id_pic)->result();
        foreach($realisasiOSPass as $rop){
            $data['realisasiOS'] = $rop->realisasi;
        }

        $targetOSPass = $this->report->getTargetPICOS($id_pic)->result();
        foreach($targetOSPass as $top){
            $data['targetOS'] = $top->target;
        }

        $this->session->unset_userdata('dataNow');
        $this->session->set_userdata($dataNow);

		$this->load->view('templates/header');
		$this->load->view('report_user_pembelian', $data);
		$this->load->view('templates/footer');
	
	}

    function print_data(){

        $data['dataPrint'] = $this->session->userdata('dataNow');
        
		$this->load->view('print/excelExportReportUserPembelian', $data);
    }
}