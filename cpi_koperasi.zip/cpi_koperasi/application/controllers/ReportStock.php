<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReportStock extends CI_Controller {
    public function __construct() 
    {
        parent::__construct();
        $this->load->model('M_report_stock', 'report');
        $this->load->helper(array('form', 'url'));
        // if ($this->session->userdata('status') == 0) {
        //     $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">
        //     Anda Harus Login Dahulu</div>');
        //     redirect('login'); 
        // }
    }

    public function index()
	{
        $data['dataUser'] = $this->report->get_user()->result();
        $data['pic'] = $this->report->get_pic()->result();
        $data['vendor'] = $this->report->get_vendor()->result();
		$data['plant'] = $this->report->get_plant()->result();
        $data['department'] = $this->report->get_department()->result_array();
        $data['has_data'] = "No";

		$this->load->view('templates/header', $data);
		$this->load->view('report_stock', $data);
		$this->load->view('templates/footer');
	
	}

    // function showDataPenjualan(){
    //     $dataPenjualan = $this->report->showDataPenjualan()->result();

    //     // var_dump($dataPenjualan);
    //     echo json_encode($dataPenjualan);
    //     // echo json_encode("test");
    // }

    function cekData(){
        $data['dataUser'] = $this->report->get_user()->result();
        $data['pic'] = $this->report->get_pic()->result();
        $data['vendor'] = $this->report->get_vendor()->result();
        $data['plant'] = $this->report->get_plant()->result();
        $data['department'] = $this->report->get_department()->result_array();

        $start = $this->input->post("start");
        $end = $this->input->post("end");
        $department = $this->input->post("department");
        $vendor = $this->input->post("vendor");

        $mode = "";

        if($start != "" && $end != ""){
            if($start > $end){
                $mode = "error";
                $data['error'] = "Date Start Tidak Boleh Lebih Besar Dari Date End!";
                $data['has_data'] = "No";
            }else{
                $mode = "tanggal";
            }
        }elseif($start != null || $end != null){
            $mode = "error";
            $data['error'] = "Harap Mengisi Date Start / Date End!";
            $data['has_data'] = "No";
        }

        

        if($mode == "tanggal"){

            $resultKrian = $this->report->dataRestockKrian($start, $end)->result();
            $resultSepanjang = $this->report->dataRestockSepanjang($start, $end)->result();
            $data['has_data'] = "Yes";
            $data['printDataKrian'] = $resultKrian;
            $data['printDataSepanjang'] = $resultSepanjang;

        }else{
            $data['has_data'] = "No";
        }

        $data['mode'] = $mode;
        
        $this->load->view('templates/header', $data);
        $this->load->view('report_stock', $data);
        $this->load->view('templates/footer');
    }
}