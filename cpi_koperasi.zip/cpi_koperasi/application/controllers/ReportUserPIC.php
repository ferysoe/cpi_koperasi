<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReportUserPIC extends CI_Controller {
    public function __construct() 
    {
        parent::__construct();
        $this->load->model('M_report_user_pic', 'report');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
	{
        $nama = $this->session->userdata('nama');
        $id_user = $this->session->userdata('id_user');
        $id_akses = $this->session->userdata('id_akses');
        $id_pic = $this->session->userdata('id_pic');
        
        $data['dataUser'] = $this->report->getDataUser($id_pic)->result();

		$this->load->view('templates/header');
		$this->load->view('report_user_pic', $data);
		$this->load->view('templates/footer');
	
	}

    function print_data(){

        $data['dataPrint'] = $this->session->userdata('dataNow');
        
		$this->load->view('print/excelExportReportUserPembelian', $data);
    }
}