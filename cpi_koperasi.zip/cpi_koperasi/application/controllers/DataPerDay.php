<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DataPerDay extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		
		$this->load->helper('form'); 
        $this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->model('M_dpd', 'dpd');
	}

	public function index()
	{
		if($this->session->has_userdata('id_user')){
			$data['dpd'] = $this->dpd->dataPerDay()->result();
			$data['dpdPermanentKrian'] = $this->dpd->dataPerDayPermanentKrian()->result();
			$data['dpdPermanentSepanjang'] = $this->dpd->dataPerDayPermanentSepanjang()->result();
			$data['dpdPermanentPremix'] = $this->dpd->dataPerDayPermanentPremix()->result();
			$data['dpdOSKrian'] = $this->dpd->dataPerDayOSKrian()->result();
			$data['dpdOSSepanjang'] = $this->dpd->dataPerDayOSSepanjang()->result();
			$data['dpdOSPremix'] = $this->dpd->dataPerDayOSPremix()->result();
			
			$this->load->view('templates/header', $data);
			$this->load->view('dpd', $data);
			$this->load->view('templates/footer');
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda Harus Login Dahulu</div>');
            redirect('login'); 
		}
	}

}
