<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembelian extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		
        $this->load->model('M_pembelian');
		$this->load->helper('string');
		// if ($this->session->userdata('status') == 0) {
        //     $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">
        //     Anda Harus Login Dahulu</div>');
        //     redirect('login'); 
        // }
	}

	public function index()
	{	
		if($this->session->has_userdata('id_user')){
			// $id_pic = $this->session->userdata('id_pic');
			
			$id_plant = $this->session->userdata('id_plant');
			$stockProduct =  $this->M_pembelian->getStock($id_plant)->result();

			// var_dump($id_plant);
			
			$hargaProduct =  $this->M_pembelian->getHarga($id_plant)->result();
			foreach($stockProduct as $sp){
				$data['stockProduct'] = $sp->stock;
			}
			foreach($hargaProduct as $hp){
				$data['hargaProduct'] = $hp->harga;
			}

			$data['dataUser'] = $this->M_pembelian->getDataUser($id_plant)->result_array();
			$data['id_akses'] =  $this->session->userdata('id_akses');
			$data['id_user'] = $this->session->userdata('id_user');
			$data['id_pic'] = $this->session->userdata('id_pic');
			$data['nama'] = $this->session->userdata('nama');
			$data['id_plant'] = $this->session->userdata('id_plant');

			// var_dump($data['id_plant']);
			// var_dump($data['dataUser']);
			
			$this->load->view('templates/header', $data);
			$this->load->view('pembelian', $data);
			$this->load->view('templates/footer');
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda Harus Login Dahulu</div>');
            redirect('login'); 
		}
	}

	public function pembelian(){
		$id_user = $this->input->post('id_user');						// ID USER

		$status_pembayaran = $this->input->post('status_pembayaran');	// STATUS PEMBAYARAN

		date_default_timezone_set('Asia/Jakarta');
        $dateNow = date('Y-m-d H:i:s', time());

		$jumlah_order = $this->input->post('jumlah');					// JUMLAH ORDER

		$status_konfirmasi = "0";										// STATUS KONFIRMASI
		
		$id_plant = $this->input->post('id_plant');						// ID PLANT
		
		$keterangan = $this->input->post('keterangan');					// KETERANGAN

		$redeem_voucher = $this->input->post('kode_voucher');			// KODE VOUCHER	

		$jumlah_voucher = $this->input->post('jumlah_voucher');			// JUMLAH VOUCHER
		$jumlah_voucher = abs($jumlah_voucher);				

        $dataSebelumnya = $this->M_pembelian->getLastPembelian()->result();

		$flagKembar = false;

		foreach($dataSebelumnya as $ds){
			$dateTest = $ds->tgl_pembelian;
			$id_user_sebelumnya = $ds->id_user;
			$pembayaran = $ds->status_pembayaran;
			$kode_voucher = $ds->kode_redeem_voucher;
			$ket = $ds->keterangan;
			$jumlah_sebelumnya = $ds->jumlah;

			$originalTime = new DateTimeImmutable($dateTest);
			$targedTime = new DateTimeImmutable($dateNow);
			$interval = $originalTime->diff($targedTime);
			// $selisihMenit = $interval->i;
			$selisihDetik = $interval->s;

			if($selisihDetik < 30){
				if($id_user_sebelumnya == $id_user){
					if($status_pembayaran == "Voucher"){
						if($redeem_voucher == $kode_voucher){
							$flagKembar = true;
						}
					}else if($status_pembayaran == $pembayaran){
						if($jumlah_order == $jumlah_sebelumnya){
							if($keterangan == $ket){
								$flagKembar = true;
							}
						}
					}
				}
			}
		}	

		if($flagKembar == false){
			$dataPembelian = $this->M_pembelian->getDataPembelian()->row();
	
			$hargaAyamPass = $this->M_pembelian->getHargaProduct()->row();
			$hargaAyam = $hargaAyamPass->harga;
	
			$year = date("Y"); 
			$month = date("m"); 
	
			if($dataPembelian == null){
				$id_pembelian = $id_user . "/" . $year . "/" . $month . "/00001";	// ID PEMBELIAN
			}else{
				$id_pembelian_last = $dataPembelian->id_pembelian;
	
				$id_pembelian_break = explode("/",$id_pembelian_last);
	
				$urutan = (int)$id_pembelian_break[3];
				$urutan += 1;
				if($id_pembelian_break[2] !== $month){
					$urutan = 1;
				}
				$urutan = (string)$urutan;
	
				$panjangUrutan = strlen($urutan);
	
				$string = "0";
				$codeUrutan = repeater($string, 5 - $panjangUrutan);
	
	
				$id_pembelian = $id_user . "/" . $year . "/" . $month . "/" . $codeUrutan . $urutan;
			}
	
			$total_harga_ayam = $hargaAyam * $jumlah_order;
	
			$total_pembayaran = $total_harga_ayam - ($jumlah_voucher * 25000);
	
			// $voucherUserPass = $this->M_pembelian->getVoucher($id_user)->result();
			// foreach($voucherUserPass as $vup){
			// 	$voucherUser = $vup->voucher;
			// }
	
			// if($total_pembayaran >= $voucherUser){
			// 	$voucherUser = 0;
			// }else{
			// 	$voucherUser = $voucherUser - $total_pembayaran;
			// }
	
			$resultInsert = $this->M_pembelian->insertDataPembelian($id_pembelian, $id_user, $status_pembayaran, $jumlah_order, $status_konfirmasi, $keterangan, $total_pembayaran, $redeem_voucher, $jumlah_voucher, $total_harga_ayam, $id_plant);
	
			$stockPass = $this->M_pembelian->getStock($id_plant)->result();
			foreach($stockPass as $sp){
				$stock = $sp->stock;
			}
	
			$stockNow = $stock - $jumlah_order;
	
			$this->M_pembelian->updateStock($id_plant, $stockNow);
	
			echo json_encode($resultInsert);
		}else{
			$dummyPass = true;
			echo json_encode($dummyPass);
		}
	}

	public function pembelian_pass(){
		$id_plant = $this->input->post('id_plant');						// ID USER	
		$id_user = $this->input->post('id_user');						// ID USER	
		$status_pembayaran = $this->input->post('status_pembayaran');	// STATUS PEMBAYARAN
		$jumlah_order = $this->input->post('jumlah');					// JUMLAH ORDER
		$status_konfirmasi = "0";										// STATUS KONFIRMASI
		$keterangan = $this->input->post('keterangan');					// KETERANGAN
		// $total_pembayaran = $this->input->post('total_pembayaran');		// TOTAL PEMBAYARAN
		$redeem_voucher = $this->input->post('kode_voucher');			// KODE VOUCHER
		$jumlah_voucher = $this->input->post('jumlah_voucher');			// JUMLAH VOUCHER
		$jumlah_voucher = abs($jumlah_voucher);			// JUMLAH VOUCHER

        $dataPembelian = $this->M_pembelian->getDataPembelian()->row();

		// // var_dump($dataPembelian);

		$hargaAyamPass = $this->M_pembelian->getHargaProduct()->row();
		$hargaAyam = $hargaAyamPass->harga;

		$year = date("Y"); 
		$month = date("m"); 

		if($dataPembelian == null){
			$id_pembelian = $id_user . "/" . $year . "/" . $month . "/00001";	// ID PEMBELIAN
		}else{
			$id_pembelian_last = $dataPembelian->id_pembelian;

			$id_pembelian_break = explode("/",$id_pembelian_last);

			$urutan = (int)$id_pembelian_break[3];
			// echo $urutan . "<br>";
			$urutan += 1;
			if($id_pembelian_break[2] !== $month){
				$urutan = 1;
			}
			// echo $urutan;
			$urutan = (string)$urutan;

			$panjangUrutan = strlen($urutan);

			$string = "0";
			// echo repeater($string, 30);
			$codeUrutan = repeater($string, 5 - $panjangUrutan);


			$id_pembelian = $id_user . "/" . $year . "/" . $month . "/" . $codeUrutan . $urutan;
		}

		$total_harga_ayam = $hargaAyam * $jumlah_order;

		$total_pembayaran = $total_harga_ayam - ($jumlah_voucher * 25000);

		// $voucherUserPass = $this->M_pembelian->getVoucher($id_user)->result();
		// foreach($voucherUserPass as $vup){
		// 	$voucherUser = $vup->voucher;
		// }

		// if($total_pembayaran >= $voucherUser){
		// 	$voucherUser = 0;
		// }else{
		// 	$voucherUser = $voucherUser - $total_pembayaran;
		// }

		$resultInsert = $this->M_pembelian->insertDataPembelian($id_pembelian, $id_user, $status_pembayaran, $jumlah_order, $status_konfirmasi, $keterangan, $total_pembayaran, $redeem_voucher, $jumlah_voucher, $total_harga_ayam, $id_plant);

		$stockPass = $this->M_pembelian->getStock($id_plant)->result();
		foreach($stockPass as $sp){
			$stock = $sp->stock;
		}

		$stockNow = $stock - $jumlah_order;

		$this->M_pembelian->updateStock($id_plant, $stockNow);

		echo json_encode($resultInsert);
		// echo json_encode($stockNow);
		// echo json_encode($stockNow);

		// echo json_encode($id_pembelian . " | " . $id_user . " | " . $jumlah_order . " | " . $status_konfirmasi . " | " . $keterangan . " | " . $total_pembayaran . " | " . $redeem_voucher . " | " . $jumlah_voucher . " | " . $total_harga_ayam);
	}

	function getHargaProduk(){
		$hargaAyamPass = $this->M_pembelian->getHargaProduct()->row();
		$hargaAyam = $hargaAyamPass->harga;

		echo json_encode($hargaAyam);
	}

	function showDataPembelian(){
		$id_plant = $this->input->post('id_plant');
		$id_akses = $this->input->post('id_akses');
		// if($id_akses == "3"){
			$dataPembelianUpToDate = $this->M_pembelian->showDataPembelianAll()->result();
		// }else{
			//  $dataPembelianUpToDate = $this->M_pembelian->showDataPembelian($id_plant)->result();
		// }

		echo json_encode($dataPembelianUpToDate);
	}

	function showDataPembelianKoperasi(){
		$id_plant = $this->input->post('id_plant');
		$id_akses = $this->input->post('id_akses');
		// if($id_akses == "3"){
			$dataPembelianUpToDate = $this->M_pembelian->showDataPembelianAllKoperasi()->result();
		// }else{
			//  $dataPembelianUpToDate = $this->M_pembelian->showDataPembelian($id_plant)->result();
		// }

		echo json_encode($dataPembelianUpToDate);
	}

	function deletePembelian(){
		$id_pembelian = $this->input->post('id_pembelian_del');
		$jumlahRestock = $this->M_pembelian->getJumlahperDataPembelian($id_pembelian)->result();

		
		foreach($jumlahRestock as $jr){
			$restock = $jr->jumlah;
			$id_plant = $jr->id_plant_pembelian;
		}
		
		$stockNow = $this->M_pembelian->getStock($id_plant)->result();
		
		foreach($stockNow as $sn){
			$stock = $sn->stock;
		}
		
		$restock = $stock + $restock;

		// var_dump($restock);

		$this->M_pembelian->updateStock($id_plant, $restock);
		$this->M_pembelian->deletePembelian($id_pembelian);

		echo json_encode("Berhasil Delete");
		// echo json_encode($id_pembelian);
	}

	function updatePembelian(){
		$id_pembelian_edit = $this->input->post('id_pembelian_edit');
		$sts_pembayaran = $this->input->post('sts_pmbl_edit');
		$jmlh_edit = $this->input->post('jmlh_edit');
		$ket_edit = $this->input->post('keter_edit');
		$kode_voucher_edit = $this->input->post('kode_vouch_edit');

		$hargaAyamPass = $this->M_pembelian->getHargaProduct()->row();
		$hargaAyam = $hargaAyamPass->harga;

		$total_pembayaran_edit = $hargaAyam * $jmlh_edit;

		$this->M_pembelian->updatePembelian($id_pembelian_edit, $sts_pembayaran, $jmlh_edit, $ket_edit, $total_pembayaran_edit, $kode_voucher_edit);

		echo json_encode("Berhasil Update");
	}

	function getStock(){
		$id_plant = $this->input->post('id_plant');
		$stock = $this->M_pembelian->getStock($id_plant)->result();
		echo json_encode($stock);
	}

	function cekSisaVoucher(){
		$id_pembeli = $this->input->post('id_pembeli');

		$picUserPass = $this->M_pembelian->cekPicUser($id_pembeli)->result();

		foreach($picUserPass as $pup){
			$picUser = $pup->id_pic;
			$vendor = $pup->vendor;
			$plant = $pup->id_plant;
		}

		if($picUser == '998'){
			$sisaVoucher = $this->M_pembelian->cekSisaVoucherVendor($vendor, $plant)->result();
		}else{
			$sisaVoucher = $this->M_pembelian->cekSisaVoucher($id_pembeli)->result();
		}

		// var_dump($sisaVoucher);
		echo json_encode($sisaVoucher);
	}

	function cekPunyaVoucher(){
		$id_pembeli = $this->input->post('id_pembeli');
		// $id_pembeli = "14";
		$punyaVoucher = $this->M_pembelian->cekPunyaVoucher($id_pembeli)->result();
		// var_dump($sisaVoucher);
		echo json_encode($punyaVoucher);
	}

	function statusUser(){
		$id_pembeli = $this->input->post('id_pembeli');
		$status = $this->M_pembelian->statusUser($id_pembeli)->result();
		echo json_encode($status);
	}
}
