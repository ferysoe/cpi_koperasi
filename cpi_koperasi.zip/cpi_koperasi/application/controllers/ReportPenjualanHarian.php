<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReportPenjualanHarian extends CI_Controller {
    public function __construct() 
    {
        parent::__construct();
        $this->load->model('M_report_harian', 'report');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
	{
        
        // $nama = $this->session->userdata('nama');
        // $id_user = $this->session->userdata('id_user');
        // $id_akses = $this->session->userdata('id_akses');
        $id_plant = $this->session->userdata('id_plant');
        $data['report'] = $this->report->getPenjualanHarian($id_plant)->result();
        $dataNow['dataNow'] = $this->report->getPenjualanHarian($id_plant)->result();

        $total_pembayaran = $this->report->getTotalPembayaran($id_plant)->result();
        foreach($total_pembayaran as $tp){
            $data['total_pembayaran'] = $tp->total;
            $dataNow['total_pembayaran'] = $tp->total;
        }

        $jumlah = $this->report->getJumlahPembelian($id_plant)->result();
        foreach($jumlah as $j){
            $data['jumlah'] = $j->jumlah;
            $dataNow['jumlah'] = $j->jumlah;
        }

        $stock = $this->report->getStock($id_plant)->result();
        foreach($stock as $s){
            $data['stock'] = $s->stock;
            $dataNow['stock'] = $s->stock;
        }

        $jVoucher = $this->report->getJumlahVoucher($id_plant)->result();
        foreach($jVoucher as $jv){
            $data['jmlVoucher'] = $jv->jumlah;
            $dataNow['jmlVoucher'] = $jv->jumlah;
        }

        $cash = $this->report->getTotalCash($id_plant)->result();
        foreach($cash as $c){
            $data['cash'] = $c->cash;
            $dataNow['cash'] = $c->cash;
        }

        $voucher = $this->report->getTotalVoucher($id_plant)->result();
        foreach($voucher as $v){
            $data['voucher'] = $v->voucher;
            $dataNow['voucher'] = $v->voucher;
        }

        $payroll = $this->report->getTotalPayroll($id_plant)->result();
        foreach($payroll as $p){
            $data['payroll'] = $p->payroll;
            $dataNow['payroll'] = $p->payroll;
        }

        // var_dump($data['report']);

        $this->session->unset_userdata('dataNow');
        $this->session->set_userdata($dataNow);

		$this->load->view('templates/header');
		$this->load->view('report_penjualan_harian', $data);
		$this->load->view('templates/footer');
	}

    function print_data(){

        $data['dataPrint'] = $this->session->userdata('dataNow');
        $data['total_pembayaran'] = $this->session->userdata('total_pembayaran');
        $data['jumlah'] = $this->session->userdata('jumlah');
        $data['stock'] = $this->session->userdata('stock');
        $data['cash'] = $this->session->userdata('cash');
        $data['voucher'] = $this->session->userdata('voucher');
        $data['payroll'] = $this->session->userdata('payroll');
        $data['jmlVoucher'] = $this->session->userdata('jmlVoucher');
        
		$this->load->view('print/exportReportHarian', $data);

        // var_dump($this->session->userdata('dataNow'));
		
    }
}