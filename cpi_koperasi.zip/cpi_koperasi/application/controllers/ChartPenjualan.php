<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ChartPenjualan extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		
		$this->load->helper('form'); 
        $this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->model('M_chart_penjualan', 'chart_penjualan');
	}

	public function index()
	{
		if($this->session->has_userdata('id_user')){

			$data['periode'] = $this->chart_penjualan->pilihanPeriode()->result();
			$data['target'] = $this->chart_penjualan->jumlahtarget()->result();
			$data['realisasi'] = $this->chart_penjualan->jumlahrealisasi()->result();
			
			$this->load->view('templates/header');
			$this->load->view('chartPenjualan', $data);
			$this->load->view('templates/footer');
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda Harus Login Dahulu</div>');
            redirect('login'); 
		}
	}

	function getDataPerVendor(){
		$dataVendor = $this->chart_penjualan->getDataPerVendor()->result();
		echo json_encode($dataVendor);
	}

}
