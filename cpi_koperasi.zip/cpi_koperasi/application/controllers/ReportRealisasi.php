<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReportRealisasi extends CI_Controller {
    public function __construct() 
    {
        parent::__construct();
        $this->load->model('M_report_realisasi', 'report');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
	{
        $data['dataUser'] = $this->report->get_user()->result();
        $data['pic'] = $this->report->get_pic()->result();
        $data['vendor'] = $this->report->get_vendor()->result();
		$data['plant'] = $this->report->get_plant()->result();
        $data['department'] = $this->report->get_department()->result_array();
        $data['has_data'] = "No";

        $data['printDataOS'] = $this->report->dataRealisasiOS()->result();

        $realisasiOS = $this->report->realisasiOS()->result();
        $targetOS = $this->report->targetOS()->result();

        foreach($realisasiOS as $ro){
            if($ro->jumlah == null){
                $realisasiOSPass = 0;
            }else{
                $realisasiOSPass = $ro->jumlah;
            }
        }

        foreach($targetOS as $to){
            if($to->target == null){
                $targetOSPass = 0;
            }else{
                $targetOSPass = $to->target;
            }
        }
        
        if($realisasiOSPass == 0){
            $percentageOS = 0;
        }elseif($targetOSPass == 0){
            if($realisasiOSPass > 0){
                $percentageOS = 100;
            }else{
                $percentageOS = 0;
            }
            $percentageOS = 100;
        }else{
            $percentageOS = round(($realisasiOSPass / $targetOSPass) * 100);
        }
    
        $data['realisasiOS'] = $realisasiOSPass;
        $data['targetOS'] = $targetOSPass;
        $data['percentageOS'] = $percentageOS;

		$this->load->view('templates/header', $data);
		$this->load->view('report_realisasi', $data);
		$this->load->view('templates/footer');
	
	}

    function showdata(){
        $data['dataUser'] = $this->report->get_user()->result();
        $data['pic'] = $this->report->get_pic()->result();
        $data['plant'] = $this->report->get_plant()->result();
        $data['department'] = $this->report->get_department()->result_array();

        $department = $this->input->post("department");

        $mode = "";

        if($department != null){
            if($department == "ALL"){
                $mode = "department";
                $data['departmentSelected'] = "ALL";
                $dataPrint['departmentSelected'] = "ALL";

                $result = $this->report->dataDeptCPI()->result();
                $realisasi = $this->report->dataDeptCPI_realisasi()->result();
                $target = $this->report->dataDeptCPI_target()->result();

            }else{
                $mode = "department";
                $data['departmentSelected'] = $department;
                $dataPrint['departmentSelected'] = $department;
    
                $result = $this->report->dataDept($department)->result();
                $realisasi = $this->report->dataDept_realisasi($department)->result();
                $target = $this->report->dataDept_target($department)->result();
            }
            

            foreach($realisasi as $r){
                if($r->jumlah == null){
                    $realisasiPass = 0;
                }else{
                    $realisasiPass = $r->jumlah;
                }
            }

            foreach($target as $t){
                if($t->target == null){
                    $targetPass = 0;
                }else{
                    $targetPass = $t->target;
                }
            }
            
            if($realisasiPass == 0){
                $percentage = 0;
            }elseif($targetPass == 0){
                $percentage = 100 * $realisasiPass;
            }else{
                $percentage = round(($realisasiPass / $targetPass) * 100);
            }

            $data['printData'] = $result;
            $dataPrint['dataPrint'] = $result;
            $data['realisasi'] = $realisasiPass;
            $data['target'] = $targetPass;
            $data['percentage'] = $percentage;
            $data['has_data'] = "Yes";
        }elseif($department == "ALL"){
            $mode = "department";
            $data['departmentSelected'] = "ALL CPI";
            $dataPrint['departmentSelected'] = "ALL CPI";

            $result = $this->report->dataDeptCPI()->result();
            $realisasi = $this->report->dataDeptCPI_realisasi()->result();
            $target = $this->report->dataDeptCPI_target()->result();

            foreach($realisasi as $r){
                if($r->jumlah == null){
                    $realisasiPass = 0;
                }else{
                    $realisasiPass = $r->jumlah;
                }
            }

            foreach($target as $t){
                if($t->target == null){
                    $targetPass = 0;
                }else{
                    $targetPass = $t->target;
                }
            }
            
            if($realisasiPass == 0){
                $percentage = 0;
            }elseif($targetPass == 0){
                $percentage = 100 * $realisasiPass;
            }else{
                $percentage = round(($realisasiPass / $targetPass) * 100);
            }

            $data['printData'] = $result;
            $dataPrint['dataPrint'] = $result;
            $data['realisasi'] = $realisasiPass;
            $data['target'] = $targetPass;
            $data['percentage'] = $percentage;
            $data['has_data'] = "Yes";
        }else{
            $mode = "error";
            $data['error'] = "Harap Memilih Department!";
            $data['has_data'] = "No";
        }

        $data['printDataOS'] = $this->report->dataRealisasiOS()->result();

        $realisasiOS = $this->report->realisasiOS()->result();
        $targetOS = $this->report->targetOS()->result();

        foreach($realisasiOS as $ro){
            if($ro->jumlah == null){
                $realisasiOSPass = 0;
            }else{
                $realisasiOSPass = $ro->jumlah;
            }
        }

        foreach($targetOS as $to){
            if($to->target == null){
                $targetOSPass = 0;
            }else{
                $targetOSPass = $to->target;
            }
        }
        
        if($realisasiOSPass == 0){
            $percentageOS = 0;
        }elseif($targetOSPass == 0){
            if($realisasiOSPass > 0){
                $percentageOS = 100;
            }else{
                $percentageOS = 0;
            }
            $percentageOS = 100;
        }else{
            $percentageOS = round(($realisasiOSPass / $targetPass) * 100);
        }
    
        $data['realisasiOS'] = $realisasiOSPass;
        $data['targetOS'] = $targetOSPass;
        $data['percentageOS'] = $percentageOS;

        $data['mode'] = $mode;
        $dataPrint['mode'] = $mode;

        $this->session->unset_userdata('dataPrint');
        $this->session->set_userdata($dataPrint);
        
        $this->load->view('templates/header', $data);
        $this->load->view('report_realisasi', $data);
        $this->load->view('templates/footer');
    }

    function getDepartmentPerVendor(){
        $id_vendor = $this->input->post('id_vendor');
        if($id_vendor == null){
            $department = $this->report->get_department()->result();
        }else{
            $department = $this->report->getDepartmentPerVendor($id_vendor)->result();
        }
        echo json_encode($department);
    }

    function print_data(){
		$data['dataPrint'] = $this->session->userdata('dataPrint');
		$data['mode'] = $this->session->userdata('mode');
		$data['vendorShow'] = $this->session->userdata('vendorShow');
		$data['departmentSelected'] = $this->session->userdata('departmentSelected');
        
		$this->load->view('print/excelReportRealisasi', $data);
    }

    function print_data_global(){
		$data['dataPrint'] = $this->report->dataRealisasiGlobal()->result();
        
		$this->load->view('print/excelReportRealisasiGlobal', $data);
    }
}