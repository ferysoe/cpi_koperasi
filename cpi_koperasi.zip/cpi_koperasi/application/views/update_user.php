<div class="modal fade" id="modaluser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">Edit Data User</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="post" action="<?php echo base_url('user/tambahuser'); ?>">      
                <div class="card-body">
                <div class="row">
                  <div class="form-group col-6">
                    <label for="username">Username</label><br>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Masukkan Username" >
                  </div>
                  <div class="form-group col-6">
                    <label for="password">Password</label>
                    <input type="text" class="form-control" name="password" id="password" placeholder="Masukkan Password">
                  </div>
                  <div class="form-group col-6">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" name="nama" id="nama" placeholder="Masukkan Nama">
                  </div>
                  <div class="form-group col-6">
                    <label for="nik">NIK</label>
                    <input type="text" class="form-control" name="nik" id="nik" placeholder="Masukkan NIK">
                  </div>
                  <div class="form-group col-6">
                    <label for="no_reg">No Reg</label>
                    <input type="text" class="form-control" name="no_reg" id="no_reg" placeholder="Masukkan No Reg">
                  </div>
                  <div class="form-group col-6">
                  <label for="exampleInputPassword1">Status Karyawan</label><br>
                  <select class="form-control" aria-label="Default select example" name="status_karyawan">
                    <option selected>--</option>
                    <option value="Permanent">Permanent</option>
                    <option value="Non Permanent">Non Permanent</option>
                  </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="vendor">Vendor</label>
                    <input type="text" class="form-control" name="vendor" id="vendor" placeholder="Masukkan Vendor">
                  </div>
                  <div class="form-group col-6">
                  <label for="exampleInputPassword1">Status Aktif</label><br>
                  <select class="form-control" aria-label="Default select example" name="aktif" id="aktif">
                    <option selected>--</option>
                    <option value="Aktif">Aktif</option>
                    <option value="Tidak Aktif">Tidak Aktif</option>
                  </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="departemen">Departemen</label>
                    <input type="text" class="form-control" name="departemen" id="departemen" placeholder="Masukkan Departemen">
                  </div>
                  <div class="form-group col-6">
                    <label for="id_plant">ID Plant</label>
                    <select class="form-control" name="id_plant" id="id_plant">
                        <option value=""></option>
                        <?php
                        foreach($plant as $dp){
                          ?>
                            <option value="<?= $dp->id_plant ?>"><?= $dp->keterangan ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="password">ID PIC</label>
                    <select class="form-control" name="id_pic" id="id_pic">
                        <option value=""></option>
                        <?php
                        foreach($pic as $dpic){
                          ?>
                            <option value="<?= $dpic->id_pic ?>"><?= $dpic->nama ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="target">Target</label>
                    <input type="text" class="form-control" name="target" id="target" placeholder="Permanen (4), OS (2)">
                  </div>
                  <div class="form-group col-6">
                    <label for="id_akses">ID Akses</label>
                    <select class="form-control" name="id_akses" id="id_akses">
                        <option value=""></option>
                        <?php
                        foreach($akses as $da){
                          ?>
                            <option value="<?= $da->id_akses ?>"><?= $da->keterangan ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>      
                  <div class="form-group col-6">
                    <label for="target">Vouvher</label>
                    <input type="text" class="form-control" name="voucher" id="voucher" placeholder="Permanen (4), OS (2)">
                  </div>        
              </div>
                </div>
                <!-- /.card-body -->
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>
                </div>
              </form>
      </div>  
    </div>
  </div>
</div>