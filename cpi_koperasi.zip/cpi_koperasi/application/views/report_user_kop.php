<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data User</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Report Data User</li>
              <input type="text" id="id_pic" value="<?= $id_pic; ?>" hidden>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">

    <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Report Data</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="post" action="<?php echo base_url(''); ?>">      
                <div class="card-body">
                <div class="row">
                <div class="form-group col-6">
                <label for="id_plant">PIC</label>
                <select class="form-control" name="id_plant_edit" id="pic_filter">
                    <option value=""></option>
                    <?php
                    foreach($tampil_pic as $v){
                    ?>
                        <option value="<?= $v->id_pic ?>"><?= $v->nama ?></option>
                    <?php
                    }
                ?>
                </select>
                </div>
                 
              </div>
                </div>
                <!-- /.card-body -->
              </form>
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" id="btn_search">Search</button>
                </div>
            </div>
            <!-- /.card -->
            <!-- Input addon -->
          </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">
            <!-- Form Element sizes -->          
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->

      <div class="container-fluid">
        
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Table User</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive">
                <div class="table-responsive">
                    <a target="_blank" class="btn btn-primary mb-3" href="<?= base_url('reportuser/print_data') ?>">EXPORT KE EXCEL</a>
                <!-- <a target="_blank" href="">EXPORT KE EXCEL</a> -->
                  <table class="table" id="table_data_user">
                    <thead>
                      <tr>
                        <th>NIK</th>
                        <th>Nama</th>
                        <th>Vendor</th>
                        <th>Department</th>
                        <!-- <th>Target</th> -->
                        <th>Memiliki Voucher</th>
                      </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>     
      </div><!-- /.container-fluid -->
    </section>

    
</div>
  <!-- /.content-wrapper -->
<script type="text/javascript" src="<?= base_url('assets/js/');?>report_user_kop.js?v=1.1.1.1.1.1.1.1"></script>