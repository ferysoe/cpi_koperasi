<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">

          <?php 
            if($id_akses == "4"){
          ?>

            <div class="col-lg-6 col-6">
              <?php if($id_plant == "1741"){ $plant = "Sepanjang"; }else{ $plant = "Krian"; } ?>
              <h1>Form Pembelian <?= $plant; ?></h1><BR>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Input data Pembelian</li>
              </ol><br>
            </div>
            <div class="col-lg-6 col-6">
              <div class="small-box bg-info pb-3">
                <div class="inner">
                  <h1 class="display-2 font-weight-bold" id="stock_now"></h1>
                  <p>Sisa Stock</p>
                </div>
                <div class="icon">
                  <i class="fas fa-drumstick-bite"></i>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-6">
              <div class="small-box bg-success pb-3">
                <div class="inner">
                  <h1 class="display-2 font-weight-bold" id="harga_now"></h1>
                  <p>Harga Ayam</p>
                </div>
                <div class="icon">
                  <i class="fas fa-money-bill"></i>
                </div>
              </div>
            </div> 

          <?php 
            }
          ?>

          <?php 
            if($id_akses == "3" || $id_akses == "1"){
          ?>

            <div class="col-sm-4">
              <h1>Delete Data Pembelian</h1>
            </div>

          <?php 
            }
          ?>

        </div>
        <input type="text" id="id_plant" value="<?= $id_plant; ?>" hidden>
        <input type="text" id="id_akses" value="<?= $id_akses; ?>" hidden>
        <input type="text" id="id_pic" disabled="disabled" value="<?= $id_pic; ?>" hidden>
      </div>
    </section>
    
    <!-- Form Pembelian -->
    <?php 
        if($id_akses == "4"){
    ?>
      <section class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <div class="card card-primary">
                  <div class="card-header">
                    <h3 class="card-title">Input Data Pembelian</h3>
                  </div>

                  <form>
                    <div class="card-body">
                      <div class="row">
                        <div class="form-group col-6">
                          <label for="exampleInputEmail1">Nama</label><br>
                          <select class="js-example-basic-single form-control" name="state" id="nama_user">
                            <option value="--">--</option>
                            <?php
                              foreach($dataUser as $du){
                                if($du['id_akses'] != "1"){
                                  if($du['nik'] == null){
                            ?>
                                    <option value="<?= $du['id_user'] ?>"><?= $du['nama'] . " - " . $du['vendor'] . " - " . $du['no_reg'] ?></option>
                            <?php
                                  }else{
                            ?>
                                    <option value="<?= $du['id_user'] ?>"><?= $du['nama'] . " - " . $du['vendor'] . " - " . $du['nik'] ?></option>
                            <?php
                                  }
                                }
                              }
                            ?>
                          </select>
                        </div>
                        <div class="form-group col-6">
                          <label for="exampleInputPassword1">Jumlah Pemesanan</label>
                          <input type="number" class="form-control" id="jumlah" placeholder="Masukkan Jumlah">
                          <input type="number" class="form-control" id="stock_product" placeholder="Masukkan Jumlah" value="<?= $stockProduct; ?>" hidden>
                          <input type="number" class="form-control" id="harga_product" placeholder="Masukkan Jumlah" value="<?= $hargaProduct; ?>" hidden>
                        </div>
                        <div class="form-group col-6">
                          <label for="exampleInputPassword1">Status Pembayaran</label><br>
                          <select class="form-control" aria-label="Default select example" id="status_pembayaran">
                            <option selected>--</option>
                            <option value="Cash">Cash</option>
                            <option value="Voucher">Voucher</option>
                            <option value="Payroll">Payroll</option>
                          </select>
                        </div>
                        <div class="form-group col-6">
                          <label for="exampleInputPassword1">Keterangan</label>
                          <input type="text" class="form-control" id="keterangan" placeholder="Masukkan Keterangan">
                        </div>    
                        <div class="form-group col-2">
                          <label for="exampleInputPassword1">Jumlah Voucher</label>
                          <input type="number" class="form-control" id="jumlah_voucher" placeholder="..." disabled="disabled">
                        </div>        
                        <div class="form-group col-4">
                          <label for="exampleInputPassword1">Kode Voucher</label>
                          <input type="text" class="form-control" id="kode_redeem_voucher" placeholder="Masukkan Kode Voucher" disabled="disabled">
                        </div>        
                        <div class="form-group col-4">
                          <label for="exampleInputPassword1">Total Pembayaran</label><br>
                          <h1 id="total_pembayaran_print">Rp 0,00</h1>
                          <input type="text" class="form-control" placeholder="Total Pembayaran" id="total" disabled="disabled" hidden>
                        </div>  
                        <div class="form-group col-2">
                          <label id="sisa_voucher_text">Sisa Voucher</label><br>
                          <h1 id="sisa_voucher_print">0</h1>
                          <input type="text" class="form-control" placeholder="Total Pembayaran" id="sisa_voucher" disabled="disabled" hidden>
                        </div>         
                      </div> 
                    </div>
                  </form>

                  <div class="card-footer">
                    <button type="submit" class="btn btn-primary" id="save_pembelian">Submit</button>
                  </div>
                  <div class="overlay" id="loading" hidden>
                    <i class="fas fa-2x fa-sync-alt fa-spin"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </section>

      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="card card-primary">

                <div class="card-header">
                  <h3 class="card-title">Table Pembelian</h3>
                </div>

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table" id="table_pembelian">
                      <thead>
                        <tr>
                          <th>ID Pembelian</th>
                          <th>Nama</th>
                          <th>Status Pembayaran</th>
                          <th>Tanggal Pembelian</th>
                          <th>Jumlah</th>
                          <th>Keterangan</th>
                          <th>Total Pembayaran</th>
                          <th>Kode Voucher</th>
                          <th>Jumlah Voucher Ter-claim</th>
                        </tr>
                      </thead>
                      <tbody>
                      </tbody>
                    </table>
                  </div>
                </div>
                
                <div class="overlay" id="loading2" hidden>
                  <i class="fas fa-2x fa-sync-alt fa-spin"></i>
                </div>
              </div>
            </div>
          </div>  
        </div>
      </section>

    <?php
      }
    ?>

    <?php 
        if($id_akses != "4"){
    ?>

      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="card card-primary">

                <div class="card-header">
                  <h3 class="card-title">Table Pembelian</h3>
                </div>

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table" id="table_pembelian_koperasi">
                      <thead>
                        <tr>
                          <th>ID Pembelian</th>
                          <th>Nama</th>
                          <th>Status Pembayaran</th>
                          <th>Tanggal Pembelian</th>
                          <th>Jumlah</th>
                          <th>Keterangan</th>
                          <th>Total Pembayaran</th>
                          <th>Kode Voucher</th>
                          <th>Jumlah Voucher Ter-claim</th>
                        </tr>
                      </thead>
                      <tbody>
                      </tbody>
                    </table>
                  </div>
                </div>

                <div class="overlay" id="loading3" hidden>
                  <i class="fas fa-2x fa-sync-alt fa-spin"></i>
                </div>

              </div>
            </div>
          </div>  
        </div>
      </section>
    
    <?php
      }
    ?>

</div>
                        
<div class="modal fade" id="modal_data_pembelian" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
      <h5 class="modal-title" id="title">Delete Data Pembelian</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form>
          <div class="card-body">
          <div class="row">
              <!-- <input type="hidden" class="form-control" id="id_pembelian" placeholder="Id Pembelian"> -->
              <div class="form-group col-12">
                <label for="id_pembelian">Apakah Anda Yakin Menghapus Data Pembelian Ini ?</label><br>
              </div>
              <div class="form-group col-12">
                <label for="id_pembelian">ID Pembelian</label><br>
                <label id="id_pembelian_edit"></label><br>
                <label for="exampleInputEmail1">Nama</label><br>
                <label id="nama_edit"></label><br>
              </div>
            </div>
          </div>
        </form>
          <!-- /.card-body -->
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <!-- <button type="submit" class="btn btn-success" id="save_edit_pembelian">Save</button> -->
            <button type="submit" class="btn btn-danger" id="delete_pembelian">Delete</button>
          </div>
      </div>
    </div>
  </div>
</div>

  <script type="text/javascript" src="<?= base_url('assets/js/');?>pembelian.js?v=2.1.1.1.1.1.1.1.1.1.1"></script>