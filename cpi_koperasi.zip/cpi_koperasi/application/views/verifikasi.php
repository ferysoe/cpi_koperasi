<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Report Data Penjualan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Report Data Penjualan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">

    <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Report Data</h3>
                <p><?php // if(isset($mode)){echo $mode;} ?></p>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="post" action="<?php echo base_url('report/cekdata'); ?>">      
                <div class="card-body">
                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                <div class="row">
                  <!-- <div class="form-group col-6">
                    <label>Date range:</label>
                    <div class="input-group">
                    <div class="input-group-prepend">
                    <span class="input-group-text">
                    <i class="far fa-calendar-alt"></i>
                    </span>
                    </div>
                    <input type="text" class="form-control float-right" id="reservation">
                    </div>

                  </div> -->
                  <div class="form-group col-6">
                    <label for="start_date">Tanggal Start</label><br>
                    <input id="tanggal_start" name="start" />
                    <!-- <input type="date" id="tanggal_start"/> -->
                  </div>
                  <div class="form-group col-6">
                    <label for="end_date">Tanggal End</label><br>
                    <input id="tanggal_end" name="end" />
                    <!-- <input type="date" id="tanggal_end"/> -->
                  </div>
                  <div class="form-group col-6">
                    <label for="departemen">Department</label>
                    <select class="form-control" name="department" id="department_filter">
                        <option value=""></option>
                        <?php
                        foreach($department as $dp){
                          ?>
                            <option value="<?= $dp['nama_department'] ?>"><?= $dp['nama_department'] ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="id_plant">Vendor</label>
                    <select class="form-control" name="vendor" id="vendor_filter">
                        <option value=""></option>
                        <?php
                        foreach($vendor as $dp){
                          ?>
                            <option value="<?= $dp->id ?>"><?= $dp->keterangan ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <!-- <div class="form-group col-6">
                    <label for="exampleInputEmail1">Nama</label><br>
                    <select class="js-example-basic-single form-control" name="state" id="nama_filter">
                      <option value="--">--</option>
                      <?php
                        foreach($dataUser as $du){
                          ?>
                            <option value="<?= $du->id_user ?>"><?= $du->nama ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                  <label for="exampleInputPassword1">PIC</label><br>
                  <select class="js-example-basic-single form-control" name="state" id="pic_filter">
                      <option value="--">--</option>
                      <?php
                        foreach($pic as $du){
                          ?>
                            <option value="<?= $du->id_pic ?>"><?= $du->nama ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="id_plant">Plant User</label>
                    <select class="form-control" name="id_plant_edit" id="plant_filter">
                        <option value=""></option>
                        <?php
                        foreach($plant as $dp){
                          ?>
                            <option value="<?= $dp->keterangan ?>"><?= $dp->keterangan ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="id_plant">Plant Toko</label>
                    <select class="form-control" name="id_plant_edit" id="plant_filter">
                        <option value=""></option>
                        <option value="1741">Plant Sepanjang</option>
                        <option value="1742">Plant Krian</option>
                    </select>
                  </div> -->
              </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" id="btn_search">Search</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            <!-- Input addon -->
          </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">
            <!-- Form Element sizes -->          
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->

      <div class="container-fluid">
        
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Result</h3>
              </div>
              <div class="card-body">
                <?php
                  if($has_data == "Yes"){
                ?>
                <div class="row">
                  <div class="col-lg-12 col-6">
                    <?php
                      if($mode == "tanggal" || $mode == "department/tanggal" || $mode == "vendor/tanggal" || $mode == "department/vendor/tanggal"){
                    ?>
                        <h4>Periode Tanggal : <?= $rangeTanggal; ?></h4><br>  
                    <?php
                      }
                    ?>
                  </div>
                  <div class="col-lg-12 col-6">
                    <?php
                      if($mode == "vendor" || $mode == "vendor/tanggal" || $mode == "department/vendor/tanggal"){
                    ?>
                        <h4>Vendor : <?= $vendorShow; ?></h4><br>  
                    <?php
                      }
                    ?>
                  </div>
                  <div class="col-lg-12 col-6">
                    <?php
                      if($mode == "department" || $mode == "department/tanggal" || $mode == "department/vendor/tanggal"){
                    ?>
                        <h4>Department : <?= $departmentSelected; ?></h4><br>  
                    <?php
                      }
                    ?>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($jumlahAyam == null){echo 0;}else{echo $jumlahAyam;} ?></h1>
                        <p>Total Penjualan Ayam</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($jumlahVoucher == null){echo 0;}else{echo $jumlahVoucher;} ?></h1>
                        <p>Total Voucher Terclaim</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($jumlahCash == null){echo 0;}else{echo $jumlahCash;} ?></h1>
                        <p>Produk Terjual Dengan Cash</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($jumlahPayroll == null){echo 0;}else{echo $jumlahPayroll;} ?></h1>
                        <p>Produk Terjual Dengan Payroll</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12 col-6">
                    <div class="col-lg-12 col-6">
                      <div class="small-box bg-success">
                        <div class="inner">
                          <h2 class="display-2 font-weight-bold"><?php if($jumlahUang == null){echo "Rp " . number_format(0,2,',','.');}else{echo "Rp " . number_format($jumlahUang,2,',','.');} ?></h2>
                          <p>Total Uang yang Didapat</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <?php    
                  }
                ?>
                <div class="table-responsive">
                  <a target="_blank" class="btn btn-primary mb-3" href="<?= base_url('report/print_data') ?>">EXPORT KE EXCEL</a>
                  <table class="table" id="table_report">
                    <thead>
                      <tr>
                        <th>ID Pembelian</th>
                        <th>Nama</th>
                        <th>Tanggal Pembelian</th>
                        <th>Jumlah</th>
                        <th>Total</th>
                        <th>Jenis Pembayaran</th>
                        <th>Keterangan</th>
                        <th>Kode Voucher</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                          if($has_data == "Yes"){
                            foreach($printData as $pd):
                          ?>
                          <tr>
                            <td><?= $pd->id_pembelian; ?></td>
                            <td><?= $pd->nama; ?></td>
                            <td><?= $pd->tanggal; ?></td>
                            <td><?= $pd->jumlah; ?></td>
                            <td><?= "Rp " . number_format($pd->total,2,',','.'); ?></td>
                            <td><?= $pd->jenis_pembayaran; ?></td>
                            <td><?= $pd->keterangan; ?></td>
                            <td><?= $pd->kode_voucher; ?></td>
                          </tr>
                          <?php
                            endforeach;
                          }
                          ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>     
      </div><!-- /.container-fluid -->
    </section>

    
</div>
  <!-- /.content-wrapper -->
<script type="text/javascript" src="<?= base_url('assets/js/');?>reportPenjualan.js?v=1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1"></script>
<script>
    
</script>