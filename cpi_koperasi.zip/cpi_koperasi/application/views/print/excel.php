<!DOCTYPE html>
<html>
<head>
	<title>Data Ayam</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data Pegawai.xls");
	?>
 
	<center>
		<h1>Export Data Ayam <br/> CPI</h1>
	</center>
 
	<table border="1">
		<tr>
			<th>No</th>
			<th>Id Pembelian</th>
			<th>Nama</th>
			<th>Tanggal Pembelian</th>
			<th>Jumlah</th>
			<th>Total Harga</th>
			<th>Jenis Pembayaran</th>
			<th>Keterangan</th>
		</tr>
        <?php 
			$no = 1;
            foreach ($dataUser as $row) { 
		?>
		<tr>
			<td><?= $no;  ?></td>
			<td><?= $row->id_pembelian ?></td>
            <td><?= $row->nama_user ?></td>
			<td><?= $row->tgl_pembelian ?></td>
			<td><?= $row->jumlah ?></td>
			<td><?= $row->total_pembayaran ?></td>
			<td><?= $row->status_pembayaran ?></td>
			<td><?= $row->keterangan ?></td>
		</tr>
        <?php 
				$no++;
            } 
		?>
	</table>
</body>
</html>