<!DOCTYPE html>
<html>
<head>
	<title>Data Ayam</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data User.xls");
	$nama = $this->session->userdata('nama');
	$namaPIC = $this->session->userdata('namaPIC');
	?>
 
	<center>
		<h1>Export Data User</h1><br>
	</center>
	<h2>PIC : <?= $this->session->userdata('namaPrint'); ?></h2>
	<table border="1">
		<tr>
			<th>No</th>
			<th>Nama</th>
			<th>NIK / NOREG</th>
			<th>Vendor</th>
			<th>Realisasi</th>
			<th>Target</th>
			<th>Percentage</th>
		</tr>
        <?php 
			$no = 1;
            foreach ($dataPrint as $row) { 
		?>
		<tr>
			<td><?= $no;  ?></td>
			<td><?= $row->nama; ?></td>
			<td><?= $row->no_reg; ?></td>
			<td><?= $row->vendor; ?></td>
			<td><?= $row->realisasi; ?></td>
			<td><?= $row->target; ?></td>
			<?php
				$realisasi = $row->realisasi;
				$target = $row->target;

				if($target <= 0){
					if($realisasi > 0){
					  $percentage = 100;
					}else{
					  $percentage = 0;
					}
				  }

				  if($realisasi <= 0){
					$percentage = 0;
				  }else{
					if($target <= 0){
					  $percentage = 100;
					}else{
					  $percentage = round(($realisasi / $target) * 100);
					}
				  }
			?>
			<td><?= $percentage . "%"; ?></td>
		</tr>
        <?php 
				$no++;
            } 
		?>
	</table>
</body>
</html>