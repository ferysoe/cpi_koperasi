<!DOCTYPE html>
<html>
<head>
	<title>Data Harian Penjualan Ayam</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data User.xls");

	date_default_timezone_set('Asia/Jakarta');
	$dateNow = date('d/m/Y');
	?>
 
	<center>
		<h1>Export Data User</h1><br>
	</center>
	<h2>Tanggal : <?= $dateNow; ?></h2>
	<h4>Total Cash yang Didapat : <?= "Rp " . number_format($total_pembayaran,2,',','.'); ?></h4>
	<h4>Jumlah Ayam Terjual : <?= $jumlah; ?></h4>
	<h4>Sisa Stock Ayam : <?= $stock; ?></h4>
	<h4>Jumlah Voucher Terclaim : <?= $jmlVoucher; ?></h4>
	<h4>Total Pembelian Menggunakan Cash : <?= $cash; ?></h4>
	<h4>Total Pembelian Menggunakan Voucher : <?= $voucher; ?></h4>
	<h4>Total Pembelian Menggunakan Payroll : <?= $payroll; ?></h4>
	<table border="1">
		<tr>
			<th>No</th>
			<th>ID Pembelian</th>
			<th>Nama</th>
			<th>NIK / NOREG</th>
			<th>Jumlah Pembelian</th>
			<th>Total Pembayaran</th>
			<th>Jenis Pembayaran</th>
			<th>Keterangan</th>
		</tr>
        <?php 
			$no = 1;
            foreach ($dataPrint as $row) { 
		?>
		<tr>
			<td><?= $no;  ?></td>
			<td><?= $row->id_pembelian; ?></td>
			<td><?= $row->nama; ?></td>
			<td><?= $row->no_reg; ?></td>
			<td><?= $row->jumlah; ?></td>
			<td><?= $row->total; ?></td>
			<td><?= $row->status; ?></td>
			<td><?= $row->keterangan; ?></td>
		</tr>
        <?php 
				$no++;
            } 
		?>
	</table>
</body>
</html>