<!DOCTYPE html>
<html>
<head>
	<title>Data Ayam</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data User.xls");
	$nama = $this->session->userdata('nama');
	$namaPIC = $this->session->userdata('namaPIC');
	?>
 
	<center>
		<h1>REPORT REALISASI</h1><br>
	</center>
	<?php
		if($mode == "vendor" || $mode == "department/vendor"){
	?>
		<h2>Vendor : <?= $vendorShow; ?></h2><br>  
	<?php
		}
	?>
	<?php
		if($mode == "department" || $mode == "department/vendor"){
	?>
		<h2>Department : <?= $departmentSelected; ?></h2><br>  
	<?php
		}
	?>
	<table border="1">
		<tr>
			<th>No</th>
			<th>Nama</th>
			<th>NIK/NOREG</th>
			<th>Vendor</th>
			<th>Department</th>
			<th>Realisasi</th>
			<th>Target</th>
			<th>Percentage</th>
			<th>Plant</th>
		</tr>
        <?php 
			$no = 1;
            foreach ($dataPrint as $row) { 
		?>
		<tr>
			<td><?= $no;  ?></td>
			<td><?= $row->nama; ?></td>
			<td><?= $row->noreg; ?></td>
			<td><?= $row->vendor; ?></td>
			<td><?= $row->department; ?></td>
			<td><?php if($row->realisasi == null){echo 0;}else{echo $row->realisasi;} ?></td>
			<td><?php if($row->target == null){echo 0;}else{echo $row->target;} ?></td>
			<?php
				if($row->realisasi == 0){
					$percentage = 0;
				}elseif($row->target == 0){
					$percentage = 100 * $row->realisasi;
				}else{
					$percentage = round(($row->realisasi / $row->target) * 100);
				}
			?>
			<td><?= $percentage; ?>%</td>
			<td><?= $row->plant; ?></td>
		</tr>
        <?php 
				$no++;
            } 
		?>
	</table>
</body>
</html>