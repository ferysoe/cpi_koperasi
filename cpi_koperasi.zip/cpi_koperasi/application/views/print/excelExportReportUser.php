<!DOCTYPE html>
<html>
<head>
	<title>Data Ayam</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data User.xls");
	$nama = $this->session->userdata('nama');
	$namaPIC = $this->session->userdata('namaPIC');
	?>
 
	<center>
		<h1>Export Data User</h1><br>
	</center>
	<?php
		if($this->session->has_userdata('namaPIC')){
			?>
				<h2>PIC : <?= $namaPIC; ?></h2>
			<?php
		}else{
			?>
				<h2>PIC : <?= $nama; ?></h2>
			<?php
		}
	?>
	<table border="1">
		<tr>
			<th>No</th>
			<th>No Reg</th>
			<th>Nama</th>
			<th>Vendor</th>
			<th>Department</th>
			<!-- <th>Target</th> -->
			<th>Memiliki Voucher</th>
			<th>TTD</th>
		</tr>
        <?php 
			$no = 1;
            foreach ($dataPrint as $row) { 
		?>
		<tr>
			<td><?= $no;  ?></td>
			<td><?= $row->no_reg; ?></td>
            <td><?= $row->nama; ?></td>
			<td><?= $row->vendor; ?></td>
			<td><?= $row->department; ?></td>
			<!-- <td><?= $row->target; ?></td> -->
			<?php
				if($row->has_voucher == "y"){
					$wv = "Yes";
				}else{
					$wv = "No";
				}
			?>
			<td><?= $wv; ?></td>
			<td></td>
		</tr>
        <?php 
				$no++;
            } 
		?>
	</table>
</body>
</html>