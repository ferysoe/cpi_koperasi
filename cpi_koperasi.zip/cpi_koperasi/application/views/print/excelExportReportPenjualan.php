<!DOCTYPE html>
<html>
<head>
	<title>Data Ayam</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Data User.xls");
	$nama = $this->session->userdata('nama');
	$namaPIC = $this->session->userdata('namaPIC');
	?>
 
	<center>
		<h1>Export Penjualan</h1><br>
	</center>
	<?php
		if($mode == "tanggal" || $mode == "department/tanggal" || $mode == "vendor/tanggal" || $mode == "department/vendor/tanggal"){
	?>
		<h2>Periode Tanggal : <?= $rangeTanggal; ?></h2><br>  
	<?php
		}
	?>
	<?php
		if($mode == "vendor" || $mode == "vendor/tanggal" || $mode == "department/vendor/tanggal"){
	?>
		<h2>Vendor : <?= $vendorShow; ?></h2><br>  
	<?php
		}
	?>
	<?php
		if($mode == "department" || $mode == "department/tanggal" || $mode == "department/vendor/tanggal"){
	?>
		<h4>Department : <?= $departmentSelected; ?></h4><br>  
	<?php
		}
	?>
	<table border="1">
		<tr>
			<th>No</th>
			<th>ID Pembelian</th>
			<th>Nama</th>
			<th>Tanggal Pembelian</th>
			<th>Jumlah</th>
			<th>Total</th>
			<th>Jenis Pembayaran</th>
			<th>Keterangan</th>
			<th>Kode Voucher</th>
		</tr>
        <?php 
			$no = 1;
            foreach ($dataPrint as $row) { 
		?>
		<tr>
			<td><?= $no;  ?></td>
			<td><?= $row->id_pembelian; ?></td>
			<td><?= $row->nama; ?></td>
			<td><?= $row->tanggal; ?></td>
			<td><?= $row->jumlah; ?></td>
			<td><?= "Rp " . number_format($row->total,2,',','.'); ?></td>
			<td><?= $row->jenis_pembayaran; ?></td>
			<td><?= $row->keterangan; ?></td>
			<td><?= $row->kode_voucher; ?></td>
		</tr>
        <?php 
				$no++;
            } 
		?>
	</table>
</body>
</html>