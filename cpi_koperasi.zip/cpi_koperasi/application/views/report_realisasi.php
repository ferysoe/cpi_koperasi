<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Report Realisasi Karyawan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Report Data Penjualan</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title font-weight-bold pt-2">Report Data Permanent</h3>
              </div>
              <form method="post" action="<?php echo base_url('reportrealisasi/showdata'); ?>">      
                <div class="card-body">
                  <?php if (isset($error)) : ?>
                    <div class="alert alert-danger">
                      <?php echo $error; ?>
                    </div>
                  <?php endif; ?>
                  <div class="row">
                    <div class="form-group col-6">
                      <label for="departemen">Department</label>
                      <select class="form-control" name="department" id="department_filter">
                          <option value=""></option>
                          <option value="ALL">ALL CPI</option>
                          <?php
                          foreach($department as $dp){
                            ?>
                              <option value="<?= $dp['nama_department'] ?>"><?= $dp['nama_department'] ?></option>
                            <?php
                          }
                        ?>
                      </select>
                    </div>  
                  </div>
                </div>
                
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" id="btn_search">Search</button>
                  <a target="_blank" class="btn btn-success float-sm-right" href="<?= base_url('reportrealisasi/print_data_global') ?>">EXPORT KE EXCEL (DATA GLOBAL)</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
      
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title font-weight-bold pt-2">Result Permanent</h3>
              </div>
              <div class="card-body">
                <?php
                  if($has_data == "Yes"){
                ?>
                <div class="row">
                  <div class="col-lg-12 col-6">
                    <?php
                      if($mode == "department"){
                    ?>
                        <h4>Department : <?= $departmentSelected; ?></h4><br>  
                    <?php
                      }
                    ?>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-4 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($realisasi == null){echo 0;}else{echo $realisasi;} ?></h1>
                        <p>Total Realisasi</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($target == null){echo 0;}else{echo $target;} ?></h1>
                        <p>Total Target</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($percentage == null){echo 0;}else{echo $percentage;} ?>%</h1>
                        <p>Percentage</p>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <?php    
                  }
                ?>
                <div class="row p-2">
                  <div class="table-responsive">
                    <!-- <a target="_blank" class="btn btn-primary mb-3" href="<?= base_url('reportrealisasi/print_data') ?>">EXPORT KE EXCEL</a> -->
                    <table class="table" id="table_report">
                      <thead>
                        <tr>
                          <th>Nama</th>
                          <th>NIK/NOREG</th>
                          <th>Department</th>
                          <th>Realisasi</th>
                          <th>Target</th>
                          <th>Percentage</th>
                          <th>Plant</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          if($has_data == "Yes"){
                            foreach($printData as $pd):
                          ?>
                          <tr>
                            <td><?= $pd->nama; ?></td>
                            <td><?= $pd->noreg; ?></td>
                            <td><?= $pd->department; ?></td>
                            <td><?php if($pd->realisasi == null){echo 0;}else{echo $pd->realisasi;} ?></td>
                            <td><?php if($pd->target == null){echo 0;}else{echo $pd->target;} ?></td>
                            <?php
                              if($pd->realisasi == 0){
                                  $percentage = 0;
                              }elseif($pd->target == 0){
                                  $percentage = 100 * $pd->realisasi;
                              }else{
                                  $percentage = round(($pd->realisasi / $pd->target) * 100);
                              }
                            ?>
                            <td><?= $percentage; ?>%</td>
                            <td><?= $pd->plant; ?></td>
                          </tr>
                          <?php
                            endforeach;
                          }
                          ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>     
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title font-weight-bold pt-2">Result OS</h3>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-lg-4 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($realisasiOS == null){echo 0;}else{echo $realisasiOS;} ?></h1>
                        <p>Total Realisasi</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($targetOS == null){echo 0;}else{echo $targetOS;} ?></h1>
                        <p>Total Target</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-6">
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h1 class="display-2 font-weight-bold"><?php if($percentageOS == null){echo 0;}else{echo $percentageOS;} ?>%</h1>
                        <p>Percentage</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row p-2">
                  <div class="table-responsive">
                    <!-- <a target="_blank" class="btn btn-primary mb-3" href="<?= base_url('reportrealisasi/print_data') ?>">EXPORT KE EXCEL</a> -->
                    <table class="table" id="table_report_os">
                      <thead>
                        <tr>
                          <th>Vendor</th>
                          <th>Plant</th>
                          <th>Realisasi</th>
                          <th>Target</th>
                          <th>Percentage</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          foreach($printDataOS as $pdo):
                        ?>
                          <tr>
                            <td><?= $pdo->vendor; ?></td>
                            <td><?= $pdo->plant; ?></td>
                            <td><?php if($pdo->realisasi == null){echo 0;}else{echo $pdo->realisasi;} ?></td>
                            <td><?php if($pdo->target == null){echo 0;}else{echo $pdo->target;} ?></td>
                            <?php
                              if($pdo->realisasi == 0){
                                  $percentage = 0;
                              }elseif($pdo->target == 0){
                                  $percentage = 100 * $pdo->realisasi;
                              }else{
                                  $percentage = round(($pdo->realisasi / $pdo->target) * 100);
                              }
                            ?>
                            <td><?= $percentage; ?>%</td>
                          </tr>
                        <?php
                          endforeach;
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>     
      </div>
    </section>

    
</div>
  <!-- /.content-wrapper -->
<script type="text/javascript" src="<?= base_url('assets/js/');?>reportRealisasi.js?v=1.1.1.1.1.1"></script>
<script>
    
</script>