<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="<?= base_url('assets/dist/img/logo.png') ?>">
  <title>CPI</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url('assets/plugins/fontawesome-free/css/all.min.css') ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="<?= base_url('/assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css') ?>">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?= base_url('/assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css') ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?= base_url('/assets/dist/css/adminlte.min.css') ?>">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?= base_url('/assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')?>">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?= base_url('/assets/plugins/daterangepicker/daterangepicker.css')?>">
  <!-- summernote -->
  <link rel="stylesheet" href="<?= base_url('/assets/plugins/summernote/summernote-bs4.min.css')?>">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

  <script src="<?= base_url('assets/');?>js/jquery-3.6.3.js" crossorigin="anonymous"></script>
  <script src="<?= base_url('assets/');?>js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

  <script src="<?= base_url('assets/');?>js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
  <script src="<?= base_url('assets/');?>js/datatables.min.js" crossorigin="anonymous"></script>
  <script src="<?= base_url('assets/');?>js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
  <script src="<?= base_url('assets/');?>js/dataTables.buttons.min.js" crossorigin="anonymous"></script>
  <!-- <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://unpkg.com/gijgo@1.9.14/js/gijgo.min.js" type="text/javascript"></script>
  <script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js" type="text/javascript"></script>
  <link href="https://unpkg.com/gijgo@1.9.14/css/gijgo.min.css" rel="stylesheet" type="text/css" />
  <link href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />

  <style>
    .select2-selection__rendered {
        line-height: 31px !important;
    }
    .select2-container .select2-selection--single {
        height: 35px !important;
    }
    .select2-selection__arrow {
        height: 34px !important;
    }
  </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?= base_url('Dashboard') ?>" class="nav-link">Home</a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a role="button" id="logout" class="nav-link">Logout</a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <div class="modal fade" id="modalLogOut" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h3 class="modal-title" id="exampleModalLabel">Log Out</h3>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?= base_url('login/logout') ?>" method="post">
          <div class="modal-body">
            <p>Apakah Anda yakin untuk Log Out?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Log Out</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!-- /.sidebar -->

    <script>
      $('#logout').on('click', function(){
        $('#modalLogOut').modal('show');
      });
    </script>

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <?php
      $id_akses =  $this->session->userdata('id_akses');
    ?>
    <div class="sb-nav-fixed" style="display: flex; justify-content: center;">
      <a href="<?= base_url('Dashboard') ?>" class="brand-link">
        <img src="<?= base_url('assets/dist/img/logo.png') ?>" alt="AdminLTE Logo" class="brand-image center" style="opacity: .8">
        <span class="brand-text font-weight-light">CPI</span>
      </a>
    </div>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?= base_url('assets/dist/img/avatar-1.png') ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo $this->session->userdata('nama') ?></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
     
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <li class="nav-item">
          <?php
            if($id_akses == "1" || $id_akses == "2" || $id_akses == "3" || $id_akses == "4"){
          ?>
            <a href="<?= base_url('Dashboard') ?>" class="nav-link">
              <i class="nav-icon fas fa-home"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <?php
            }
          ?>
          <?php
            if($id_akses == "3" || $id_akses == "4" || $id_akses == "1"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('pembelian/index')?>" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Pembelian
              </p>
            </a>
          </li>
          <?php
            }
          ?>
          <?php
            if($id_akses == "1"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('user/index')?>" class="nav-link">
              <i class="nav-icon fas fa-user-alt"></i>
              <p>
                Data User    
              </p>
            </a>
          </li>
          <?php
            }
          ?>
          <?php
            if($id_akses == "1" || $id_akses == "3"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('user/produk')?>" class="nav-link">
              <i class="nav-icon fas fa-tree"></i>
              <p>
                Produk
              </p>
            </a>
          </li> 
          <?php
            }
          ?>
          <?php
            if($id_akses == "1" || $id_akses == "3"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('report')?>" class="nav-link">
              <i class="nav-icon fas fa-check-square"></i>
              <p>
                Report Penjualan
              </p>
            </a>
          </li> 
          <?php
            }
          ?>
          <?php
            if($id_akses == "10"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('reportuser')?>" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Report User
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
          <?php
            if($id_akses == "1" || $id_akses == "3" ){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('ReportUser/indexkop')?>" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Report User Kop
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
          <?php
            if($id_akses == "2"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('reportuserpembelian')?>" class="nav-link">
              <i class="nav-icon fas fa-address-book"></i>
              <p>
                Report Pembelian User
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
          <?php
            if($id_akses == "2"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('reportuserpic')?>" class="nav-link">
              <i class="nav-icon fas fa-address-book"></i>
              <p>
                User PIC
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
          <?php
            if($id_akses == "5"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('reportuser')?>" class="nav-link">
              <i class="nav-icon fas fa-address-book"></i>
              <p>
                Report Pembelian User
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
          <?php
            if($id_akses == "4"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('reportpenjualanharian')?>" class="nav-link">
              <i class="nav-icon fas fa-address-book"></i>
              <p>
                Report Penjualan Harian
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
          <?php
            if($id_akses == "1" || $id_akses == "3" || $id_akses == "4"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('reportrealisasi')?>" class="nav-link">
              <i class="nav-icon fas fa-address-book"></i>
              <p>
                Report Realisasi Karyawan
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
          <?php
            if($id_akses == "1" || $id_akses == "3"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('reportstock')?>" class="nav-link">
              <i class="nav-icon fas fa-address-book"></i>
              <p>
                Report Stock Produk
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
          <?php
            if($id_akses == "1"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('DataPerDay')?>" class="nav-link">
              <i class="nav-icon fas fa-address-book"></i>
              <p>
                Data Per Day
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
          <?php
            if($id_akses == "1"){
          ?>
          <li class="nav-item">
            <a href="<?= base_url('chartpenjualan')?>" class="nav-link">
              <i class="nav-icon fas fa-address-book"></i>
              <p>
                Report Penjualan(Chart)
              </p>
            </a>
          </li>
          <?php
            }
          ?> 
        </ul>
      </nav>

      <!-- <div class="row">
        <div class="col-4">
          <div class="list-group" id="list-tab" role="tablist">
            <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">Dashboard</a>
            <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">Pembelian</a>
            <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="messages">Data User</a>
            <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-settings" role="tab" aria-controls="settings">Verifikasi</a>
            <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-settings" role="tab" aria-controls="settings">Produk</a>
          </div>
        </div>
        <div class="col-8">
          <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">...</div>
            <div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">...</div>
            <div class="tab-pane fade" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list">...</div>
            <div class="tab-pane fade" id="list-settings" role="tabpanel" aria-labelledby="list-settings-list">...</div>
          </div>
        </div>
      </div> -->
      <!-- /.sidebar-menu -->
    </div>
  </aside>