<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Report Data Penjualan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Report Data Stock</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">

    <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Report Data</h3>
                <p><?php // if(isset($mode)){echo $mode;} ?></p>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="post" action="<?php echo base_url('reportstock/cekdata'); ?>">      
                <div class="card-body">
                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                <div class="row">
                  <!-- <div class="form-group col-6">
                    <label>Date range:</label>
                    <div class="input-group">
                    <div class="input-group-prepend">
                    <span class="input-group-text">
                    <i class="far fa-calendar-alt"></i>
                    </span>
                    </div>
                    <input type="text" class="form-control float-right" id="reservation">
                    </div>

                  </div> -->
                  <div class="form-group col-6">
                    <label for="start_date">Tanggal Start</label><br>
                    <input id="tanggal_start" name="start" />
                    <!-- <input type="date" id="tanggal_start"/> -->
                  </div>
                  <div class="form-group col-6">
                    <label for="end_date">Tanggal End</label><br>
                    <input id="tanggal_end" name="end" />
                    <!-- <input type="date" id="tanggal_end"/> -->
                  </div>
              </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" id="btn_search">Search</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            <!-- Input addon -->
          </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">
            <!-- Form Element sizes -->          
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->

      <div class="container-fluid">
        
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Stock Krian</h3>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table" id="table_report_krian">
                    <thead>
                      <tr>
                        <th>Tanggal</th>
                        <th>Restock</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                          if($has_data == "Yes"){
                            foreach($printDataKrian as $pdk):
                          ?>
                          <tr>
                            <td><?= $pdk->tanggal; ?></td>
                            <td><?= $pdk->stock; ?></td>
                          </tr>
                          <?php
                            endforeach;
                          }
                          ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>     
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Stock Sepanjang</h3>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table" id="table_report_sepanjang">
                    <thead>
                      <tr>
                        <th>Tanggal</th>
                        <th>Restock</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                          if($has_data == "Yes"){
                            foreach($printDataSepanjang as $pds):
                          ?>
                          <tr>
                            <td><?= $pds->tanggal; ?></td>
                            <td><?= $pds->stock; ?></td>
                          </tr>
                          <?php
                            endforeach;
                          }
                          ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>     
      </div><!-- /.container-fluid -->
    </section>

    
</div>
  <!-- /.content-wrapper -->
<script type="text/javascript" src="<?= base_url('assets/js/');?>reportStock.js?v=1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1"></script>
<script>
    
</script>