<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="<?= base_url('assets/dist/img/logo.png') ?>">
  <title>Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="assets/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="assets/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="assets/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="assets/plugins/summernote/summernote-bs4.min.css">
</head>
<body>
	<div class="wrapper">
		<div class="content-header">
			<div class="container-fluid">
				<div class="row">
					<div class="col-sm-10" style="display: flex; justify-content: left;">
						<h1 class="text-left font-weight-bold m-0">Dashboard Penjualan</h1>
					</div>
					<div class="col-sm-2" style="display: flex; justify-content: right;">
						<button class="btn btn-info btn-sm m-0" style="border: radius 20px;"><a href="<?= base_url('login'); ?>" style="color:white" class="nav-link">Login</a></button>
					</div>
				</div>
			</div>
		</div>
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-4">
						<div class="small-box bg-info">
							<div class="inner">
								<?php
									if($realisasi[0]->jumlah == null){
										$realisasiWrite = "0";
									}else{
										$realisasiWrite = $realisasi[0]->jumlah;
									}
								?>
								<h1 class="display-2 font-weight-bold"><?= $realisasiWrite ?></h1>
								<p>Total Realisasi</p>
							</div>
							<div class="icon">
								<i class="fas fa-balance-scale"></i>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="small-box bg-success">
							<div class="inner">
								<h1 class="display-2 font-weight-bold"><?= $target[0]->target ?></h1>
								<p>Total Target</p>
							</div>
							<div class="icon">
								<i class="fas fa-trophy"></i>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="small-box bg-warning">
							<div class="inner">
								<h1 class="display-2 font-weight-bold"><?= $percentage ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
								<p>Persentase</p>
							</div>
							<div class="icon">
								<i class="ion ion-stats-bars"></i>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<section class="col-sm-12">
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title font-weight-bold"><i class="fas fa-chart-pie mr-1"></i>Penjualan Plant Krian</h3>
								<div class="card-tools">
									<button type="button" class="btn btn-tool float-sm-right" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
								</div>
							</div>
							<div class="card-header mt-2">
								<div class="row m-2">
									<h1 class="font-weight-bold">Permanent</h1>
								</div>
								<div class="row">
									<div class="col-sm-4">
										<div class="small-box bg-info">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $realisasiCPIKrian; ?></h1>
												<p>Total Realisasi</p>
											</div>
											<div class="icon">
												<i class="fas fa-balance-scale"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-success">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $targetCPIKrian; ?></h1>
												<p>Total Target</p>
											</div>
											<div class="icon">
												<i class="fas fa-trophy"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-warning">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $persentaseCPIKrian; ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
												<p>Persentase</p>
											</div>
											<div class="icon">
												<i class="ion ion-stats-bars"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table table-striped">
										<thead>
											<tr>
												<th scope="col">Department</th>
												<th scope="col">Total Realisasi</th>
												<th scope="col">Total Target</th>
												<th scope="col">Persentase</th>
											</tr>
										</thead>
										<tbody>
											<?php
												foreach($dataCPIKrian as $dk):
													?>
													<tr>
														<th scope="row"><?= $dk->Departemen; ?></th>
													<?php
													if($dk->Realisasi == null){
														$realisasiKrian_data = 0;
													}else{
														$realisasiKrian_data = $dk->Realisasi;
													}
													?>
														<td><?= $realisasiKrian_data; ?></td>
													<?php
													?>
														<td><?= $dk->Target; ?></td>
													<?php
														if($realisasiKrian_data == 0){
															$percentageKrian = 0;
														}elseif($dk->Target == 0){
															if($realisasiKrian_data > 1){
																$percentageKrian = 100;
															}else{
																$percentageKrian = 0;
															}
														}else{
															$percentageKrian = round(($realisasiKrian_data / $dk->Target) * 100);
														}
													?>
														<td><?= $percentageKrian . "%"; ?></td>
														</tr>
													<?php
												endforeach;
												?>
										</tbody>
									</table>
								</div>
							</div>
							<div class="card-header mt-2">
								<div class="row m-2">
									<h1 class="font-weight-bold">OS</h1>
								</div>
								<div class="row">
									<div class="col-sm-4">
										<div class="small-box bg-info">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $realisasiOSKrian; ?></h1>
												<p>Total Realisasi</p>
											</div>
											<div class="icon">
												<i class="fas fa-balance-scale"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-success">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $targetOSKrian; ?></h1>
												<p>Total Target</p>
											</div>
											<div class="icon">
												<i class="fas fa-trophy"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-warning">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $persentaseOSKrian; ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
												<p>Persentase</p>
											</div>
											<div class="icon">
												<i class="ion ion-stats-bars"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table table-striped">
										<thead>
											<tr>
												<th scope="col">Vendor</th>
												<th scope="col">Total Realisasi</th>
												<th scope="col">Total Target</th>
												<th scope="col">Persentase</th>
											</tr>
										</thead>
										<tbody>
											<?php
												foreach($dataOSKrian as $dk):
													?>
													<tr>
														<th scope="row"><?= $dk->Vendor; ?></th>
													<?php
													if($dk->Realisasi == null){
														$realisasiKrian_data = 0;
													}else{
														$realisasiKrian_data = $dk->Realisasi;
													}
													?>
														<td><?= $realisasiKrian_data; ?></td>
													<?php
													?>
														<td><?= $dk->Target; ?></td>
													<?php
														if($realisasiKrian_data == 0){
															$percentageKrian = 0;
														}elseif($dk->Target == 0){
															if($realisasiKrian_data > 1){
																$percentageKrian = 100;
															}else{
																$percentageKrian = 0;
															}
														}else{
															$percentageKrian = round(($realisasiKrian_data / $dk->Target) * 100);
														}
													?>
														<td><?= $percentageKrian . "%"; ?></td>
														</tr>
													<?php
												endforeach;
												?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</section>
					<section class="col-lg-12">
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title font-weight-bold"><i class="fas fa-chart-pie mr-1"></i>Penjualan Plant Sepanjang</h3>
								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
								</div>
							</div>
							<div class="card-header mt-2">
								<div class="row m-2">
									<h1 class="font-weight-bold">Permanent</h1>
								</div>
								<div class="row">
									<div class="col-sm-4">
										<div class="small-box bg-info">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $realisasiCPISepanjang; ?></h1>
												<p>Total Realisasi</p>
											</div>
											<div class="icon">
												<i class="fas fa-balance-scale"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-success">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $targetCPISepanjang; ?></h1>
												<p>Total Target</p>
											</div>
											<div class="icon">
												<i class="fas fa-trophy"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-warning">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $persentaseCPISepanjang; ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
												<p>Persentase</p>
											</div>
											<div class="icon">
												<i class="ion ion-stats-bars"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table table-striped">
										<thead>
											<tr>
											<th scope="col">Department</th>
											<th scope="col">Total Realisasi</th>
											<th scope="col">Total Target</th>
											<th scope="col">Presentase</th>
											</tr>
										</thead>
										<tbody>
											<?php
												foreach($dataCPISepanjang as $ds):
													?>
													<tr>
														<th scope="row"><?= $ds->Departemen; ?></th>
													<?php
													if($ds->Realisasi == null){
														$realisasiKrian = 0;
													}else{
														$realisasiKrian = $ds->Realisasi;
													}
													?>
														<td><?= $realisasiKrian; ?></td>
													<?php
													?>
														<td><?= $ds->Target; ?></td>
													<?php
														if($realisasiKrian == 0){
															$percentageKrian = 0;
														}elseif($ds->Target == 0){
															if($realisasiKrian > 1){
																$percentageKrian = 100;
															}else{
																$percentageKrian = 0;
															}
														}else{
															$percentageKrian = round(($realisasiKrian / $ds->Target) * 100);
														}
													?>
														<td><?= $percentageKrian . "%"; ?></td>
														</tr>
													<?php
												endforeach;
											?>
										</tbody>
									</table>
								</div>
							</div>
							<div class="card-header mt-2">
								<div class="row m-2">
									<h1 class="font-weight-bold">OS</h1>
								</div>
								<div class="row">
									<div class="col-sm-4">
										<div class="small-box bg-info">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $realisasiOSSepanjang; ?></h1>
												<p>Total Realisasi</p>
											</div>
											<div class="icon">
												<i class="fas fa-balance-scale"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-success">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $targetOSSepanjang; ?></h1>
												<p>Total Target</p>
											</div>
											<div class="icon">
												<i class="fas fa-trophy"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-warning">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $persentaseOSSepanjang; ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
												<p>Persentase</p>
											</div>
											<div class="icon">
												<i class="ion ion-stats-bars"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table table-striped">
										<thead>
											<tr>
												<th scope="col">Vendor</th>
												<th scope="col">Total Realisasi</th>
												<th scope="col">Total Target</th>
												<th scope="col">Persentase</th>
											</tr>
										</thead>
										<tbody>
											<?php
												foreach($dataOSSepanjang as $dk):
													?>
													<tr>
														<th scope="row"><?= $dk->Vendor; ?></th>
													<?php
													if($dk->Realisasi == null){
														$realisasiKrian_data = 0;
													}else{
														$realisasiKrian_data = $dk->Realisasi;
													}
													?>
														<td><?= $realisasiKrian_data; ?></td>
													<?php
													?>
														<td><?= $dk->Target; ?></td>
													<?php
														if($realisasiKrian_data == 0){
															$percentageKrian = 0;
														}elseif($dk->Target == 0){
															if($realisasiKrian_data > 1){
																$percentageKrian = 100;
															}else{
																$percentageKrian = 0;
															}
														}else{
															$percentageKrian = round(($realisasiKrian_data / $dk->Target) * 100);
														}
													?>
														<td><?= $percentageKrian . "%"; ?></td>
														</tr>
													<?php
												endforeach;
												?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</section>
					<section class="col-lg-12">
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title font-weight-bold"><i class="fas fa-chart-pie mr-1"></i>Penjualan Plant Premix</h3>
								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
								</div>
							</div>
							<div class="card-header mt-2">
								<div class="row m-2">
									<h1 class="font-weight-bold">Permanent</h1>
								</div>
								<div class="row">
									<div class="col-sm-4">
										<div class="small-box bg-info">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $realisasiCPIPremix; ?></h1>
												<p>Total Realisasi</p>
											</div>
											<div class="icon">
												<i class="fas fa-balance-scale"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-success">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $targetCPIPremix; ?></h1>
												<p>Total Target</p>
											</div>
											<div class="icon">
												<i class="fas fa-trophy"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-warning">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $persentaseCPIPremix; ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
												<p>Persentase</p>
											</div>
											<div class="icon">
												<i class="ion ion-stats-bars"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table table-striped">
										<thead>
											<tr>
											<th scope="col">Department</th>
											<th scope="col">Total Realisasi</th>
											<th scope="col">Total Target</th>
											<th scope="col">Presentase</th>
											</tr>
										</thead>
										<tbody>
											<?php
												foreach($dataCPISPremix as $dp):
													?>
													<tr>
														<th scope="row"><?= $dp->Departemen; ?></th>
													<?php
													if($dp->Realisasi == null){
														$realisasiKrian = 0;
													}else{
														$realisasiKrian = $dp->Realisasi;
													}
													?>
														<td><?= $realisasiKrian; ?></td>
													<?php
													?>
														<td><?= $dp->Target; ?></td>
													<?php
														if($realisasiKrian == 0){
															$percentageKrian = 0;
														}elseif($dp->Target == 0){
															if($realisasiKrian > 1){
																$percentageKrian = 100;
															}else{
																$percentageKrian = 0;
															}
														}else{
															// $percentageKrian = round(($realisasiKrian_data / $dk->Target) * 100);
															$percentageKrian = round(($realisasiKrian / $dp->Target) * 100);
														}
													?>
														<td><?= $percentageKrian . "%"; ?></td>
														</tr>
													<?php
												endforeach;
											?>
										</tbody>
									</table>
								</div>
							</div>
							<div class="card-header mt-2">
								<div class="row m-2">
									<h1 class="font-weight-bold">OS</h1>
								</div>
								<div class="row">
									<div class="col-sm-4">
										<div class="small-box bg-info">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $realisasiOSPremix; ?></h1>
												<p>Total Realisasi</p>
											</div>
											<div class="icon">
												<i class="fas fa-balance-scale"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-success">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $targetOSPremix; ?></h1>
												<p>Total Target</p>
											</div>
											<div class="icon">
												<i class="fas fa-trophy"></i>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="small-box bg-warning">
											<div class="inner">
												<h1 class="display-2 font-weight-bold"><?= $persentaseOSPremix; ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
												<p>Persentase</p>
											</div>
											<div class="icon">
												<i class="ion ion-stats-bars"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table table-striped">
										<thead>
											<tr>
												<th scope="col">Vendor</th>
												<th scope="col">Total Realisasi</th>
												<th scope="col">Total Target</th>
												<th scope="col">Persentase</th>
											</tr>
										</thead>
										<tbody>
											<?php
												foreach($dataOSPremix as $dk):
													?>
													<tr>
														<th scope="row"><?= $dk->Vendor; ?></th>
													<?php
													if($dk->Realisasi == null){
														$realisasiKrian_data = 0;
													}else{
														$realisasiKrian_data = $dk->Realisasi;
													}
													?>
														<td><?= $realisasiKrian_data; ?></td>
													<?php
													?>
														<td><?= $dk->Target; ?></td>
													<?php
														if($realisasiKrian_data == 0){
															$percentageKrian = 0;
														}elseif($dk->Target == 0){
															if($realisasiKrian_data > 1){
																$percentageKrian = 100;
															}else{
																$percentageKrian = 0;
															}
														}else{
															$percentageKrian = round(($realisasiKrian_data / $dk->Target) * 100);
														}
													?>
														<td><?= $percentageKrian . "%"; ?></td>
														</tr>
													<?php
												endforeach;
												?>
										</tbody>
									</table>
								</div>
							</div>
						</div>

					</section>
					<section class="col-lg-12">
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title font-weight-bold"><i class="fas fa-chart-pie mr-1"></i>Penjualan External</h3>
								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
								</div>
							</div>
						<div class="card-body p-0">
							<div class="table-responsive">
								<table class="table table-striped">
									<thead>
										<tr>
										<th scope="col">Customer</th>
										<th scope="col">Total Realisasi</th>
										<th scope="col">Total Target</th>
										<th scope="col">Presentase</th>
										</tr>
									</thead>
									<tbody>
										<?php
											foreach($dataExternal as $dk){
											?>
												<tr>
													<th scope="row"><?= $dk->Nama; ?></th>
											<?php
												if($dk->Realisasi == null){
													$realisasiExt = 0;
												}else{
													$realisasiExt = $dk->Realisasi;
												}
												?>
													<td><?= $realisasiExt; ?></td>
												<?php
												?>
													<td><?= $dk->Target; ?></td>
												<?php
													if($realisasiExt == 0){
														$percentageExt = 0;
													}elseif($dk->Target == 0){
														if($realisasiExt > 1){
															$percentageExt = 100;
														}else{
															$percentageExt = 0;
														}
													}
												?>
													<td><?= $percentageExt . "%"; ?></td>
													</tr>
												<?php
											}
										?>
									</tbody>
								</table>
							</div>
						</div>
					</section>
					<section class="col-lg-12">
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title font-weight-bold"><i class="fas fa-chart-pie mr-1"></i>Rekap Penjualan</h3>
								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
								</div>
							</div>
						<div class="card-body p-0">
							<div class="table-responsive">
								<table class="table table-striped">
									<thead>
										<tr>
										<th scope="col">Bulan</th>
										<th scope="col">Total Realisasi</th>
										<th scope="col">Total Target</th>
										<th scope="col">Presentase</th>
										</tr>
									</thead>
									<tbody>
										<?php
											foreach($rekap as $r){
											?>
												<tr>
													<th scope="row"><?= $r->bulan; ?></th>
											<?php
												if($r->realisasi == null){
													$realisasiRekap = 0;
												}else{
													$realisasiRekap = $r->realisasi;
												}
												?>
													<td><?= $realisasiRekap; ?></td>
												<?php
												?>
													<td><?= $r->target; ?></td>
												<?php
													$percentageRekap = 0;
													if($realisasiRekap == 0){
														$percentageRekap = 0;
													}elseif($r->target == 0){
														if($realisasiRekap > 1){
															$percentageRekap = 100;
														}else{
															$percentageRekap = 0;
														}
													}else{
														$percentageRekap = ($realisasiRekap / $r->target) * 100;
													}
												?>
													<td><?= number_format((float)$percentageRekap, 1, '.', '') . "%"; ?></td>
													</tr>
												<?php
											}
										?>
									</tbody>
								</table>
							</div>
						</div>
					</section>
				</div>
			</div>
		</div>
	</div>
	
	
	<!-- ./wrapper -->
	<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
	<!-- jQuery -->
	<script src="<?= base_url('/assets/plugins/jquery/jquery.min.js')?>"></script>
	<!-- jQuery UI 1.11.4 -->
	<script src="<?= base_url('/assets/plugins/jquery-ui/jquery-ui.min.js')?>"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

	<script>
		$.widget.bridge('uibutton', $.ui.button)
	</script>
	<!-- jQuery -->
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<!-- jQuery UI 1.11.4 -->
	<script src="assets/plugins/jquery-ui/jquery-ui.min.js"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<!-- Bootstrap 4 -->
	<script src="assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- ChartJS -->
	<script src="assets/plugins/chart.js/Chart.min.js"></script>
	<!-- Sparkline -->
	<script src="assets/plugins/sparklines/sparkline.js"></script>
	
	<!-- jQuery Knob Chart -->
	<script src="assets/plugins/jquery-knob/jquery.knob.min.js"></script>
	<!-- daterangepicker -->
	<script src="assets/plugins/moment/moment.min.js"></script>
	<script src="assets/plugins/daterangepicker/daterangepicker.js"></script>
	<!-- Tempusdominus Bootstrap 4 -->
	<script src="assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
	<!-- Summernote -->
	<script src="assets/plugins/summernote/summernote-bs4.min.js"></script>
	<!-- overlayScrollbars -->
	<script src="assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
	<!-- AdminLTE App -->
	<script src="assets/dist/js/adminlte.js"></script>
	<!-- AdminLTE for demo purposes -->
	<!-- <script src="assets/dist/js/demo.js"></script> -->
	<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
	<script src="assets/dist/js/pages/dashboard.js"></script>
	<script src="<?= base_url('assets/');?>js/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
</body>
</html>
