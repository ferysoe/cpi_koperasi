<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Per Day</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Data Per Day</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title font-weight-bold pt-2">Table Data Per Day Global</h3>
                <div class="card-tools">
									<button type="button" class="btn btn-tool float-sm-right" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
								</div>
              </div>
              <div class="card-body table-responsive">
                <div class="table-responsive">
                  <table class="table" id="table_dpd">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Realisasi</th>
                        <th>Target</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                        $no = 1;
                        foreach($dpd as $d){
						          ?>
							        <tr>
                        <td><?= $no; $no++;?></td>
                        <td><?= $d->tanggal; ?></td>
                        <td><?= $d->realisasi; ?></td>
                        <td><?= $d->target; ?></td>
                      </tr>
                      <?php
                        }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>     
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title font-weight-bold pt-2">Table Data Per Day Permanent</h3>
                <div class="card-tools">
									<button type="button" class="btn btn-tool float-sm-right" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
								</div>
              </div>
              <div class="card-body table-responsive">
                <div class="row">
                  <h1 class="font-weight-bold pt-3 px-2">Krian</h1>
                </div>
                <div class="row p-2">
                  <div class="table-responsive">
                    <table class="table" id="table_dpd_permanent_krian">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Tanggal</th>
                          <th>Department</th>
                          <th>Realisasi</th>
                          <th>Target</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $no = 1;
                          foreach($dpdPermanentKrian as $d):
                        ?>
                        <tr>
                          <td><?= $no; $no++;?></td>
                          <td><?= $d->tanggal; ?></td>
                          <td><?= $d->department; ?></td>
                          <td><?= $d->realisasi; ?></td>
                          <td><?= $d->target; ?></td>
                        </tr>
                        <?php
                          endforeach;
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <h1 class="font-weight-bold pt-3 px-2">Sepanjang</h1>
                </div>
                <div class="row p-2 mt-2">
                  <div class="table-responsive">
                    <table class="table" id="table_dpd_permanent_sepanjang">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Tanggal</th>
                          <th>Department</th>
                          <th>Realisasi</th>
                          <th>Target</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $no = 1;
                          foreach($dpdPermanentSepanjang as $d):
                        ?>
                        <tr>
                          <td><?= $no; $no++;?></td>
                          <td><?= $d->tanggal; ?></td>
                          <td><?= $d->department; ?></td>
                          <td><?= $d->realisasi; ?></td>
                          <td><?= $d->target; ?></td>
                        </tr>
                        <?php
                          endforeach;
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <h1 class="font-weight-bold pt-3 px-2">Premix</h1>
                </div>
                <div class="row p-2 mt-2">
                  <div class="table-responsive">
                    <table class="table" id="table_dpd_permanent_premix">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Tanggal</th>
                          <th>Department</th>
                          <th>Realisasi</th>
                          <th>Target</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $no = 1;
                          foreach($dpdPermanentPremix as $d):
                        ?>
                        <tr>
                          <td><?= $no; $no++;?></td>
                          <td><?= $d->tanggal; ?></td>
                          <td><?= $d->department; ?></td>
                          <td><?= $d->realisasi; ?></td>
                          <td><?= $d->target; ?></td>
                        </tr>
                        <?php
                          endforeach;
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>     
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title font-weight-bold pt-2">Table Data Per Day OS</h3>
                <div class="card-tools">
									<button type="button" class="btn btn-tool float-sm-right" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
								</div>
              </div>
              <div class="card-body table-responsive">
                <div class="row">
                  <h1 class="font-weight-bold pt-3 px-2">Krian</h1>
                </div>
                <div class="row p-2">
                  <div class="table-responsive">
                    <table class="table" id="table_dpd_os_krian">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Tanggal</th>
                          <th>Vendor</th>
                          <th>Realisasi</th>
                          <th>Target</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $no = 1;
                          foreach($dpdOSKrian as $d):
                        ?>
                        <tr>
                          <td><?= $no; $no++;?></td>
                          <td><?= $d->tanggal; ?></td>
                          <td><?= $d->vendor; ?></td>
                          <td><?= $d->realisasi; ?></td>
                          <td><?= $d->target; ?></td>
                        </tr>
                        <?php
                          endforeach;
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <h1 class="font-weight-bold pt-3 px-2">Sepanjang</h1>
                </div>
                <div class="row p-2 mt-2">
                  <div class="table-responsive">
                    <table class="table" id="table_dpd_os_sepanjang">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Tanggal</th>
                          <th>Vendor</th>
                          <th>Realisasi</th>
                          <th>Target</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $no = 1;
                          foreach($dpdOSSepanjang as $d):
                        ?>
                        <tr>
                          <td><?= $no; $no++;?></td>
                          <td><?= $d->tanggal; ?></td>
                          <td><?= $d->vendor; ?></td>
                          <td><?= $d->realisasi; ?></td>
                          <td><?= $d->target; ?></td>
                        </tr>
                        <?php
                          endforeach;
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <h1 class="font-weight-bold pt-3 px-2">Premix</h1>
                </div>
                <div class="row p-2 mt-2">
                  <div class="table-responsive">
                    <table class="table" id="table_dpd_os_premix">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Tanggal</th>
                          <th>Vendor</th>
                          <th>Realisasi</th>
                          <th>Target</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $no = 1;
                          foreach($dpdOSPremix as $d):
                        ?>
                        <tr>
                          <td><?= $no; $no++;?></td>
                          <td><?= $d->tanggal; ?></td>
                          <td><?= $d->vendor; ?></td>
                          <td><?= $d->realisasi; ?></td>
                          <td><?= $d->target; ?></td>
                        </tr>
                        <?php
                          endforeach;
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>     
      </div>
    </section>
</div>

<script type="text/javascript" src="<?= base_url('assets/js/');?>dpd.js?v=1.1.1.1"></script>