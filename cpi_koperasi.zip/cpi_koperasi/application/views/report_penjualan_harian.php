<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Penjualan Harian</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Report Penjualan Harian</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">

    <div class="container-fluid">
			<!-- Small boxes (Stat box) -->
		<div class="row">
			<div class="col-lg-8 col-6">
				<!-- small box -->
				<div class="small-box bg-info">
				<div class="inner">
					<?php
						
					?>
					<h1 class="display-2 font-weight-bold"><?= "Rp " . number_format($total_pembayaran,2,',','.'); ?></h1>

					<p>Total Cash yang Didapat</p>
				</div>
				<div class="icon">
					<i class="fas fa-balance-scale"></i>
				</div>
				</div>
			</div>
			<!-- ./col -->
			<div class="col-lg-4 col-6">
				<!-- small box -->
				<div class="small-box bg-success">
				<div class="inner">
					<h1 class="display-2 font-weight-bold"><?= $jumlah; ?></h1>

					<p>Jumlah Pembelian Ayam</p>
				</div>
				<div class="icon">
					<i class="fas fa-trophy"></i>
				</div>
				</div>
			</div>
			<!-- ./col -->
			<!-- ./col -->
		</div>
		<div class="row">
			<div class="col-lg-2 col-6">
				<!-- small box -->
				<div class="small-box bg-warning">
				<div class="inner">
					<h1 class="display-2 font-weight-bold"><?= $stock; ?></h1>
	
					<p>Sisa Stock Ayam</p>
				</div>
				<div class="icon">
					<i class="ion ion-stats-bars"></i>
				</div>
				</div>
			</div>
			<div class="col-lg-2 col-6">
				<!-- small box -->
				<div class="small-box bg-warning">
				<div class="inner">
					<h1 class="display-2 font-weight-bold"><?= $jmlVoucher; ?></h1>
	
					<p>Jumlah Voucher Terclaim</p>
				</div>
				<div class="icon">
					<i class="ion ion-stats-bars"></i>
				</div>
				</div>
			</div>
			<div class="col-lg-2 col-6">
				<!-- small box -->
				<div class="small-box bg-primary">
				<div class="inner">
					<h1 class="display-2 font-weight-bold"><?= $voucher; ?></h1>

					<p>Penjualan Dengan Voucher</p>
				</div>
				<div class="icon">
					<i class="fas fa-receipt"></i>
				</div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<!-- small box -->
				<div class="small-box bg-primary">
				<div class="inner">
					<?php
						
					?>
					<h1 class="display-2 font-weight-bold"><?= $cash; ?></h1>

					<p>Penjualan Dengan Cash</p>
				</div>
				<div class="icon">
					<i class="fas fa-money-bill"></i>
				</div>
				</div>
			</div>
			<!-- ./col -->
			<!-- ./col -->
			<div class="col-lg-3 col-6">
				<!-- small box -->
				<div class="small-box bg-primary">
				<div class="inner">
					<h1 class="display-2 font-weight-bold"><?= $payroll; ?></h1>

					<p>Penjualan Dengan Payroll</p>
				</div>
				<div class="icon">
					<i class="fas fa-file-invoice"></i>
				</div>
				</div>
			</div>
			<!-- ./col -->
		</div>
    </div>

      <div class="container-fluid">
        
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Table User</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive">
                <div class="table-responsive">
                    <a target="_blank" class="btn btn-primary mb-3" href="<?= base_url('reportpenjualanharian/print_data') ?>">EXPORT KE EXCEL</a>
                <!-- <a target="_blank" href="">EXPORT KE EXCEL</a> -->
                  <table class="table" id="table_data_user">
                    <thead>
                      <tr>
                        <th>ID Pembelian</th>
                        <th>Nama</th>
                        <th>NIK/NoReg</th>
                        <th>Jumlah Pembelian</th>
                        <th>Total Pembayaran</th>
                        <th>Jenis Pembayaran</th>
                        <th>Keterangan</th>
                        <th>Kode Voucher</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                          foreach($report as $r){
                            ?>
                              <tr>
                                <td><?= $r->id_pembelian; ?></td>
                                <td><?= $r->nama; ?></td>
                                <td><?= $r->no_reg; ?></td>
                                <td><?= $r->jumlah; ?></td>
                                <td><?= $r->total; ?></td>
                                <td><?= $r->status; ?></td>
                                <td><?= $r->keterangan; ?></td>
                                <td><?= $r->kode_voucher; ?></td>
                              </tr>
                            <?php
                          }
                        ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>     
      </div><!-- /.container-fluid -->
    </section>

    
</div>
  <!-- /.content-wrapper -->
<script type="text/javascript" src="<?= base_url('assets/js/');?>reportPenjualanHarian.js?v=1.1.1.1.1.1"></script>