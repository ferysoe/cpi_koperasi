

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
			<div class="col-sm-6" style="display: flex; justify-content: left;">
				<h1 class="text-left m-0">Dashboard Penjualan</h1>
			</div><!-- /.col -->
			
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->
		</div>
		<!-- /.content-header -->

		<!-- Main content -->
		<div class="container-fluid">
			<!-- Small boxes (Stat box) -->
			<div class="row">
			<div class="col-lg-4 col-6">
				<!-- small box -->
				<div class="small-box bg-info">
				<div class="inner">
					<?php
						// var_dump($realisasi[0]->jumlah);
						if($realisasi[0]->jumlah == null){
							$realisasiWrite = "0";
						}else{
							$realisasiWrite = $realisasi[0]->jumlah;
						}
					?>
					<h1 class="display-2 font-weight-bold"><?= $realisasiWrite ?></h1>

					<p>Total Realisasi</p>
				</div>
				<div class="icon">
					<i class="fas fa-balance-scale"></i>
				</div>
				</div>
			</div>
			<!-- ./col -->
			<div class="col-lg-4 col-6">
				<!-- small box -->
				<div class="small-box bg-success">
				<div class="inner">
					<h1 class="display-2 font-weight-bold"><?= $target[0]->target ?></h1>

					<p>Total Target</p>
				</div>
				<div class="icon">
					<i class="fas fa-trophy"></i>
				</div>
				</div>
			</div>
			<!-- ./col -->
			<div class="col-lg-4 col-6">
				<!-- small box -->
				<div class="small-box bg-warning">
				<div class="inner">
					<h1 class="display-2 font-weight-bold"><?= $percentage ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>

					<p>Persentase</p>
				</div>
				<div class="icon">
					<i class="ion ion-stats-bars"></i>
				</div>
				</div>
			</div>
			<!-- ./col -->
			</div>
			<!-- /.row -->
			<!-- Main row -->
			<div class="row">
			<!-- Left col -->
			<section class="col-lg-12">
				<!-- Custom tabs (Charts with tabs)-->
				<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title font-weight-bold">
					<i class="fas fa-chart-pie mr-1"></i>
					Penjualan Plant Krian
					</h3>
				</div><!-- /.card-header -->
				<div class="card-body">
					<div class="tab-content p-0">
						<h4>Permanent</h4>
						<table class="table">
							<thead>
								<tr>
								<th scope="col">Area</th>
								<th scope="col">Total Realisasi</th>
								<th scope="col">Total Target</th>
								<th scope="col">Presentase</th>
								</tr>
							</thead>
							<tbody>
								<?php
										foreach($dataKrian as $dk){
											?>
											<tr>
												<th scope="row"><?= $dk->Area; ?></th>
											<?php
											if($dk->Realisasi == null){
												$realisasiKrian = 0;
											}else{
												$realisasiKrian = $dk->Realisasi;
											}
											?>
												<td><?= $realisasiKrian; ?></td>
											<?php
											?>
												<td><?= $dk->Target; ?></td>
											<?php
												if($dk->Target <= 0){
													if($realisasiKrian <= 0){
														$percentageKrian = 0;
													}else{
														$percentageKrian = 100;
													}
												}else{
													$percentageKrian = round(($realisasiKrian / $dk->Target) * 100);
												}
											?>
												<td><?= $percentageKrian . "%"; ?></td>
												</tr>
											<?php
										}
									?>
							</tbody>
						</table>
					</div>
					<div class="tab-content p-0">
						<h4>OS</h4>
						<table class="table">
							<thead>
								<tr>
									<th scope="col">Vendor</th>
									<th scope="col">Total Realisasi</th>
									<th scope="col">Total Target</th>
									<th scope="col">Persentase</th>
								</tr>
							</thead>
							<tbody>
								<?php
										foreach($dataOSKrian as $dk):
											?>
											<tr>
												<th scope="row"><?= $dk->Vendor; ?></th>
											<?php
											if($dk->Realisasi == null){
												$realisasiKrian_data = 0;
											}else{
												$realisasiKrian_data = $dk->Realisasi;
											}
											?>
												<td><?= $realisasiKrian_data; ?></td>
											<?php
											?>
												<td><?= $dk->Target; ?></td>
											<?php
												if($realisasiKrian_data == 0){
													$percentageKrian = 0;
												}elseif($dk->Target == 0){
													if($realisasiKrian_data > 1){
														$percentageKrian = 100;
													}else{
														$percentageKrian = 0;
													}
												}else{
													$percentageKrian = round(($realisasiKrian_data / $dk->Target) * 100);
												}
											?>
												<td><?= $percentageKrian . "%"; ?></td>
												</tr>
											<?php
										endforeach;
									?>
							</tbody>
						</table>
					</div>
				</div><!-- /.card-body -->
				</div>
				<!-- /.card -->

			</section>
			<section class="col-lg-12">
				<!-- Custom tabs (Charts with tabs)-->
				<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title font-weight-bold">
					<i class="fas fa-chart-pie mr-1"></i>
					Penjualan Plant Sepanjang
					</h3>
				</div><!-- /.card-header -->
				<div class="card-body">
					<div class="tab-content p-0">
						<h4>Permanent</h4>
						<table class="table">
							<thead>
								<tr>
								<th scope="col">Area</th>
								<th scope="col">Total Realisasi</th>
								<th scope="col">Total Target</th>
								<th scope="col">Presentase</th>
								</tr>
							</thead>
							<tbody>
								<?php
										foreach($dataSepanjang as $dk){
											?>
											<tr>
												<th scope="row"><?= $dk->Area; ?></th>
											<?php
											if($dk->Realisasi == null){
												$realisasiKrian = 0;
											}else{
												$realisasiKrian = $dk->Realisasi;
											}
											?>
												<td><?= $realisasiKrian; ?></td>
											<?php
											?>
												<td><?= $dk->Target; ?></td>
											<?php
												if($dk->Target <= 0){
													if($realisasiKrian <= 0){
														$percentageKrian = 0;
													}else{
														$percentageKrian = 100;
													}
												}else{
													$percentageKrian = round(($realisasiKrian / $dk->Target) * 100);
												}
											?>
												<td><?= $percentageKrian . "%"; ?></td>
												</tr>
											<?php
										}
									?>
							</tbody>
						</table>
					</div>
					<div class="tab-content p-0">
						<h4>OS</h4>
						<table class="table">
							<thead>
								<tr>
									<th scope="col">Vendor</th>
									<th scope="col">Total Realisasi</th>
									<th scope="col">Total Target</th>
									<th scope="col">Persentase</th>
								</tr>
							</thead>
							<tbody>
								<?php
										foreach($dataOSSepanjang as $dk):
											?>
											<tr>
												<th scope="row"><?= $dk->Vendor; ?></th>
											<?php
											if($dk->Realisasi == null){
												$realisasiKrian_data = 0;
											}else{
												$realisasiKrian_data = $dk->Realisasi;
											}
											?>
												<td><?= $realisasiKrian_data; ?></td>
											<?php
											?>
												<td><?= $dk->Target; ?></td>
											<?php
												if($realisasiKrian_data == 0){
													$percentageKrian = 0;
												}elseif($dk->Target == 0){
													if($realisasiKrian_data > 1){
														$percentageKrian = 100;
													}else{
														$percentageKrian = 0;
													}
												}else{
													$percentageKrian = round(($realisasiKrian_data / $dk->Target) * 100);
												}
											?>
												<td><?= $percentageKrian . "%"; ?></td>
												</tr>
											<?php
										endforeach;
									?>
							</tbody>
						</table>
					</div>
				</div><!-- /.card-body -->
				</div>
				<!-- /.card -->

			</section>
			<section class="col-lg-12">
				<!-- Custom tabs (Charts with tabs)-->
				<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title font-weight-bold">
					<i class="fas fa-chart-pie mr-1"></i>
					Penjualan Plant Premix
					</h3>
				</div><!-- /.card-header -->
				<div class="card-body">
					<div class="tab-content p-0">
						<h4>Permanent</h4>
						<table class="table">
							<thead>
								<tr>
								<th scope="col">Area</th>
								<th scope="col">Total Realisasi</th>
								<th scope="col">Total Target</th>
								<th scope="col">Presentase</th>
								</tr>
							</thead>
							<tbody>
								<?php
										foreach($dataPremix as $dk){
											?>
											<tr>
												<th scope="row"><?= $dk->Area; ?></th>
											<?php
											if($dk->Realisasi == null){
												$realisasiKrian = 0;
											}else{
												$realisasiKrian = $dk->Realisasi;
											}
											?>
												<td><?= $realisasiKrian; ?></td>
											<?php
											?>
												<td><?= $dk->Target; ?></td>
											<?php
												if($dk->Target <= 0){
													if($realisasiKrian <= 0){
														$percentageKrian = 0;
													}else{
														$percentageKrian = 100;
													}
												}else{
													$percentageKrian = round(($realisasiKrian / $dk->Target) * 100);
												}
											?>
												<td><?= $percentageKrian . "%"; ?></td>
												</tr>
											<?php
										}
									?>
							</tbody>
						</table>
					</div>
					<div class="tab-content p-0">
						<h4>OS</h4>
						<table class="table">
							<thead>
								<tr>
									<th scope="col">Vendor</th>
									<th scope="col">Total Realisasi</th>
									<th scope="col">Total Target</th>
									<th scope="col">Persentase</th>
								</tr>
							</thead>
							<tbody>
								<?php
										foreach($dataOSPremix as $dk):
											?>
											<tr>
												<th scope="row"><?= $dk->Vendor; ?></th>
											<?php
											if($dk->Realisasi == null){
												$realisasiKrian_data = 0;
											}else{
												$realisasiKrian_data = $dk->Realisasi;
											}
											?>
												<td><?= $realisasiKrian_data; ?></td>
											<?php
											?>
												<td><?= $dk->Target; ?></td>
											<?php
												if($realisasiKrian_data == 0){
													$percentageKrian = 0;
												}elseif($dk->Target == 0){
													if($realisasiKrian_data > 1){
														$percentageKrian = 100;
													}else{
														$percentageKrian = 0;
													}
												}else{
													$percentageKrian = round(($realisasiKrian_data / $dk->Target) * 100);
												}
											?>
												<td><?= $percentageKrian . "%"; ?></td>
												</tr>
											<?php
										endforeach;
									?>
							</tbody>
						</table>
					</div>
				</div><!-- /.card-body -->
				</div>
				<!-- /.card -->

			</section>
			</div>
			<!-- /.row (main row) -->
		</div><!-- /.container-fluid -->
		<!-- /.content -->
	<!-- </div> -->
	<!-- /.content-wrapper -->
	</div>
    <!-- /.content-header -->
  </div>
 