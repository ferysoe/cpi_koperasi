<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Daftar Produk</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Daftar Produk</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <div class="container-fluid">     
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <div class="col-6">
                <h3 class="card-title">Daftar Produk</h3>
                </div>
                <div class="" style="display: flex; justify-content: right;">
                <a href=""class="btn btn-primary btn-sm" data-toggle="modal" data-target="#membershipForm" hidden><i class="fas fa-plus-circle"></i>&nbsp;Tambah Data</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table" id="table_product">
                    <thead>                       
                      <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Plant</th>
                        <th>Stock</th>
                        <th>Harga</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $no=1; foreach ($product as $row) { ?>
                        <tr>        
                          <td><?= $no;  ?></td>
                          <td><?= $row->nama?></td>
                          <td><?= $row->plant?></td>
                          <td><?= $row->stock?></td>
                          <?php
                            $rupiahConverted = "Rp " . number_format($row->harga,2,',','.');
                          ?>
                          <td><?= $rupiahConverted ?></td>
                          <td><a class="btn btn-warning btn-sm btn_edit" id="<?= $row->id_product; ?>"><i class="fas fa-pencil-alt"></i></a>
                          <a class="btn btn-danger btn-sm>" data-toggle="modal" data-target="#modal-hapus" hidden><i class="fas fa-trash-alt"></i></a></td>
                        </tr>
                      <?php $no++; } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>  
    </div>

    <!-- Content Header (Page header) -->

    <div class="container-fluid">     
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <div class="col-6">
                <h3 class="card-title">Update Harga</h3>
                </div>
                <div class="" style="display: flex; justify-content: right;">
                <a href=""class="btn btn-primary btn-sm" data-toggle="modal" data-target="#membershipForm" hidden><i class="fas fa-plus-circle"></i>&nbsp;Tambah Data</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="row">
                  <div class="form-group col-6">
                    <h4>Harga Ayam : </h4><br>
                    <?php
                       $harga = "Rp " . number_format($harga,2,',','.');
                    ?>
                    <h4><?= $harga; ?></h4>
                  </div>
                <div class="form-group col-6">
                    <label for="exampleInputPassword1">Update Harga</label>
                    <input type="number" class="form-control" id="update_harga" placeholder="Update Harga Terbaru"><br>
                    <input type="submit" class="btn btn-primary" id="btn_update_harga" value="Update Harga">
                </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div> 
      </div> 
      </div> 

<div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="membershipFormLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Daftar Produk</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body">
				<div class="box box-info">
					<div class="form-group">
						<label for="tipe_food" class="col-sm-6 control-label">Nama :</label>
						<div class="col-sm-12">
              <p class="control-label" id="nama_product"></p>
							<!-- <input type="input" class="form-control" id="tipe_food" name="nama_produk" disabled> -->
              <input type="input" class="form-control" id="id_product" name="id_product" hidden>
						</div>
					</div>
					<div class="form-group">
						<label for="tipe_food" class="col-sm-2 control-label">Plant :</label>
						<div class="col-sm-12">
              <p class="control-label" id="plant_product"></p>
							<!-- <input type="input" class="form-control" id="tipe_food" name="nama_produk" disabled> -->
              <!-- <input type="input" class="form-control" id="id_product" name="id_product" hidden> -->
						</div>
					</div>
					<div class="form-group">
						<label for="tipe_food" class="col-sm-6 control-label">Stock Sekarang :</label>
						<div class="col-sm-12">
              <p class="control-label" id="stock_now"></p>
							<!-- <input type="input" class="form-control" id="tipe_food" name="nama_produk" disabled> -->
              <!-- <input type="input" class="form-control" id="id_product" name="id_product" hidden> -->
						</div>
					</div>
					<div class="form-group">
						<label for="harga_food" class="col-sm-2 control-label">Stock</label>
						<div class="col-sm-12">
							<input type="number" class="form-control" id="stock" name = "stock" placeholder = "Masukkan Tambahan Stock">
							<!-- <input type="input" class="form-control" id="id_product" name="stock_past"hidden> -->
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary" id="save_update">Update Stock</button>
					</div>
				</div>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
   
</div>
<!-- Modal -->
<div class="modal fade" id="membershipForm" tabindex="-1" role="dialog" aria-labelledby="membershipFormLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">

        <div class="modal-content">
          <div class="modal-header">

            <h2 class="modal-title" id="membershipFormLabel">Form Pendaftaran</h2>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
          
            <form action="<?= base_url('user/tambahproduk') ?>" method="post" enctype="multipart/form-data" class="membership-form webform" role="form">
                  <div class="form-group col-12">
                    <label for="username">Nama</label><br>
                    <input type="text" class="form-control" name="nama_produk" id="nama_produk" placeholder="Masukkan Nama" >
                  </div>
                  <div class="form-group col-12">
                    <label for="username">Harga</label><br>
                    <input type="number" class="form-control" name="harga" id="harga" placeholder="Masukkan Harga" >
                  </div>
                  <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                </div>
                </div>
            </form>
          </div>

          <div class="modal-footer"></div>

        </div>
      </div>
    </div>
<!-- /.content-wrapper -->
<script type="text/javascript" src="<?= base_url('assets/js/');?>product.js?v=1.1.1.1.1.1"></script>