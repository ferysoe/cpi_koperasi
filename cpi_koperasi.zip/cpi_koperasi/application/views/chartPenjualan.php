<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Rekap Penjualan</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Rekap Penjualan</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="card card-outline card-primary m-4">
      <div class="card-header">
        <h2>Rekap Penjualan</h2>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="form-group col-6">
            <label for="exampleInputEmail1">Periode</label><br>
            <select class="js-example-basic-single form-control" name="state" id="periode">
              <option value=""></option>
              <?php 
                foreach($periode as $p){
              ?>
                <option value="<?= $p->bulan; ?>"><?= $p->periode; ?></option>
              <?php
                }
              ?>
            </select>
          </div>         
          <!-- <div class="form-group col-6">
            <label for="exampleInputEmail1">Filter</label><br>
            <select class="js-example-basic-single form-control" name="state" id="filter">
              <option value=""></option>
            </select>
          </div>          -->
        </div> 
      </div>
      <div class="card-footer">
        <button class="btn btn-outline-primary float-right">Search</button>
      </div>
    </div>
    <div class="card card-outline card-primary m-4">
      <div class="card-header">
        <h2>Periode : Maret 2023</h2>
      </div> 
      <div class="card-body">
        <div class="row m-2 mt-4">
          <div class="col-lg-4 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h1 class="display-2 font-weight-bold"><?= $realisasi[0]->jumlah; ?></h1>
                <p>Total Realisasi</p>
              </div>
              <div class="icon">
                <i class="fas fa-balance-scale"></i>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-6">
            <div class="small-box bg-success">
              <div class="inner">
                <h1 class="display-2 font-weight-bold"><?= $target[0]->target; ?></h1>
                <p>Total Target</p>
              </div>
              <div class="icon">
                <i class="fas fa-trophy"></i>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-6">
            <div class="small-box bg-warning">
              <div class="inner">
                <?php
                  if($realisasi[0]->jumlah == 0){
                    $percetase = 0;
                  }elseif($target[0]->target == 0){
                    if($realisasi[0]->jumlah > 0){
                      $percetase = 100;
                    }else{
                      $percetase = 100;
                    }
                  }else{
                    $percetase = ($realisasi[0]->jumlah / $target[0]->target)*100;
                  }
                ?>
                <h1 class="display-2 font-weight-bold"><?= number_format((float)$percetase, 1, '.', ''); ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
                <p>Persentase</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
            </div>
          </div>
        </div>
        <canvas class="align-middle" id="myChart" width="400" height="100"></canvas>
      </div>
      <div class="overlay" id="loading" hidden>
        <i class="fas fa-2x fa-sync-alt fa-spin"></i>
      </div>
    </div>
  </section>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script type="text/javascript" src="<?= base_url('assets/js/');?>chartPenjualan.js?v=1.1.1.1.1.1.1"></script>