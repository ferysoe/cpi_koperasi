<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>User</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Input data User</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

    <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Input Data User</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="post" action="<?php echo base_url('user/tambahuser'); ?>">      
                <div class="card-body">
                <div class="row">
                  <div class="form-group col-6">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" name="nama" id="nama" placeholder="Masukkan Nama" required>
                  </div>
                  <div class="form-group col-6">
                    <label for="no_reg">NoReg / NIK</label>
                    <input type="text" class="form-control" name="no_reg" id="no_reg" placeholder="Masukkan No Reg" required>
                  </div>
                  <div class="form-group col-6">
                    <label for="exampleInputPassword1">Status Karyawan</label><br>
                    <select class="form-control" aria-label="Default select example" name="status_karyawan" id="status_karyawan" required>
                      <option selected></option>
                      <option value="PREMANENT">Permanent</option>
                      <option value="NON PERMANENT">Non Permanent</option>
                    </select>
                  </div>
                  <div class="form-group col-2">
                    <label for="target">Mendapatkan Voucher ?</label>
                    <select class="form-control" aria-label="Default select example" name="has_voucher" required>
                      <option value="n">No</option>
                      <option value="y">Yes</option>
                    </select>
                  </div>
                  <div class="form-group col-4">
                    <label for="target">Target</label>
                    <input type="number" class="form-control" name="target" id="target" placeholder="Permanen (4), OS (2)" required>
                  </div>
                  <div class="form-group col-6">
                    <label for="vendor">Vendor</label>
                    <select class="form-control" name="vendor" id="vendor" required>
                        <option value=""></option>
                        <?php
                        foreach($vendor as $dp){
                          ?>
                            <option value="<?= $dp->id ?>"><?= $dp->keterangan ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="departemen">Department</label>
                    <select class="form-control" name="department" id="department" required>
                        <option value=""></option>
                        <?php
                        foreach($department as $dp){
                          ?>
                            <option value="<?= $dp->department ?>"><?= $dp->department ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="id_plant">ID Plant</label>
                    <select class="form-control" name="id_plant" id="id_plant" required>
                        <option value=""></option>
                        <?php
                        foreach($plant as $dp){
                          ?>
                            <option value="<?= $dp->id_plant ?>"><?= $dp->keterangan ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-2">
                    <label for="id_akses" id="pic_teks">Apakah User Adalah PIC ?</label>
                    <select class="form-control" name="pic_yesno" id="pic_yesno" require>
                        <option value="n">No</option>
                        <option value="y">Yes</option>
                    </select>
                  </div>       
                  <div class="form-group col-4">
                    <label for="id_pic">Pilihan PIC</label>
                    <select class="form-control" name="id_pic" id="id_pic" required>
                        <option value=""></option>
                        <?php
                        foreach($pic as $dpic){
                          ?>
                            <option value="<?= $dpic->id_pic ?>"><?= $dpic->nama ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="username" id="username_label" style="display:none;">Username</label>
                    <input type="text" class="form-control" name="username" id="username" style="display:none;" placeholder="Masukkan Username" required></input>
                  </div>
                  <div class="form-group col-6">
                    <label for="password" id="password_label" style="display:none;">Password</label>
                    <input type="password" class="form-control" name="password" id="password" style="display:none;" placeholder="Masukkan Password" required>
                  </div>
                  <div class="form-group col-6">
                    <label for="pic_question" id="pic_question_label" style="display:none;">PIC</label>
                    <select class="form-control" name="pic_question" id="pic_question" style="display:none;">
                        <option value="y">Diri Sendiri</option>
                        <option value="n">User Lain</option>
                    </select>
                  </div> 
                  <div class="form-group col-6">
                    <label for="username" id="area_pic_label" style="display:none;">Area PIC</label>
                    <input type="text" class="form-control" name="area_pic" id="area_pic" style="display:none;" placeholder="Masukkan Area PIC" required></input>
                  </div>      
              </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            <!-- Input addon -->
          </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">
            <!-- Form Element sizes -->          
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->

      <div class="container-fluid">
        
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Table User</h3>
                <!-- <div class="row" style="display:flex; justify-content:right;">
                  <div class="col-md-4">
                    <form action="<?php echo base_url('user/search');?>" method="post">
                      <div class="input-group">
                      <input type="search" class="form-control" placeholder="Cari Nama" name="keyword">
                      <div class="input-group-append">
                        <button type="submit" class="btn btn-primary">
                        <i class="fa fa-search"></i>
                        </button>
                      </div>
                      </div>
                    </form>
                  </div>
                </div> -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="table-responsive">                            
                  <table class="table" id="table_user">
                    <thead>
                      <tr>
                        <th rowspan="1" colspan="1">No</th>
                        <th rowspan="1" colspan="1">Nama</th>
                        <th rowspan="1" colspan="1">No Reg</th>
                        <th rowspan="1" colspan="1">Status Karyawan</th>
                        <th rowspan="1" colspan="1">Vendor</th>
                        <th rowspan="1" colspan="1">Department</th>
                        <th rowspan="1" colspan="1">Aktif</th>
                        <th rowspan="1" colspan="1">ID Plant</th>
                        <th rowspan="1" colspan="1">ID PIC</th>
                        <th rowspan="1" colspan="1">Target</th>
                        <th rowspan="1" colspan="1">Voucher</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $no=1; foreach  ($master_user as $du):
                        if($du->id_akses !== "1"){
                      ?>
                      <tr id="<?=$du->id_user?>">
                        <td rowspan="1" colspan="1"><?=$no?></td>
                        <td rowspan="1" colspan="1"><?= $du->nama?></td>
                        <td rowspan="1" colspan="1"><?= $du->no_reg?></td>
                        <td rowspan="1" colspan="1"><?= $du->status_karyawan?></td>
                        <td rowspan="1" colspan="1"><?= $du->vendor?></td>
                        <td rowspan="1" colspan="1"><?= $du->departemen?></td>
                        <td rowspan="1" colspan="1"><?= $du->aktif?></td>
                        <td rowspan="1" colspan="1"><?= $du->id_plant?></td>
                        <td rowspan="1" colspan="1"><?= $du->id_pic?></td>
                        <td rowspan="1" colspan="1"><?= $du->target?></td>
                        <td rowspan="1" colspan="1"><?= $du->has_voucher?></td>
                      </tr>
                      <?php $no++; }?>
                      <?php endforeach ?>
                    </tbody>                
                  </table>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>     
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="modaluser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">Edit Data User</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="post" action="<?php echo base_url('user/editUser'); ?>">      
                <div class="card-body">
                <div class="row">
                  <input type="text" class="form-control" name="id_user" id="id_user" hidden>
                  <div class="form-group col-6">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" name="nama_edit" id="nama_edit" placeholder="Masukkan Nama">
                  </div>
                  <div class="form-group col-6">
                    <label for="no_reg">No Reg</label>
                    <input type="text" class="form-control" name="no_reg_edit" id="no_reg_edit" placeholder="Masukkan No Reg">
                  </div>
                  <div class="form-group col-6">
                  <label for="exampleInputPassword1">Status Karyawan</label><br>
                  <select class="form-control" aria-label="Default select example" name="sts_krywn_edit" id="sts_krywn_edit">
                    <option selected></option>
                    <option value="PREMANENT">Permanent</option>
                    <option value="NON PERMANENT">Non Permanent</option>
                  </select>
                  </div>
                  <div class="form-group col-3">
                    <label for="exampleInputPassword1">Status Aktif</label><br>
                    <select class="form-control" aria-label="Default select example" name="aktif_edit" id="aktif_edit">
                      <option selected></option>
                      <option value="AKTIF">Aktif</option>
                      <option value="TIDAK AKTIF">Tidak Aktif</option>
                    </select>
                  </div>
                  <div class="form-group col-3">
                    <label for="id_plant">ID Plant</label>
                    <select class="form-control" name="id_plant_edit" id="id_plant_edit">
                        <option value=""></option>
                        <?php
                        foreach($plant as $dp){
                          ?>
                            <option value="<?= $dp->id_plant ?>"><?= $dp->keterangan ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="vendor">Vendor</label>
                    <select class="form-control" name="vendor_edit" id="vendor_edit" required>
                        <option value=""></option>
                        <?php
                        foreach($vendor as $dp){
                          ?>
                            <option value="<?= $dp->id ?>"><?= $dp->keterangan ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="departemen">Department</label>
                    <select class="form-control" name="department_edit" id="department_edit" required>
                        <option value=""></option>
                        <?php
                        foreach($department as $dp){
                          ?>
                            <option value="<?= $dp->department ?>"><?= $dp->department ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-6">
                    <label for="password">ID PIC</label>
                    <select class="form-control" name="id_pic_edit" id="id_pic_edit">
                        <option value=""></option>
                        <?php
                        foreach($pic as $dpic){
                          ?>
                            <option value="<?= $dpic->id_pic ?>"><?= $dpic->nama ?></option>
                          <?php
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group col-4">
                    <label for="target">Mendapatkan Voucher ?</label>
                    <select class="form-control" aria-label="Default select example" name="has_voucher_edit" id="has_voucher_edit" required>
                      <option value="n">No</option>
                      <option value="y">Yes</option>
                    </select>
                  </div>
                  <div class="form-group col-2">
                    <label for="target">Target</label>
                    <input type="text" class="form-control" name="target_edit" id="target_edit" placeholder="Permanen (4), OS (2)">
                  </div>  
                  <div class="form-group col-6">
                    <label for="username">Username</label><br>
                    <input type="text" class="form-control" name="username_edit" id="username_edit" placeholder="Masukkan Username">
                  </div>
                  <div class="form-group col-6">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password_edit" id="password_edit" placeholder="Masukkan Password">
                  </div>           
              </div>
                </div>
                <!-- /.card-body -->
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-success">Update</button>
                  <button type="submit" id="btn_del" class="btn btn-danger">Delete</button>
                </div>
              </form>
      </div>
      
    </div>
  </div>
</div>

<div class="modal fade" id="modaldeleteuser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">Delete User</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?= base_url('user/deleteUser') ?>" method="post">
      <div class="modal-body">
       <h4>Apakah Anda yakin ingin menghapus Data ini?</h4>
       <p id="data"></p>
        <div class="form-group col-12">
          <input type="text" class="form-control" name="id_user" id="id_user_delete" hidden>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Konfirmasi</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?= base_url('assets/js/');?>user.js?v=1.1.1.1.1.1.1.1.1"></script>