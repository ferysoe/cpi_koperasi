<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Data Pembelian User per PIC</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Report Pembelian User</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-4">
          <div class="small-box bg-info">
            <div class="inner">
              <h1 class="display-2 font-weight-bold"><?= $realisasi; ?></h1>
              <p>Total Realisasi</p>
            </div>
            <div class="icon">
              <i class="fas fa-balance-scale"></i>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4">
          <div class="small-box bg-success">
            <div class="inner">
              <h1 class="display-2 font-weight-bold"><?= $target; ?></h1>
              <p>Total Target</p>
            </div>
            <div class="icon">
              <i class="fas fa-trophy"></i>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="small-box bg-warning">
            <div class="inner">
              <h1 class="display-2 font-weight-bold"><?= round(($realisasi / $target) * 100); ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
              <p>Persentase</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Table User</h3>
            </div>
            <div class="card-body table-responsive">
              <?php
                if($status == 'ALL' || $status == 'PERMANENT'){
              ?>
              
              <div class="row">
                <h1 class="font-weight-bold p-3">
                  Permanent
                </h1>
              </div>
              <div class="row">
                <div class="col-lg-4">
                  <div class="small-box bg-info">
                    <div class="inner">
                      <h1 class="display-2 font-weight-bold"><?= $realisasiPermanent; ?></h1>
                      <p>Total Realisasi</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-balance-scale"></i>
                    </div>
                  </div>
                </div>
                
                <div class="col-lg-4">
                  <div class="small-box bg-success">
                    <div class="inner">
                      <h1 class="display-2 font-weight-bold"><?= $targetPermanent; ?></h1>
                      <p>Total Target</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-trophy"></i>
                    </div>
                  </div>
                </div>

                <div class="col-lg-4">
                  <div class="small-box bg-warning">
                    <div class="inner">
                      <h1 class="display-2 font-weight-bold"><?= round(($realisasiPermanent / $targetPermanent) * 100); ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
                      <p>Persentase</p>
                    </div>
                    <div class="icon">
                      <i class="ion ion-stats-bars"></i>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row p-3">
                <div class="table-responsive">
                  <!-- <a target="_blank" class="btn btn-primary mb-3" href="<?= base_url('reportuserpembelian/print_data') ?>">EXPORT KE EXCEL</a> -->
                  <table class="table" id="table_data_user">
                    <thead>
                      <tr>
                        <th>Nama</th>
                        <th>NIK / NOREG</th>
                        <th>Vendor</th>
                        <th>Department</th>
                        <th>Realisasi</th>
                        <th>Target</th>
                        <th>Percentage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                        foreach($dataUser as $du){
                          $realisasi = $du->realisasi;
                          $target = $du->target;
  
                          if($target <= 0){
                            if($realisasi > 0){
                              $percentage = 100;
                            }else{
                              $percentage = 0;
                            }
                          }
  
                          if($realisasi <= 0){
                            $percentage = 0;
                          }else{
                            if($target <= 0){
                              $percentage = 100;
                            }else{
                              $percentage = round(($realisasi / $target) * 100);
                            }
                          }
  
                          if($percentage <= 0){
                            ?>
                              <tr class="table-danger">
                            <?php
                          }elseif($percentage <= 49){
                            ?>
                              <tr class="bg-orange">
                            <?php
                          }elseif($percentage <= 99){
                            ?>
                              <tr class="bg-warning">
                            <?php
                          }else{
                            ?>
                              <tr class="table-success">
                            <?php
                          }
                      ?>
                        <td><?= $du->nama; ?></td>
                        <td><?= $du->no_reg; ?></td>
                        <td><?= $du->vendor; ?></td>
                        <td><?= $du->department; ?></td>
                        <td><?= $du->realisasi; ?></td>
                        <td><?= $du->target; ?></td>
                        <th scope="row"><?= $percentage . "%"; ?></th>
                      </tr>
                      <?php
                        }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>

              <?php
                }
              ?>

              <?php
                if($status == 'ALL' || $status == 'NON PERMANENT'){
              ?>

              <div class="row">
                <h1 class="font-weight-bold p-3">
                  OS
                </h1>
              </div>
              <!-- <div class="row">
                <div class="col-lg-4">
                  <div class="small-box bg-info">
                    <div class="inner">
                      <h1 class="display-2 font-weight-bold"><?= $realisasiOS; ?></h1>
                      <p>Total Realisasi</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-balance-scale"></i>
                    </div>
                  </div>
                </div>
                
                <div class="col-lg-4">
                  <div class="small-box bg-success">
                    <div class="inner">
                      <h1 class="display-2 font-weight-bold"><?= $targetOS; ?></h1>
                      <p>Total Target</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-trophy"></i>
                    </div>
                  </div>
                </div>

                <div class="col-lg-4">
                  <div class="small-box bg-warning">
                    <div class="inner">
                      <h1 class="display-2 font-weight-bold"><?= round(($realisasiOS / $targetOS) * 100); ?><sup class="font-weight-bold" style="font-size: 50px">%</sup></h1>
                      <p>Persentase</p>
                    </div>
                    <div class="icon">
                      <i class="ion ion-stats-bars"></i>
                    </div>
                  </div>
                </div>
              </div> -->
              <div class="row p-3">
                <div class="table-responsive">
                  <!-- <a target="_blank" class="btn btn-primary mb-3" href="<?= base_url('reportuserpembelian/print_data') ?>">EXPORT KE EXCEL</a> -->
                  <table class="table" id="table_data_user_OS">
                    <thead>
                      <tr>
                        <th>Vendor</th>
                        <th>Realisasi</th>
                        <th>Target</th>
                        <th>Persentase</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                        foreach($dataUserOS as $du){
                          $realisasi = $du->realisasi;
                          $target = $du->target;
  
                          if($target <= 0){
                            if($realisasi > 0){
                              $percentage = 100;
                            }else{
                              $percentage = 0;
                            }
                          }
  
                          if($realisasi <= 0){
                            $percentage = 0;
                          }else{
                            if($target <= 0){
                              $percentage = 100;
                            }else{
                              $percentage = round(($realisasi / $target) * 100);
                            }
                          }
  
                          if($percentage <= 49){
                            ?>
                              <tr class="table-danger">
                            <?php
                          }elseif($percentage <= 99){
                            ?>
                              <tr class="table-warning">
                            <?php
                          }else{
                            ?>
                              <tr class="table-success">
                            <?php
                          }
                      ?>
                        <td><?= $du->vendor; ?></td>
                        <td><?= $du->realisasi; ?></td>
                        <td><?= $du->target; ?></td>
                        <td><?= $percentage . '%'; ?></td>
                      </tr>
                      <?php
                        }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>

              <?php
                }
              ?>
            </div>
          </div>
        </div>
      </div>     
    </div>
  </section>
</div>

<script type="text/javascript" src="<?= base_url('assets/js/');?>reportUserPembelian.js?v=1.1.1.1.1.1"></script>